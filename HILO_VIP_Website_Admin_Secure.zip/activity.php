<?php
/** Verified member activity logs (solo mode); gameplay calculations remain browser-local. */
declare(strict_types=1);
require __DIR__.'/vip_storage.php';
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');
$who=vip_require_member();$req=vip_req();$action=$req['action']??'';
if(!in_array($action,['SOLO_ENTER','SOLO_ROUND','SOLO_EXIT'],true))vip_json_error('คำสั่งไม่ถูกต้อง');
$code=vip_clean_name($req['code']??'',16);
if(!preg_match('/^[A-Z][0-9]{5}$/D',$code))vip_json_error('รหัสห้องเดี่ยวไม่ถูกต้อง');
$name=vip_clean_name($req['name']??$who['name'],24)?:$who['name'];
$round=filter_var($req['round']??0,FILTER_VALIDATE_INT);if($round===false||$round<0||$round>999999)$round=0;
$dice=$req['dice']??null;
if(!is_array($dice)||count($dice)!==3||array_filter($dice,static fn($n)=>!is_int($n)||$n<1||$n>6))$dice=null;
$stake=filter_var($req['stake']??0,FILTER_VALIDATE_INT);if($stake===false||$stake<0||$stake>1000000000)$stake=0;
$payout=filter_var($req['payout']??0,FILTER_VALIDATE_INT);if($payout===false||$payout<0||$payout>1000000000)$payout=0;
$now=(int)round(microtime(true)*1000);
$result=vip_locked('hilo-rooms-data.php',static function(array $db)use($who,$action,$code,$name,$round,$dice,$stake,$payout,$now):array {
  $db['rooms']??=[];$db['archive']??=[];$db['events']??=[];
  $db['events'][]=['at'=>$now,'event'=>$action,'room'=>$code,'username'=>$who['username'],
    'name'=>$name,'round'=>$round,'dice'=>$dice,'stake'=>$stake,'payout'=>$payout,'source'=>'CLIENT_SOLO'];
  return ['db'=>$db,'result'=>['ok'=>true]];
});
echo json_encode($result,JSON_UNESCAPED_UNICODE);
