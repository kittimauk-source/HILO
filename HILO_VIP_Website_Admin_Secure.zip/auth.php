<?php
/** Server-side membership, password hashes and sessions (no Guest access). */
declare(strict_types=1);
require __DIR__.'/vip_storage.php';
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');
vip_session();$input=vip_req();$action=$input['action']??'';
if($action==='logout'){
    unset($_SESSION['vip_member']);session_regenerate_id(true);
    echo json_encode(['ok'=>true]);exit;
}
if($action==='me'){
    echo json_encode(['ok'=>true,'user'=>$_SESSION['vip_member']??null],JSON_UNESCAPED_UNICODE);exit;
}
if(!in_array($action,['register','login'],true))vip_json_error('ไม่รู้จักคำสั่ง');
$username=strtolower(trim(is_string($input['username']??null)?$input['username']:''));
$password=$input['password']??'';
if(!preg_match('/^[a-z0-9_]{3,24}$/D',$username))vip_json_error('Username ต้องเป็นอักษรอังกฤษ ตัวเลข หรือ _ จำนวน 3–24 ตัว');
if(!is_string($password)||strlen($password)<8||strlen($password)>72)vip_json_error('รหัสผ่านต้องมี 8–72 ตัวอักษร');
$name=vip_clean_name($input['name']??'',24)?:$username;
$result=vip_locked('hilo-accounts-data.php',static function(array $db)use($username,$password,$name,$action):array {
    $db['accounts']??=[];
    if($action==='register'){
        if(isset($db['accounts'][$username]))vip_json_error('Username นี้ถูกใช้แล้ว',409);
        $db['accounts'][$username]=['username'=>$username,'name'=>$name,
           'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'createdAt'=>(int)(microtime(true)*1000)];
    }else{
        $user=$db['accounts'][$username]??null;
        if(!is_array($user)||!password_verify($password,$user['password_hash']??''))vip_json_error('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง',401);
    }
    $u=$db['accounts'][$username];
    return ['db'=>$db,'result'=>['username'=>$username,'name'=>$u['name'],'balance'=>1500]];
});
session_regenerate_id(true);
$_SESSION['vip_member']=['username'=>$result['username'],'name'=>$result['name']];
echo json_encode(['ok'=>true,'user'=>$result],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
