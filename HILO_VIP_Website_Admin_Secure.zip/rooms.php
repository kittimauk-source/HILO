<?php
/** Live room coordination and PERMANENT admin-only audit; no payment/real-money account handling. */
declare(strict_types=1);
require __DIR__.'/vip_storage.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
$who=vip_require_member();
$req=vip_req();
$action=$req['action']??'';
if(!in_array($action,['create','join','poll','start','leave'],true))vip_json_error('ไม่รู้จักคำสั่ง');
$code=strtoupper(trim(is_string($req['code']??null)?$req['code']:''));
if($action!=='create'&&!preg_match('/^K[0-9]{5}$/D',$code))vip_json_error('รหัสห้องไม่ถูกต้อง');
$ticket=is_string($req['ticket']??null)?$req['ticket']:'';
$name=vip_clean_name($req['name']??$who['name'])?:$who['name'];
$preset=filter_var($req['preset']??0,FILTER_VALIDATE_INT);
if($preset===false||$preset<0||$preset>9)$preset=0;
$balance=filter_var($req['balance']??1500,FILTER_VALIDATE_INT);
if($balance===false||$balance<0||$balance>1000000000)$balance=1500;
function vip_ms():int {return (int)round(microtime(true)*1000);}
function vip_log(array &$db,string $event,string $code,int $now,string $username='',string $name='',array $extra=[]):void {
    $db['events'][]=array_merge(['at'=>$now,'event'=>$event,'room'=>$code,'username'=>$username,'name'=>$name],$extra);
}
function vip_dice(array $room,int $number):array {
    $dice=[];for($i=0;$i<3;$i++){$digest=hash_hmac('sha256',$number.'-'.$i,$room['secret'],true);
        $dice[]=(unpack('N',substr($digest,0,4))[1]%6)+1;}
    return $dice;
}
function vip_snapshot(array $room,string $ticket,int $now):array {
    $start=$room['startedAt'];$phase='lobby';$number=1;$phaseEnd=0;$dice=null;
    if(is_int($start)&&$start>0){
        $elapsed=max(0,$now-$start);$period=23000;$number=intdiv($elapsed,$period)+1;
        $within=$elapsed%$period;
        if($within<15000){$phase='betting';$phaseEnd=$start+($number-1)*$period+15000;}
        elseif($within<17000){$phase='shake';$phaseEnd=$start+($number-1)*$period+17000;}
        elseif($within<20000){$phase='announce';$phaseEnd=$start+($number-1)*$period+20000;}
        else{$phase='result';$phaseEnd=$start+$number*$period;}
        if($phase==='announce'||$phase==='result')$dice=vip_dice($room,$number);
    }
    return ['code'=>$room['code'],'myId'=>substr($ticket,0,12),'hostId'=>substr($room['host'],0,12),
        'players'=>array_map(static fn(array $p):array=>[
            'id'=>substr($p['ticket'],0,12),'name'=>$p['name'],'preset'=>$p['preset'],'balance'=>$p['balance']],array_values($room['players'])),
        'started'=>is_int($start)&&$start>0,'round'=>$number,'phase'=>$phase,
        'phaseEndsAt'=>$phaseEnd,'serverTime'=>$now,'dice'=>$dice];
}
$result=vip_locked('hilo-rooms-data.php',static function(array $db) use($action,$code,$ticket,$name,$preset,$balance,$who):array {
    $db['rooms']??=[];$db['archive']??=[];$db['events']??=[];
    $now=vip_ms();
    // Preserve pre-upgrade active rooms from the earlier ZIP, whose usernames were not server-verified.
    foreach($db['rooms'] as $oldCode=>&$oldRoom){
        if(!isset($oldRoom['archiveId'])){
            $aid=bin2hex(random_bytes(12));$oldRoom['archiveId']=$aid;
            $creator=null;
            foreach($oldRoom['players']??[] as $oldPlayer){
                if(($oldPlayer['ticket']??'')===($oldRoom['host']??'')){$creator=$oldPlayer;break;}
            }
            $creator??=$oldRoom['players'][0]??[];
            $joins=[];
            foreach($oldRoom['players']??[] as $oldPlayer){
                $joins[]=['username'=>'ก่อนอัปเกรดระบบ','name'=>$oldPlayer['name']??'ไม่ระบุ',
                    'joinedAt'=>$oldRoom['createdAt']??$now,'leftAt'=>null,
                    'ticketHash'=>hash('sha256',(string)($oldPlayer['ticket']??''))];
            }
            $db['archive'][$aid]=['recordId'=>$aid,'code'=>$oldCode,'createdBy'=>'ก่อนอัปเกรดระบบ',
                'creatorName'=>$creator['name']??'ไม่ระบุ','createdAt'=>$oldRoom['createdAt']??$now,
                'lastActivityAt'=>$now,'startedAt'=>$oldRoom['startedAt']??null,
                'hostUsername'=>'ก่อนอัปเกรดระบบ','status'=>'open','lastRound'=>0,
                'lastDice'=>null,'joins'=>$joins];
        }
    }unset($oldRoom);
    // Expired seats can no longer join a running room. Their history remains forever.
    foreach($db['rooms'] as $key=>&$room){
        $archiveId=$room['archiveId']??$key;
        foreach($room['players'] as $i=>$p){
            if(($p['lastSeen']??0)<$now-60000){
                vip_log($db,'DISCONNECTED',$key,$now,$p['username']??'', $p['name']??'');
                if(isset($db['archive'][$archiveId]['joins'])){
                    foreach($db['archive'][$archiveId]['joins'] as &$entry){
                        if(($entry['ticketHash']??'')===hash('sha256',$p['ticket'])&&empty($entry['leftAt'])){$entry['leftAt']=$now;break;}
                    }unset($entry);
                }
                unset($room['players'][$i]);
            }
        }
        $room['players']=array_values($room['players']);
        if(!$room['players']||($room['createdAt']??0)<$now-86400000){
            $db['archive'][$archiveId]['status']='closed';$db['archive'][$archiveId]['closedAt']=$now;
            vip_log($db,'ROOM_CLOSED',$key,$now);
            unset($db['rooms'][$key]);continue;
        }
        $tickets=array_column($room['players'],'ticket');
        if(!in_array($room['host'],$tickets,true)){
            $room['host']=$tickets[0];
            $db['archive'][$archiveId]['hostUsername']=$room['players'][0]['username'];
        }
    }unset($room);
    $codeNow=$code;$ticketNow=$ticket;
    if($action==='create'){
        do{$codeNow='K'.str_pad((string)random_int(0,99999),5,'0',STR_PAD_LEFT);}
        while(isset($db['rooms'][$codeNow]));
        $ticketNow=bin2hex(random_bytes(20));
        $archiveId=bin2hex(random_bytes(12));
        $p=['ticket'=>$ticketNow,'username'=>$who['username'],'name'=>$name,'preset'=>$preset,'balance'=>$balance,'lastSeen'=>$now];
        $db['rooms'][$codeNow]=['code'=>$codeNow,'host'=>$ticketNow,'createdAt'=>$now,
            'startedAt'=>null,'secret'=>bin2hex(random_bytes(32)),'archiveId'=>$archiveId,'players'=>[$p]];
        $db['archive'][$archiveId]=['code'=>$codeNow,'recordId'=>$archiveId,'createdBy'=>$who['username'],'creatorName'=>$name,
            'createdAt'=>$now,'lastActivityAt'=>$now,'startedAt'=>null,'hostUsername'=>$who['username'],
            'status'=>'open','lastRound'=>0,'lastDice'=>null,
            'joins'=>[['username'=>$who['username'],'name'=>$name,'joinedAt'=>$now,
                'leftAt'=>null,'ticketHash'=>hash('sha256',$ticketNow)]]];
        vip_log($db,'ROOM_CREATED',$codeNow,$now,$who['username'],$name);
    }elseif($action==='join'){
        if(!isset($db['rooms'][$codeNow]))vip_json_error('ไม่พบห้องนี้ ตรวจสอบรหัสอีกครั้ง',404);
        if(count($db['rooms'][$codeNow]['players'])>=5)vip_json_error('ห้องเต็มแล้ว (5/5 คน)',409);
        $archiveId=$db['rooms'][$codeNow]['archiveId']??$codeNow;
        $ticketNow=bin2hex(random_bytes(20));
        $db['rooms'][$codeNow]['players'][]=['ticket'=>$ticketNow,'username'=>$who['username'],
            'name'=>$name,'preset'=>$preset,'balance'=>$balance,'lastSeen'=>$now];
        $db['archive'][$archiveId]['joins'][]=['username'=>$who['username'],'name'=>$name,
            'joinedAt'=>$now,'leftAt'=>null,'ticketHash'=>hash('sha256',$ticketNow)];
        vip_log($db,'PLAYER_JOINED',$codeNow,$now,$who['username'],$name);
    }else{
        if(!isset($db['rooms'][$codeNow]))vip_json_error('ไม่พบห้องหรือห้องหมดอายุแล้ว',404);
        if(!preg_match('/^[a-f0-9]{40}$/D',$ticketNow))vip_json_error('ไม่มีสิทธิ์เข้าห้องนี้',403);
        $archiveId=$db['rooms'][$codeNow]['archiveId']??$codeNow;
        $found=-1;
        foreach($db['rooms'][$codeNow]['players'] as $i=>$p){
            if(hash_equals($p['ticket'],$ticketNow)&&($p['username']??'')===$who['username']){$found=$i;break;}
        }
        if($found<0)vip_json_error('ไม่มีสิทธิ์เข้าห้องนี้',403);
        if($action==='leave'){
            $p=$db['rooms'][$codeNow]['players'][$found];
            array_splice($db['rooms'][$codeNow]['players'],$found,1);
            foreach($db['archive'][$archiveId]['joins'] as &$entry){
                if(($entry['ticketHash']??'')===hash('sha256',$ticketNow)&&empty($entry['leftAt'])){$entry['leftAt']=$now;break;}
            }unset($entry);
            vip_log($db,'PLAYER_LEFT',$codeNow,$now,$p['username'],$p['name']);
            if(!$db['rooms'][$codeNow]['players']){
                $db['archive'][$archiveId]['status']='closed';$db['archive'][$archiveId]['closedAt']=$now;
                vip_log($db,'ROOM_CLOSED',$codeNow,$now);
                unset($db['rooms'][$codeNow]);
            }elseif($db['rooms'][$codeNow]['host']===$ticketNow){
                $db['rooms'][$codeNow]['host']=$db['rooms'][$codeNow]['players'][0]['ticket'];
                $db['archive'][$archiveId]['hostUsername']=$db['rooms'][$codeNow]['players'][0]['username'];
            }
        }else{
            $db['rooms'][$codeNow]['players'][$found]['lastSeen']=$now;
            if($action==='poll'){
                $db['rooms'][$codeNow]['players'][$found]['name']=$name;
                $db['rooms'][$codeNow]['players'][$found]['preset']=$preset;
                $db['rooms'][$codeNow]['players'][$found]['balance']=$balance;
            }
            if($action==='start'){
                if($db['rooms'][$codeNow]['host']!==$ticketNow)vip_json_error('เฉพาะ Host เท่านั้นที่เริ่มเกมได้',403);
                if(count($db['rooms'][$codeNow]['players'])<2)vip_json_error('ต้องมีผู้เล่นอย่างน้อย 2 คน',409);
                if($db['rooms'][$codeNow]['startedAt']===null){
                    $db['rooms'][$codeNow]['startedAt']=$now;
                    $db['archive'][$archiveId]['startedAt']=$now;
                    vip_log($db,'GAME_STARTED',$codeNow,$now,$who['username'],$name);
                }
            }
        }
    }
    if(isset($db['rooms'][$codeNow])){
        $room=$db['rooms'][$codeNow];
        $archiveId=$room['archiveId']??$codeNow;
        $db['archive'][$archiveId]['lastActivityAt']=$now;
        if(is_int($room['startedAt'])&&$room['startedAt']>0){
            $elapsed=$now-$room['startedAt'];
            $finished=$elapsed>=20000?intdiv($elapsed-20000,23000)+1:0;
            $last=(int)($db['archive'][$archiveId]['lastRound']??0);
            // Log result once per round, even after a client refresh. No automatic log deletion.
            for($r=$last+1;$r<=$finished;$r++){
                $dice=vip_dice($room,$r);
                $db['archive'][$archiveId]['lastRound']=$r;
                $db['archive'][$archiveId]['lastDice']=$dice;
                vip_log($db,'ROUND_RESULT',$codeNow,$room['startedAt']+($r-1)*23000+20000,'','',['round'=>$r,'dice'=>$dice]);
            }
        }
    }
    return ['db'=>$db,'result'=>['ok'=>true,'ticket'=>in_array($action,['create','join'],true)?$ticketNow:null,
        'room'=>isset($db['rooms'][$codeNow])?vip_snapshot($db['rooms'][$codeNow],$ticketNow,$now):null]];
});
echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
