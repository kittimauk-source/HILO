<?php
/** Private server dashboard. This page is not an embedded client-side admin preview. */
declare(strict_types=1);
require __DIR__.'/vip_storage.php';
vip_session();
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store, max-age=0');
header('Content-Security-Policy: frame-ancestors \'none\'');
$config=require __DIR__.'/admin-config.php';
$_SESSION['vip_admin_csrf']??=bin2hex(random_bytes(24));
$csrf=$_SESSION['vip_admin_csrf'];
$isAdmin=!empty($_SESSION['vip_is_admin']);
$error='';
if(($_SERVER['REQUEST_METHOD']??'')==='POST'){
    $type=$_POST['action']??'';
    if($type==='login'){
        $attempts=$_SESSION['vip_admin_failures']??0;$since=$_SESSION['vip_admin_failures_since']??0;
        if($since+900<time()){$attempts=0;$_SESSION['vip_admin_failures_since']=time();}
        if($attempts>=7){$error='ลองเข้าสู่ระบบอีกครั้งภายหลัง';}
        elseif(!hash_equals($csrf,(string)($_POST['csrf']??''))){$error='เซสชันไม่ถูกต้อง';}
        elseif(password_verify((string)($_POST['password']??''),(string)($config['password_hash']??''))){
            session_regenerate_id(true);
            $_SESSION['vip_is_admin']=true;
            $_SESSION['vip_admin_failures']=0;
            $_SESSION['vip_admin_csrf']=bin2hex(random_bytes(24));
            header('Location: admin.php');exit;
        }else{$_SESSION['vip_admin_failures']=$attempts+1;$error='รหัสผ่าน ADMIN ไม่ถูกต้อง';}
    }elseif($type==='logout'&&$isAdmin&&hash_equals($csrf,(string)($_POST['csrf']??''))){
        unset($_SESSION['vip_is_admin']);session_regenerate_id(true);header('Location: admin.php');exit;
    }
}
$isAdmin=!empty($_SESSION['vip_is_admin']);
if(!$isAdmin){
    header('Content-Type: text/html; charset=utf-8');
    ?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ADMIN — HILO VIP</title>
<style>*{box-sizing:border-box}body{min-height:100vh;margin:0;background:radial-gradient(circle at top,#243449,#060b17 70%);color:#f1e5c9;font-family:Tahoma,sans-serif;display:grid;place-items:center}.panel{width:min(440px,calc(100% - 24px));padding:32px;border:1px solid #c29b5f;border-radius:18px;background:#111b2bdc;box-shadow:0 15px 70px #0008}h1{font-size:25px;color:#f4d493}p{line-height:1.7;color:#c3cfdb;font-size:14px}input,button{display:block;width:100%;margin:14px 0;padding:14px;border-radius:8px;font:inherit}input{background:#090f1d;color:#fff;border:1px solid #7181a0}button{background:linear-gradient(#f1d391,#b27a37);border:0;color:#231b14;font-weight:bold;cursor:pointer}.error{color:#ff9999}</style></head><body><div class="panel"><h1>⚙ ระบบผู้ดูแล HILO VIP</h1><p>สำหรับผู้ดูแลเกมเท่านั้น ต้องใช้รหัสผ่าน ADMIN เพื่อดูข้อมูลผู้ใช้และห้องบนเซิร์ฟเวอร์</p><form method="post" autocomplete="off"><input type="hidden" name="action" value="login"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>"><label for="adminPass">รหัสผ่าน ADMIN</label><input id="adminPass" name="password" type="password" required autofocus autocomplete="current-password"><button type="submit">เข้าสู่ระบบ ADMIN</button></form><p class="error"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></p><a href="index.html" style="color:#f1d391">← กลับหน้าเกม</a></div></body></html>
<?php exit;}
// All data APIs and download paths below require the above server-verified Admin session.
if(($_GET['action']??'')==='data'||isset($_GET['download'])){
    $db=vip_locked('hilo-rooms-data.php',static fn(array $db):array=>['db'=>$db,'result'=>$db]);
    $accounts=vip_locked('hilo-accounts-data.php',static fn(array $db):array=>['db'=>$db,'result'=>$db['accounts']??[]]);
    $archive=array_values($db['archive']??[]);
    usort($archive,static fn($a,$b)=>($b['createdAt']??0)<=>($a['createdAt']??0));
    $active=$db['rooms']??[];
    $rooms=array_map(static function(array $r)use($active):array {
        $code=$r['code']??'';
        $joins=array_map(static fn(array $j):array=>[
            'username'=>$j['username']??'', 'name'=>$j['name']??'',
            'joinedAt'=>$j['joinedAt']??null,'leftAt'=>$j['leftAt']??null],$r['joins']??[]);
        $players=array_map(static fn(array $p):array=>[
            'username'=>$p['username']??'','name'=>$p['name']??'',
            'balance'=>$p['balance']??null,'lastSeen'=>$p['lastSeen']??null],$active[$code]['players']??[]);
        return ['recordId'=>$r['recordId']??$code,'code'=>$code,'createdBy'=>$r['createdBy']??'',
            'creatorName'=>$r['creatorName']??'', 'createdAt'=>$r['createdAt']??0,
            'startedAt'=>$r['startedAt']??null,'closedAt'=>$r['closedAt']??null,
            'lastActivityAt'=>$r['lastActivityAt']??0,'status'=>(isset($active[$code])&&($active[$code]['archiveId']??$code)===($r['recordId']??$code))?'open':'closed',
            'hostUsername'=>$r['hostUsername']??'', 'lastRound'=>$r['lastRound']??0,
            'lastDice'=>$r['lastDice']??null,'joins'=>$joins,'players'=>$players];
    },$archive);
    $events=array_values($db['events']??[]);
    $users=array_map(static fn(array $u):array=>[
        'username'=>$u['username']??'','name'=>$u['name']??'',
        'createdAt'=>$u['createdAt']??0],array_values($accounts));
    usort($users,static fn($a,$b)=>($b['createdAt']??0)<=>($a['createdAt']??0));
    $data=['ok'=>true,'rooms'=>$rooms,'accounts'=>$users,
        'totalEvents'=>count($events),'events'=>isset($_GET['download'])?$events:array_slice($events,-500)];
    header('Content-Type: application/json; charset=utf-8');
    if(isset($_GET['download'])){
        header('Content-Disposition: attachment; filename="hilo-admin-history-'.gmdate('Y-m-d').'.json"');
    }
    echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;
}
if(($_SERVER['REQUEST_METHOD']??'')==='POST'){
    $req=vip_req();
    if(($req['action']??'')!=='clear')vip_json_error('ไม่รู้จักคำสั่ง');
    if(!hash_equals($csrf,(string)($req['csrf']??'')))vip_json_error('สิทธิ์ยืนยันคำสั่งไม่ถูกต้อง',403);
    if(($req['confirmation']??'')!=='ล้างข้อมูลทั้งหมด')vip_json_error('ต้องพิมพ์คำยืนยันให้ตรง',400);
    vip_locked('hilo-rooms-data.php',static fn(array $db):array=>[
        'db'=>vip_data(),'result'=>true]);
    header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true]);exit;
}
header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HILO VIP — ADMIN Dashboard</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#070d1b;color:#e6effb;font-family:Tahoma,"Noto Sans Thai",sans-serif;font-size:14px}header{position:sticky;top:0;z-index:5;background:#101d33;border-bottom:1px solid #b69153;padding:16px clamp(12px,3vw,34px);display:flex;align-items:center;gap:15px;flex-wrap:wrap}h1{margin:0;color:#ffda96;font-size:24px}button,a{font:inherit}button{cursor:pointer}a{color:#ffda96}.wrap{max-width:1520px;margin:auto;padding:25px clamp(10px,2vw,30px)}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.stat,.section{background:#101b30;border:1px solid #294262;border-radius:13px;padding:16px}.stat label{display:block;font-size:12px;color:#afc0d4}.stat strong{display:block;font-size:27px;color:#ffdf9f;margin-top:8px}.section{margin-top:16px}h2{font-size:19px;color:#ffda96;margin:4px 0 14px}.filters{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.filters input{flex:1 1 220px}.filters button,.small{border:1px solid #a88458;background:#263850;color:#f6d9a1;border-radius:7px;padding:10px 12px}input{padding:10px;border:1px solid #526e8d;color:white;background:#0a1426;border-radius:8px;font:inherit}.scroll{overflow:auto;max-height:390px}table{border-collapse:collapse;width:100%;min-width:700px}th,td{border-bottom:1px solid #2b405a;padding:11px 10px;text-align:left;white-space:nowrap;font-size:12px}th{background:#142541;color:#e9c586;position:sticky;top:0}tr:hover td{background:#1a2b43}.detail{line-height:1.9;overflow-wrap:anywhere;color:#dce5ef}.chips{display:flex;gap:9px;flex-wrap:wrap}.chip{padding:7px 11px;border:1px solid #526786;border-radius:8px;background:#1b2e46}.danger{border-color:#a83e4b!important;color:#ffe4e3!important;background:#50222d!important}.danger-section{border-color:#803b45}.muted{font-size:12px;color:#aec0d2}.selected{outline:2px solid #ebca81}#msg{color:#efc889}.expand{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:800px){.stats{grid-template-columns:1fr 1fr}.expand{grid-template-columns:1fr}}@media(max-width:400px){.stats{grid-template-columns:1fr}}
</style></head><body>
<header><h1>⚙ ADMIN • HILO VIP</h1><span class="muted">ข้อมูลรวมจากเซิร์ฟเวอร์ • เฉพาะผู้ดูแล</span><div style="margin-left:auto;display:flex;gap:12px;align-items:center"><a href="index.html">กลับเกม</a><form method="post" style="margin:0"><input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf,ENT_QUOTES,'UTF-8')?>"><input type="hidden" name="action" value="logout"><button class="small" type="submit">ออกจาก ADMIN</button></form></div></header>
<main class="wrap"><div class="stats" id="stats"><div class="stat">กำลังอ่านข้อมูล…</div></div>
<div class="section"><h2>รายชื่อห้องทั้งหมด (รวมประวัติห้องที่ออกแล้ว)</h2><div class="filters"><input id="roomSearch" placeholder="ค้นหารหัสห้อง / เจ้าของ / ผู้เล่น"><button class="small" onclick="load()">รีเฟรชข้อมูล</button><a class="small" href="admin.php?download=1">ดาวน์โหลดประวัติทั้งหมด (.json)</a></div><p id="msg" class="muted"></p><div class="scroll"><table><thead><tr><th>รหัสห้อง</th><th>สร้างโดย (บัญชี)</th><th>ชื่อในเกม</th><th>เวลาสร้าง</th><th>สถานะ</th><th>จำนวนที่เคยเข้า</th><th>ผู้เล่นปัจจุบัน</th><th>รอบล่าสุด</th></tr></thead><tbody id="roomRows"></tbody></table></div></div>
<div class="expand"><div class="section"><h2>รายละเอียดห้องที่เลือก</h2><div id="roomDetail" class="detail">เลือกรหัสห้องจากตาราง</div></div><div class="section"><h2>สมาชิกที่สมัครทั้งหมด</h2><div class="scroll"><table><thead><tr><th>บัญชีผู้ใช้</th><th>ชื่อในเกม</th><th>สมัครเมื่อ</th></tr></thead><tbody id="accountRows"></tbody></table></div></div></div>
<div class="section"><h2>ประวัติกิจกรรมห้อง (500 เหตุการณ์ล่าสุด)</h2><div class="scroll"><table><thead><tr><th>วันเวลา</th><th>ห้อง</th><th>กิจกรรม</th><th>บัญชีผู้ใช้</th><th>ชื่อในเกม</th><th>รายละเอียด</th></tr></thead><tbody id="eventRows"></tbody></table></div><p class="muted">ประวัติเก่ากว่า 500 เหตุการณ์ยังเก็บอยู่ ไม่ถูกลบ ดาวน์โหลดข้อมูลทั้งหมดเพื่อดูครบทุกเหตุการณ์ • ไม่มีการลบอัตโนมัติ</p></div>
<div class="section danger-section"><h2>การจัดการข้อมูล</h2><p>ประวัติสร้างห้อง ผู้เข้าห้อง เวลาเข้า–ออก และผลแต่ละรอบจะถูกเก็บต่อไป แม้ปิดเว็บหรือห้องสิ้นสุด ระบบจะไม่ลบประวัติโดยอัตโนมัติ</p><p class="muted">การล้างจะลบข้อมูลห้องปัจจุบัน รายชื่อผู้เข้าร่วมห้อง และประวัติเหตุการณ์ห้องทั้งหมด (แต่ไม่ลบบัญชีสมาชิก) ผู้เล่นในห้องอาจต้องสร้างห้องใหม่</p><button type="button" id="clearBtn" class="small danger">ล้างข้อมูลห้องและประวัติทั้งหมด</button></div>
</main><script>
const csrf=<?=json_encode($csrf)?>;
let data={rooms:[],events:[],accounts:[]},selected='';
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const time=v=>v?new Date(v).toLocaleString('th-TH',{dateStyle:'medium',timeStyle:'medium'}):'—';
const eventName=e=>({ROOM_CREATED:'สร้างห้อง',PLAYER_JOINED:'เข้าห้อง',GAME_STARTED:'เริ่มเล่น',ROUND_RESULT:'ผลลูกเต๋า',PLAYER_LEFT:'ออกห้อง',DISCONNECTED:'ขาดการเชื่อมต่อ',ROOM_CLOSED:'ปิดห้อง',SOLO_ENTER:'เริ่มเล่นคนเดียว',SOLO_ROUND:'ผลเล่นคนเดียว',SOLO_EXIT:'ออกจากเกมเดี่ยว'})[e]||e;
async function load(){
 try{let r=await fetch('admin.php?action=data',{cache:'no-store'});if(r.status===401){location.reload();return;}const res=await r.json();if(!res.ok)throw Error(res.error||'โหลดไม่สำเร็จ');data=res;
  const open=data.rooms.filter(r=>r.status==='open').length;
  const cells=[['สมาชิกทั้งหมด',data.accounts.length],['ห้องกลุ่มที่เคยสร้าง',data.rooms.length],['ห้องกลุ่มที่ยังเปิด',open],['กิจกรรมสะสม (Solo/Group)',data.totalEvents]];
  $('stats').innerHTML=cells.map(([k,v])=>`<div class="stat"><label>${esc(k)}</label><strong>${esc(v)}</strong></div>`).join('');
  $('msg').textContent='อัปเดตล่าสุด '+new Date().toLocaleString('th-TH')+' • ประวัติทั้งหมดเก็บฝั่งเซิร์ฟเวอร์จนกว่า ADMIN จะล้าง';
  $('accountRows').innerHTML=data.accounts.map(a=>`<tr><td>${esc(a.username)}</td><td>${esc(a.name)}</td><td>${time(a.createdAt)}</td></tr>`).join('')||'<tr><td colspan="3">ยังไม่มีสมาชิก</td></tr>';
  $('eventRows').innerHTML=data.events.slice().reverse().map(e=>`<tr><td>${time(e.at)}</td><td>${esc(e.room)}</td><td>${esc(eventName(e.event))}</td><td>${esc(e.username)}</td><td>${esc(e.name)}</td><td>${esc(e.round?'รอบ '+e.round+' ลูกเต๋า '+(e.dice||[]).join('-')+(e.event==='SOLO_ROUND'?' • ลงชิป '+e.stake+' • จ่าย '+e.payout:''):'—')}</td></tr>`).join('')||'<tr><td colspan="6">ยังไม่มีกิจกรรม</td></tr>';
  rooms();
 }catch(e){$('msg').textContent='ไม่สามารถอ่านข้อมูล: '+e.message;}
}
function rooms(){const q=$('roomSearch').value.trim().toLowerCase();const list=data.rooms.filter(r=>[r.code,r.createdBy,r.creatorName,...r.joins.flatMap(j=>[j.username,j.name])].some(v=>String(v||'').toLowerCase().includes(q)));
 $('roomRows').innerHTML=list.map(r=>`<tr data-room="${esc(r.recordId)}" style="cursor:pointer"><td><b>${esc(r.code)}</b></td><td>${esc(r.createdBy)}</td><td>${esc(r.creatorName)}</td><td>${time(r.createdAt)}</td><td>${r.status==='open'?'เปิดอยู่':'ปิดแล้ว'}</td><td>${r.joins.length}</td><td>${r.players.length}</td><td>${r.lastRound}</td></tr>`).join('')||'<tr><td colspan="8">ไม่พบข้อมูล</td></tr>';
 $('roomRows').querySelectorAll('tr[data-room]').forEach(row=>{row.onclick=()=>{selected=row.dataset.room;rooms()}});
 const room=data.rooms.find(r=>r.recordId===selected)||list[0];if(room){selected=room.recordId;showRoom(room)}else $('roomDetail').textContent='ยังไม่มีห้อง';
 $('roomRows').querySelectorAll('tr[data-room]').forEach(row=>row.classList.toggle('selected',row.dataset.room===selected));
}
function showRoom(r){$('roomDetail').innerHTML=`<div class="chips"><span class="chip">${esc(r.code)}</span><span class="chip">${r.status==='open'?'กำลังใช้งาน':'ปิดแล้ว'}</span><span class="chip">รอบที่ ${esc(r.lastRound)}</span></div><p>ผู้สร้าง: <b>${esc(r.createdBy)}</b> (${esc(r.creatorName)})<br>Host ปัจจุบัน: ${esc(r.hostUsername)}<br>เวลาสร้าง: ${time(r.createdAt)}<br>เริ่มเกม: ${time(r.startedAt)}<br>ปิดห้อง: ${time(r.closedAt)}<br>กิจกรรมล่าสุด: ${time(r.lastActivityAt)}<br>ลูกเต๋าล่าสุด: ${esc(r.lastDice?.join(' - ')||'—')}</p><h3>รายชื่อผู้เล่นและเวลาเข้า–ออก</h3><div class="scroll"><table><thead><tr><th>บัญชี</th><th>ชื่อ</th><th>เข้า</th><th>ออก</th></tr></thead><tbody>${r.joins.map(j=>`<tr><td>${esc(j.username)}</td><td>${esc(j.name)}</td><td>${time(j.joinedAt)}</td><td>${time(j.leftAt)}</td></tr>`).join('')}</tbody></table></div><h3>ผู้เล่นที่ยังออนไลน์ (${r.players.length})</h3><div class="chips">${r.players.map(p=>`<span class="chip">${esc(p.username)} • ${esc(p.name)} • เงินเกม ${esc(p.balance)} • ${time(p.lastSeen)}</span>`).join('')||'ไม่มี'}</div>`;}
$('roomSearch').addEventListener('input',rooms);
$('clearBtn').onclick=async()=>{
 if(!confirm('คุณต้องการลบประวัติห้องและกิจกรรมทั้งหมดบนเซิร์ฟเวอร์หรือไม่? ข้อมูลจะกู้กลับไม่ได้ถ้าไม่มีสำรอง'))return;
 const confirmation=prompt('พิมพ์คำว่า ล้างข้อมูลทั้งหมด เพื่อยืนยัน');
 if(confirmation!=='ล้างข้อมูลทั้งหมด'){alert('ยกเลิก ไม่ได้ลบข้อมูล');return;}
 try{const r=await fetch('admin.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'clear',confirmation,csrf})});const p=await r.json();if(!r.ok||!p.ok)throw Error(p.error||'ลบไม่สำเร็จ');selected='';await load();alert('ล้างประวัติห้องและกิจกรรมเรียบร้อยแล้ว (บัญชีสมาชิกยังอยู่)');}
 catch(e){alert('ไม่สำเร็จ: '+e.message);}
};
load();
</script></body></html>
