<?php
/* Only PHP executes this file; never send its contents to clients. */
return ['password_hash' => '$2y$12$p.ARQIUTLLm1ivG2uIP9b.TO7Nq7hkliaYnlRKS3ZwqNQVLVplDdG'];
