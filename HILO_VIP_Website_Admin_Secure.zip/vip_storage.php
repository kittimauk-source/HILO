<?php
/** Same-host PHP storage and session utilities. Do not serve PHP files as plaintext. */
declare(strict_types=1);
header('X-Content-Type-Options: nosniff');
function vip_session(): void {
    if(session_status()===PHP_SESSION_ACTIVE)return;
    ini_set('session.use_strict_mode','1');
    ini_set('session.use_only_cookies','1');
    session_set_cookie_params(['lifetime'=>0,'path'=>rtrim(dirname($_SERVER['SCRIPT_NAME']??'/'),'/').'/',
        'secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),
        'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function vip_json_error(string $message, int $code=400): never {
    http_response_code($code);echo json_encode(['ok'=>false,'error'=>$message],JSON_UNESCAPED_UNICODE);exit;
}
function vip_locked(string $file, callable $fn): mixed {
    $handle=@fopen(__DIR__.'/'.$file,'c+');
    if(!$handle)vip_json_error('โฮสติ้งไม่อนุญาตให้บันทึกข้อมูล กรุณาตั้งสิทธิ์โฟลเดอร์ PHP',500);
    try{
        if(!flock($handle,LOCK_EX))vip_json_error('ไม่สามารถล็อกข้อมูล',500);
        $prefix="<?php http_response_code(404); exit; ?>\n";
        rewind($handle);$raw=stream_get_contents($handle);
        if($raw!==''&&!str_starts_with($raw,$prefix))vip_json_error('รูปแบบไฟล์จัดเก็บผิดพลาด',500);
        $db=$raw===''?[]:json_decode(substr($raw,strlen($prefix)),true);
        if(!is_array($db))vip_json_error('ข้อมูลจัดเก็บผิดพลาด',500);
        $out=$fn($db);
        if(!is_array($out)||!array_key_exists('db',$out))vip_json_error('ระบบบันทึกข้อมูลผิดพลาด',500);
        $packed=$prefix.json_encode($out['db'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR);
        rewind($handle);if(fwrite($handle,$packed)===false)vip_json_error('ไม่สามารถบันทึกข้อมูล',500);
        ftruncate($handle,strlen($packed));fflush($handle);
        return $out['result']??null;
    }finally{flock($handle,LOCK_UN);fclose($handle);}
}
function vip_data(): array {return ['rooms'=>[],'archive'=>[],'events'=>[]];}
function vip_require_member(): array {
    vip_session();$member=$_SESSION['vip_member']??null;
    if(!is_array($member)||!isset($member['username']))vip_json_error('กรุณาสมัครสมาชิกหรือเข้าสู่ระบบก่อน',401);
    return $member;
}
function vip_req(): array {
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')vip_json_error('ต้องใช้ POST',405);
    if(!str_starts_with(strtolower($_SERVER['CONTENT_TYPE']??''),'application/json'))vip_json_error('ข้อมูลต้องเป็น JSON',415);
    if((int)($_SERVER['CONTENT_LENGTH']??0)>8192)vip_json_error('ข้อมูลยาวเกินกำหนด',413);
    $body=json_decode(file_get_contents('php://input')?:'',true);
    if(!is_array($body))vip_json_error('รูปแบบคำขอไม่ถูกต้อง');
    return $body;
}
function vip_clean_name(mixed $name,int $max=24):string{
    if(!is_string($name))return '';
    $name=trim(preg_replace('/[\x00-\x1F\x7F<>]/u','',$name)??'');
    return function_exists('mb_substr')?mb_substr($name,0,$max,'UTF-8'):implode('',array_slice(preg_split('//u',$name,-1,PREG_SPLIT_NO_EMPTY)?:[],0,$max));
}
