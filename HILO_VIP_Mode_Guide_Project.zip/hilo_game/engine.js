'use strict';
const crypto = require('node:crypto');

// ตารางยอดเงินที่ได้รับรวมทุนคืนเมื่อชนะ ตามตัวเลขที่ผู้ใช้กำหนด (ไม่ใช่ตัวคูณ)
const PAYOUT_TABLE = Object.freeze(require('./payout-table.json'));
const CHIP_VALUES = Object.freeze([10,50,100,500]);
const CATEGORY_BY_BET = Object.freeze({
  '5low':'FIVE_LOW','6low':'SIX_LOW','11':'HILO_11',
  'low':'LOW_HIGH','high':'LOW_HIGH','123':'GROUP_123_456','456':'GROUP_123_456',
  'face1':'SINGLE','face2':'SINGLE','face3':'SINGLE','face4':'SINGLE','face5':'SINGLE','face6':'SINGLE',
  'combo-1':'ONE_LOW','combo-4':'THREE_LOW','combo-5':'FOUR_HIGH','combo-2':'SIX_HIGH',
  '4x1':'TWO_NUMBER','5x1':'TWO_NUMBER','6x1':'TWO_NUMBER',
  '4x2':'TWO_NUMBER','5x2':'TWO_NUMBER','6x2':'TWO_NUMBER',
  '5x3':'TWO_NUMBER','6x3':'TWO_NUMBER',
  'combo-3':'TWO_NUMBER','combo-6':'TWO_NUMBER','combo-7':'TWO_NUMBER','combo-8':'TWO_NUMBER','combo-9':'TWO_NUMBER'
});
// Compatibility export: a category map; settlement/guide use only PAYOUT_TABLE.
const PAYOUTS = PAYOUT_TABLE;
function payoutAmount(id, chipValue) {
  const category = CATEGORY_BY_BET[id];
  const money = PAYOUT_TABLE[String(chipValue)]?.[category];
  if (!category || !Number.isSafeInteger(money)) throw new Error('ไม่มีรายการค่าตอบแทนสำหรับช่องเดิมพัน/เหรียญนี้');
  return money;
}
function chipsForBet(player, id, total) {
  const values = player.betChips?.[id];
  if (Array.isArray(values) && values.length && values.every(v=>CHIP_VALUES.includes(v)) && sum(values)===total) return values;
  // Backward compatibility with historical sessions that stored only totals.
  let rest=total;const chunks=[];
  for(const denomination of [...CHIP_VALUES].reverse()){while(rest>=denomination){chunks.push(denomination);rest-=denomination;}}
  if(rest!==0)throw new Error('ยอดเดิมพันไม่ตรงกับเหรียญที่รองรับ');
  return chunks;
}
const BETS = Object.freeze([
  {id:'5low',label:'5 ต่ำ'}, {id:'11',label:'ไฮ 11 โล'}, {id:'6low',label:'6 ต่ำ'},
  {id:'4x1',label:'4•1'}, {id:'face1',label:'หน้า 1'}, {id:'low',label:'ต่ำ'},
  {id:'high',label:'สูง'}, {id:'face6',label:'หน้า 6'}, {id:'6x1',label:'6•1'},
  {id:'6x2',label:'6•2'}, {id:'face2',label:'หน้า 2'}, {id:'face3',label:'หน้า 3'},
  {id:'face4',label:'หน้า 4'}, {id:'face5',label:'หน้า 5'}, {id:'5x2',label:'5•2'},
  {id:'123',label:'123'}, {id:'6x3',label:'6•3'}, {id:'4x2',label:'4•2'},
  {id:'5x3',label:'5•3'}, {id:'5x1',label:'5•1'}, {id:'456',label:'456'},
  {id:'combo-1',label:'คู่ หน้า 1 + ต่ำ',a:'face1',b:'low'},
  {id:'combo-2',label:'คู่ สูง + หน้า 6',a:'high',b:'face6'},
  {id:'combo-3',label:'คู่ หน้า 1 + หน้า 2',a:'face1',b:'face2'},
  {id:'combo-4',label:'คู่ ต่ำ + หน้า 3',a:'low',b:'face3'},
  {id:'combo-5',label:'คู่ สูง + หน้า 4',a:'high',b:'face4'},
  {id:'combo-6',label:'คู่ หน้า 6 + หน้า 5',a:'face6',b:'face5'},
  {id:'combo-7',label:'คู่ หน้า 2 + หน้า 3',a:'face2',b:'face3'},
  {id:'combo-8',label:'คู่ หน้า 3 + หน้า 4',a:'face3',b:'face4'},
  {id:'combo-9',label:'คู่ หน้า 4 + หน้า 5',a:'face4',b:'face5'}
]);
const BET_BY_ID = new Map(BETS.map(b=>[b.id,b]));
const WHEEL = [20,20,30,30,50,50,100,'steal'];
const EMOJI = ['🦊','🐼','🐯','🐱','🐻','🐰','🦄','🐸','🐨','🐵','🦁','🐧','😀','😎','🤓','🥳','😺','🐶','🐮','🦋','🐺','🦖'];
const now = () => Date.now();
const BET_MS=15000, SHAKE_MS=1800, ANNOUNCE_MS=4200, RESULT_MS=3000;
const fail = (message, status=400) => { const e=new Error(message);e.status=status;throw e; };
const sum = vals => vals.reduce((a,b)=>a+b,0);
const die = () => crypto.randomInt(1,7);
const newToken = () => crypto.randomBytes(24).toString('hex');
function validateName(name) { const s=String(name||'').trim().slice(0,24);if(!s)fail('กรุณาระบุชื่อผู้เล่น'); return s; }
const CHIP_BORDERS=['#ffc247','#47b6ff','#ff7da5','#48e0a8','#c396ff','#ff8653','#bbef5a','#e858b5','#47d5d8','#f4f1f1','#8da4ff','#b6a16c'];
function nextColor(players){return CHIP_BORDERS.find(color=>!players.some(p=>p.chipBorderColor===color))||CHIP_BORDERS[0];}
function basePlayer(name, emoji, bot=false){ return {id:crypto.randomUUID(),token:bot?'':newToken(),name:validateName(name),emoji:EMOJI.includes(emoji)?emoji:'🦊',bot,balance:1500,bets:{},betChips:{},lastBetChips:{},chipBorderColor:'',locked:false,streak:0,spins:0,presses:0,missions:0,wheels:0,totalWon:0,totalLost:0,history:[],lastBet:{},pendingSteal:false,mic:false,online:!bot,joined:now(),avatar:'',quiz:null,quizEligible:false}; }
function betWon(id,dice){
  const b=BET_BY_ID.get(id);if(!b)return false;
  if(b.a)return betWon(b.a,dice)&&betWon(b.b,dice);
  const count=n=>dice.filter(v=>v===n).length;
  const total=sum(dice), triple=dice[0]===dice[1]&&dice[1]===dice[2];
  if(id==='5low')return total<=5;
  if(id==='6low')return total<=6;
  if(id==='11')return total===11;
  if(id==='low')return total>=3&&total<=10;
  if(id==='high')return total>=12&&total<=18;
  if(id==='123')return [...dice].sort().join('')==='123';
  if(id==='456')return [...dice].sort().join('')==='456';
  const exact=/^([456])x([123])$/.exec(id);if(exact)return count(+exact[1])>0&&count(+exact[2])>0;
  const face=/^face([1-6])$/.exec(id);if(face)return count(+face[1])>0;
  return false;
}
// Return gross payment for one chip, NOT a profit multiplier.
function payout(id,dice,chipValue=10){return betWon(id,dice)?payoutAmount(id,chipValue):0;}
function payoutForBet(player,id,total,dice){return betWon(id,dice)?sum(chipsForBet(player,id,total).map(value=>payoutAmount(id,value))):0;}
function publicPlayer(p){const {token,quiz,...safe}=p;return {...safe,bets:{...p.bets},betChips:Object.fromEntries(Object.entries(p.betChips||{}).map(([id,chips])=>[id,[...chips]])),lastBet:{...p.lastBet},history:p.history.slice(0,25)};}
class HiloEngine {
  constructor(opts={}){this.rooms=new Map();this.sessions=new Map();this.logs=[];this.events=[];this.version=1;this.clock=opts.clock||now;this.roll=opts.roll||(()=>[die(),die(),die()]);this.wheel=opts.wheel||(()=>crypto.randomInt(0,8));this.pendingDedupe=new Map();this.betRecords=[];}
  addRoom({mode='solo',name,emoji}){
    if(!['solo','group'].includes(mode))fail('ประเภทห้องไม่ถูกต้อง');
    const host=basePlayer(name,emoji), code=mode==='group'?this.code():`S${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    host.chipBorderColor=CHIP_BORDERS[0];
    const started=mode==='solo';
    const room={roomId:crypto.randomUUID(),code,mode,host:host.id,players:[host],phase:started?'betting':'lobby',round:started?1:0,
      roundId:started?`${code}:1`:null,deadline:started?this.clock()+BET_MS:0,
      bettingEndAt:started?this.clock()+BET_MS:0,shakeStartAt:0,revealAt:0,nextRoundAt:0,
      version:1,dice:null,results:[],diceHistory:[],messages:[],created:this.clock(),lastOutcome:null,botPlan:[],roundStartAt:started?this.clock():0,roundEndAt:0};
    if(mode==='solo')for(let i=1;i<=4;i++){const bot=basePlayer(`บอท ${i}`,EMOJI[i],true);bot.chipBorderColor=CHIP_BORDERS[i];room.players.push(bot);}
    this.rooms.set(code,room);this.sessions.set(host.token,{room:code,id:host.id});this.recordEvent(room,'ROOM_CREATED',host,{playerType:'HUMAN'});
    if(mode==='solo'){this.scheduleBots(room);this.recordEvent(room,'ROUND_START',host);this.recordEvent(room,'BETTING_START');}
    return {token:host.token,room:this.snapshot(room,host.id)};
  }
  recordEvent(r,type,p=null,details={}){
    const e={id:crypto.randomUUID(),type,at:this.clock(),room:r.code,roomId:r.roomId,roundId:r.roundId,mode:r.mode,accountId:p?.accountId||'',playerId:p?.id||'',name:p?.name||'',bot:p?.bot||false,balance:p?.balance??null,...details};
    this.events.unshift(e);
    if(type==='BET_PLACED'){this.betRecords.unshift({betId:e.betId||crypto.randomUUID(),timestamp:e.at,mode:r.mode,roomId:r.roomId,roomCode:r.code,roundId:r.roundId,playerId:p.id,accountId:p.accountId||'',playerName:p.name,username:'',playerType:p.bot?'BOT':'HUMAN',betType:e.betType||'',betArea:e.betArea||e.betType||'',chipValue:e.chipValue??e.amount,betAmount:e.amount,chipBorderColor:p.chipBorderColor,status:'OPEN',payout:0,netResult:0,balanceBefore:e.balanceBefore??p.balance+e.amount,balanceAfter:e.balanceAfter??p.balance});this.betRecords=this.betRecords.slice(0,30000);} 
    if(type==='BET_CLEARED'&&p){for(const b of this.betRecords)if(b.status==='OPEN'&&b.roomId===r.roomId&&b.roundId===r.roundId&&b.playerId===p.id)b.status='CANCELLED';}
    this.events=this.events.slice(0,5000);
  }
  code(){let code;do{code=String.fromCharCode(65+crypto.randomInt(26))+String(crypto.randomInt(0,100000)).padStart(5,'0')}while(this.rooms.has(code));return code;}
  joinRoom({code,name,emoji}){
    const room=this.rooms.get(String(code||'').trim().toUpperCase());if(!room||room.mode!=='group')fail('ไม่พบห้องนี้',404);
    if(room.players.filter(p=>!p.bot).length>=5)fail('ห้องเต็มแล้ว (สูงสุด 5 คน)');
    // ผู้เล่นใหม่เข้าห้องระหว่างรอบได้ โดยรับเวลาปัจจุบันของห้องเดิม ไม่เปิดรอบแยก
    const p=basePlayer(name,emoji);p.chipBorderColor=nextColor(room.players);room.players.push(p);this.sessions.set(p.token,{room:room.code,id:p.id});this.recordEvent(room,'PLAYER_JOINED',p);this.recordEvent(room,'ROOM_JOINED',p);
    return {token:p.token,room:this.snapshot(room,p.id)};
  }
  get(token){const s=this.sessions.get(token);if(!s)fail('เซสชันไม่ถูกต้อง กรุณาเข้าห้องใหม่',401);const r=this.rooms.get(s.room);const p=r?.players.find(p=>p.id===s.id);if(!p)fail('ไม่พบผู้เล่น',401);return {r,p};}
  snapshot(r,me=null){return {roomId:r.roomId||r.code,roomCode:r.code,roundId:r.roundId||`${r.code}:${r.round}`,version:r.version||1,serverTimestamp:this.clock(),bettingEndAt:r.bettingEndAt||0,shakeStartAt:r.shakeStartAt||0,revealAt:r.revealAt||0,nextRoundAt:r.nextRoundAt||0,code:r.code,mode:r.mode,host:r.host,phase:r.phase,round:r.round,deadline:r.deadline,dice:r.dice,results:r.results.slice(-10),lastOutcome:r.lastOutcome,diceHistory:(r.diceHistory||[]).map(entry=>({...entry,dice:[...entry.dice]})),players:r.players.map(publicPlayer),messages:r.messages.slice(-60),me,payoutTable:PAYOUT_TABLE,bets:BETS,wheel:WHEEL,serverTime:this.clock()};}
  scheduleBots(r){
    // เซิร์ฟเวอร์กำหนดเวลาวางเดิมพันบอทแต่ละตัวภายใน 15 วินาที
    // บอท 4 ตัวมีบุคลิกและขนาดชิปที่ต่างกันและใช้ยอดเงินจำกัด
    const styles=[{p:['low','high'],a:[10,50]},{p:['face1','face2','face3','face4','face5','face6'],a:[10,50,100]},
      {p:['123','456','6x2','5x2'],a:[10,50]},{p:['low','high','face3','face4'],a:[50,100,500]}];
    const start=r.bettingEndAt-BET_MS;
    r.botPlan=r.players.filter(p=>p.bot).map((p,i)=>({
      playerId:p.id,at:start+850+i*2300+crypto.randomInt(0,800),
      id:styles[i].p[crypto.randomInt(styles[i].p.length)],
      amount:styles[i].a[crypto.randomInt(styles[i].a.length)]
    }));
  }
  tickBots(r){
    let modified=false;
    if(r.mode!=='solo'||r.phase!=='betting')return modified;
    for(const plan of r.botPlan||[]){
      if(plan.done||this.clock()<plan.at||this.clock()>=r.bettingEndAt)continue;
      plan.done=true;const p=r.players.find(x=>x.id===plan.playerId);
      if(!p||p.balance<10)continue;
      const amount=Math.min(plan.amount,p.balance); // เฉพาะชิปมาตรฐาน
      const chip=[500,100,50,10].find(n=>n<=amount);
      if(!chip)continue;
      p.balance-=chip;p.bets[plan.id]=(p.bets[plan.id]||0)+chip;((p.betChips??={})[plan.id]??=[]).push(chip);p.locked=true;
      this.recordEvent(r,'BET_PLACED',p,{betId:crypto.randomUUID(),betType:plan.id,betArea:BET_BY_ID.get(plan.id).label,chipValue:chip,amount:chip,balanceBefore:p.balance+chip,balanceAfter:p.balance,chipBorderColor:p.chipBorderColor});
      modified=true;
    }
    return modified;
  }
  place(token,{id,amount}){const {r,p}=this.get(token);if(r.phase!=='betting'||p.locked)fail('ขณะนี้ไม่สามารถเพิ่มเดิมพันได้');
    if(!BET_BY_ID.has(id))fail('ช่องเดิมพันไม่ถูกต้อง');const n=Number(amount);if(![10,50,100,500].includes(n))fail('กรุณาเลือกชิป 10, 50, 100 หรือ 500');
    if(p.balance<n)fail('ยอดเงินจำลองไม่เพียงพอ');p.balance-=n;p.bets[id]=(p.bets[id]||0)+n;(p.betChips??={})[id]??=[];p.betChips[id].push(n);this.recordEvent(r,'BET_PLACED',p,{betId:crypto.randomUUID(),betType:id,betArea:BET_BY_ID.get(id).label,chipValue:n,amount:n,balanceBefore:p.balance+n,balanceAfter:p.balance,chipBorderColor:p.chipBorderColor});return this.snapshot(r,p.id);
  }
  clear(token){const {r,p}=this.get(token);if(r.phase!=='betting'||p.locked)fail('ตอนนี้ล้างเดิมพันไม่ได้');p.balance+=sum(Object.values(p.bets));p.bets={};p.betChips={};this.recordEvent(r,'BET_CLEARED',p);return this.snapshot(r,p.id);}
  double(token){const {r,p}=this.get(token);if(r.phase!=='betting'||p.locked)fail('ตอนนี้เพิ่มเดิมพันไม่ได้');const n=sum(Object.values(p.bets));if(!n)fail('กรุณาเลือกช่องเดิมพันก่อน');if(p.balance<n)fail('ยอดเงินจำลองไม่เพียงพอ');p.balance-=n;for(const [id,v]of Object.entries(p.bets)){p.bets[id]=v*2;const stack=p.betChips[id]||[v];p.betChips[id]=[...stack,...stack];}this.recordEvent(r,'BET_DOUBLED',p,{amount:n});for(const [bid,stack] of Object.entries(p.betChips)){for(const value of stack.slice(stack.length/2))this.recordEvent(r,'BET_PLACED',p,{betId:crypto.randomUUID(),betType:bid,betArea:BET_BY_ID.get(bid)?.label||bid,chipValue:value,amount:value,balanceAfter:p.balance});}return this.snapshot(r,p.id);}
  repeat(token){const {r,p}=this.get(token);if(r.phase!=='betting'||p.locked)fail('ตอนนี้แทงเท่าเดิมไม่ได้');const n=sum(Object.values(p.lastBet));if(!n)fail('ยังไม่มีเดิมพันจากรอบก่อน');if(sum(Object.values(p.bets)))fail('กรุณาล้างเดิมพันปัจจุบันก่อน');if(p.balance<n)fail('ยอดเงินจำลองไม่เพียงพอ');p.balance-=n;p.bets={...p.lastBet};p.betChips=Object.fromEntries(Object.entries(p.lastBetChips||{}).map(([id,stack])=>[id,[...stack]]));this.recordEvent(r,'BET_REPEATED',p,{amount:n});for(const [bid,stack] of Object.entries(p.betChips)){for(const value of stack)this.recordEvent(r,'BET_PLACED',p,{betId:crypto.randomUUID(),betType:bid,betArea:BET_BY_ID.get(bid)?.label||bid,chipValue:value,amount:value,balanceAfter:p.balance});}return this.snapshot(r,p.id);}
  lock(token){const {r,p}=this.get(token);if(r.phase!=='betting')fail('ยังไม่อยู่ในรอบเดิมพัน');if(!sum(Object.values(p.bets)))fail('กรุณาวางเดิมพันก่อน');p.locked=true;return this.snapshot(r,p.id);}
  start(token){const {r,p}=this.get(token);if(r.mode!=='group'||r.phase!=='lobby')fail('เกมเริ่มไปแล้ว');if(r.host!==p.id)fail('เฉพาะ Host เท่านั้นที่เริ่มเกมได้',403);if(r.players.length<2)fail('รอผู้เล่นอย่างน้อย 2 คน');this.next(r);return this.snapshot(r,p.id);}
  next(r){r.phase='betting';r.round++;r.roundId=`${r.code}:${r.round}`;r.bettingEndAt=this.clock()+BET_MS;r.deadline=r.bettingEndAt;r.shakeStartAt=0;r.revealAt=0;r.nextRoundAt=0;r.dice=null;r.lastOutcome=null;r.results=[];r.roundStartAt=this.clock();r.roundEndAt=0;for(const p of r.players){p.bets={};p.betChips={};p.locked=false;}if(r.mode==='solo')this.scheduleBots(r);this.recordEvent(r,'ROUND_START',r.players.find(p=>p.id===r.host));this.recordEvent(r,'BETTING_START');}
  settle(r,dice=this.roll()){
    if(!['betting','shake'].includes(r.phase))return false;if(!Array.isArray(dice)||dice.length!==3||dice.some(n=>!Number.isInteger(n)||n<1||n>6))fail('ผลลูกเต๋าไม่ถูกต้อง');
    r.dice=dice;r.results=[];for(const p of r.players){const chosen=Object.entries(p.bets),before=p.balance+sum(chosen.map(([,n])=>n));let gross=0,winning=0;
      for(const [id,amount] of chosen)if(betWon(id,dice)){gross+=payoutForBet(p,id,amount,dice);winning++;}
      p.balance+=gross;for(const b of this.betRecords){if(b.status!=='OPEN'||b.roundId!==r.roundId||b.roomId!==r.roomId||b.playerId!==p.id)continue;const win=betWon(b.betType,dice);b.status=win?'WON':'LOST';b.payout=win?payoutAmount(b.betType,b.chipValue):0;b.netResult=b.payout-b.betAmount;b.balanceAfter=p.balance;b.dice=[...dice];}if(!p.bot)p.quizEligible=p.balance<10;const net=gross-sum(chosen.map(([,n])=>n));if(net>=0)p.totalWon+=net;else p.totalLost+=-net;
      if(!p.bot){if(chosen.length&&winning===chosen.length){p.streak=Math.min(3,p.streak+1);if(p.streak===3&&!p.spins)p.spins=1;}else p.streak=0;}
      p.lastBet={...p.bets};p.lastBetChips=Object.fromEntries(Object.entries(p.betChips||{}).map(([id,stack])=>[id,[...stack]]));const rec={round:r.round,roundId:r.roundId,roomId:r.roomId,mode:r.mode,hostId:r.host,roundPlayers:r.players.length,at:this.clock(),player:p.name,playerId:p.id,accountId:p.accountId||'',room:r.code,dice:[...dice],chosen:chosen.map(([id,n])=>({id,label:BET_BY_ID.get(id).label,amount:n,won:betWon(id,dice),payout:payoutForBet(p,id,n,dice)})),before,net,after:p.balance,bot:p.bot,event:'settle'};
      p.history.unshift(rec);p.history=p.history.slice(0,50);r.results.push(rec);this.logs.unshift(rec);this.recordEvent(r,'ROUND_RESULT',p,{dice:[...dice],betAmount:sum(chosen.map(([,v])=>v)),netResult:net,payout:gross});
    }
    this.logs=this.logs.slice(0,5000);r.phase='announcing';r.deadline=this.clock()+ANNOUNCE_MS;r.nextRoundAt=r.deadline+RESULT_MS;r.lastOutcome={round:r.round,dice:[...dice],at:this.clock()};(r.diceHistory??=[]);if(r.diceHistory.length>1&&r.diceHistory[0].round>r.diceHistory[r.diceHistory.length-1].round)r.diceHistory.reverse();r.diceHistory.push({...r.lastOutcome,roundId:r.roundId,total:sum(dice),result:dice.every(n=>n===dice[0])?'ตอง':sum(dice)>=11&&sum(dice)<=17?'สูง':sum(dice)>=4&&sum(dice)<=10?'ต่ำ':'พิเศษ',timestamp:this.clock()});this.recordEvent(r,'DICE_RESULT',null,{dice:[...dice]});return true;
  }
  tick(){const affected=[];for(const r of this.rooms.values()){
    if(this.tickBots(r))affected.push(r.code);
    if(!r.deadline||this.clock()<r.deadline)continue;
    if(r.phase==='betting'){
      this.recordEvent(r,'BETTING_END');r.phase='shake';this.recordEvent(r,'DICE_SHAKE');r.shakeStartAt=r.bettingEndAt||r.deadline;r.revealAt=r.shakeStartAt+SHAKE_MS;r.deadline=r.revealAt;
      affected.push(r.code);
    }else if(r.phase==='shake'){
      this.settle(r);affected.push(r.code);
    }else if(r.phase==='announcing'){
      this.recordEvent(r,'ANNOUNCE_END');r.phase='result';r.deadline=this.clock()+RESULT_MS;r.nextRoundAt=r.deadline;affected.push(r.code);
    }else if(r.phase==='result'){
      this.recordEvent(r,'ROUND_END');r.roundEndAt=this.clock();this.next(r);affected.push(r.code);
    }
  }return affected;}
  quizPositionOrder(){const positions=[0,1,2,0,1];for(let i=positions.length-1;i>0;i--){const j=crypto.randomInt(i+1);[positions[i],positions[j]]=[positions[j],positions[i]];}return positions;}
  quizQuestion(token){const {r,p}=this.get(token);
    if(!p.quiz&&(p.balance>=10||!p.quizEligible))fail('แบบฝึกหัดเปิดหลังตัดสินผลเมื่อยอดเงินน้อยกว่า 10 บาทเท่านั้น');
    // หลังตัดสินผลเท่านั้นจึงเริ่มแบบฝึกหัดใหม่ได้
    if(!p.quiz&&r.phase==='shake')fail('กรุณารอการประกาศผลการเดิมพันก่อน');
    if(!p.quiz&&r.phase==='betting'&&Object.keys(p.bets).length)fail('กรุณารอผลการเดิมพันก่อน');
    if(!p.quiz){this.recordEvent(r,'EXERCISE_START',p);p.quiz={index:0,correctCount:0,questions:[],started:this.clock(),correctPositions:this.quizPositionOrder()};}
    const q=p.quiz;if(q.index>=5)fail('แบบฝึกหัดนี้เสร็จแล้ว');
    if(!q.questions[q.index]){
      const digits=3+crypto.randomInt(3),max=10**digits-1,min=10**(digits-1);
      const a=crypto.randomInt(min,max+1),b=crypto.randomInt(min,max+1);
      const add=q.index%2===0,answer=add?a+b:Math.max(a,b)-Math.min(a,b);
      const distractors=[];while(distractors.length<2){const candidate=Math.max(0,answer+crypto.randomInt(-200,201));if(candidate!==answer&&!distractors.includes(candidate))distractors.push(candidate);}
      const options=[...distractors];options.splice(q.correctPositions[q.index],0,answer);
      q.questions[q.index]={text:add?`${a.toLocaleString('th-TH')} + ${b.toLocaleString('th-TH')}`:`${Math.max(a,b).toLocaleString('th-TH')} − ${Math.min(a,b).toLocaleString('th-TH')}`,options,answer};
    }
    const current=q.questions[q.index];return {index:q.index+1,total:5,text:current.text,options:current.options,earned:q.correctCount*100};
  }
  quizAnswer(token,choice){const {r,p}=this.get(token);const q=p.quiz;if(!q||q.index>=5)fail('ยังไม่ได้เริ่มแบบฝึกหัด');const question=q.questions[q.index];if(!question)fail('กรุณาเรียกคำถามก่อน');
    if(!Number.isInteger(choice)||choice<0||choice>2)fail('ตัวเลือกไม่ถูกต้อง');
    const correct=question.options[choice]===question.answer;if(correct)q.correctCount++;this.recordEvent(r,'EXERCISE_ANSWER',p,{correct});q.index++;
    const finished=q.index===5,earned=finished?q.correctCount*100:0;
    if(finished){p.balance+=earned;if(earned>0)p.quizEligible=false;p.missions++;this.recordEvent(r,'EXERCISE_REWARD',p,{amount:earned,correct:q.correctCount,wrong:5-q.correctCount});this.events.unshift({type:'quiz',at:this.clock(),room:r.code,playerId:p.id,name:p.name,amount:earned});p.quiz=null;}
    // 0/5: เริ่มโจทย์ชุดใหม่ให้เฉพาะผู้เล่นนี้ทันที ไม่หยุดรอบของห้อง
    return {correct,finished,earned,retry:finished&&earned===0,next:(!finished||earned===0)?this.quizQuestion(token):null};
  }
  press(token,idempotencyKey){const {r,p}=this.get(token);
    if(typeof idempotencyKey!=='string'||idempotencyKey.length<12||idempotencyKey.length>120)fail('คำขอไม่ถูกต้อง');const key=`${p.id}:press:${idempotencyKey}`;if(this.pendingDedupe.has(key))return {...this.pendingDedupe.get(key),duplicate:true};
    if(p.balance>=50)fail('ภารกิจเปิดเมื่อยอดเงินต่ำกว่า 50 บาทเท่านั้น');
    p.presses++;let awarded=false;if(p.presses===20){p.balance+=50;p.missions++;p.presses=0;awarded=true;this.events.unshift({type:'mission',at:this.clock(),playerId:p.id,name:p.name,room:r.code,amount:50});}
    const result={progress:p.presses,awarded,balance:p.balance};this.pendingDedupe.set(key,result);if(this.pendingDedupe.size>20000)this.pendingDedupe.clear();return result;
  }
  spin(token,idempotencyKey){const {r,p}=this.get(token);if(typeof idempotencyKey!=='string'||idempotencyKey.length<12)fail('คำขอไม่ถูกต้อง');const key=`${p.id}:spin:${idempotencyKey}`;if(this.pendingDedupe.has(key))return this.pendingDedupe.get(key);
    if(!p.spins||p.pendingSteal)fail('ยังไม่มีสิทธิ์หมุนวงล้อ');p.spins--;p.streak=0;p.wheels++;const index=this.wheel();if(!Number.isInteger(index)||index<0||index>7)fail('วงล้อผิดพลาด');let reward=WHEEL[index];
    if(reward==='steal'){const targets=r.players.filter(x=>!x.bot&&x.id!==p.id&&x.balance>0);if(targets.length)p.pendingSteal=true;else{p.balance+=50;reward=50;}}
    else p.balance+=reward;
    const result={index,reward,balance:p.balance,pendingSteal:p.pendingSteal};this.events.unshift({type:'wheel',at:this.clock(),playerId:p.id,name:p.name,room:r.code,reward});this.pendingDedupe.set(key,result);return result;
  }
  steal(token,targetId){const {r,p}=this.get(token);if(!p.pendingSteal)fail('ไม่มีรางวัลขโมยเงินที่รอดำเนินการ');const target=r.players.find(x=>x.id===targetId&&x.id!==p.id&&!x.bot&&x.balance>0);
    if(!target)fail('ไม่สามารถเลือกผู้เล่นนี้ได้');const amount=Math.min(100,target.balance);target.balance-=amount;p.balance+=amount;p.pendingSteal=false;this.events.unshift({type:'steal',at:this.clock(),playerId:p.id,targetId:target.id,room:r.code,amount});return {amount,balance:p.balance};
  }
  chat(token,message){const {r,p}=this.get(token);const content=String(message||'').trim().slice(0,250);if(!content)fail('ข้อความว่างเปล่า');r.messages.push({id:crypto.randomUUID(),playerId:p.id,name:p.name,text:content,at:this.clock()});r.messages=r.messages.slice(-60);return this.snapshot(r,p.id);}
  mic(token,enabled){const {r,p}=this.get(token);p.mic=Boolean(enabled);return this.snapshot(r,p.id);}
  profile(token,{name,emoji,avatar,chipBorderColor}){const {r,p}=this.get(token);p.name=validateName(name);if(!EMOJI.includes(emoji))fail('รูปโปรไฟล์ไม่ถูกต้อง');p.emoji=emoji;if(avatar!==undefined){if(avatar&&!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(avatar))fail('รูปโปรไฟล์ไม่ถูกต้อง');if(avatar.length>110000)fail('ภาพมีขนาดใหญ่เกินไป');p.avatar=avatar;}if(chipBorderColor!==undefined){if(!CHIP_BORDERS.includes(chipBorderColor))fail('สีขอบเหรียญไม่ถูกต้อง');const used=r.players.some(x=>x.id!==p.id&&x.chipBorderColor===chipBorderColor);if(used){if(r.mode==='solo'){const other=r.players.find(x=>x.id!==p.id&&x.chipBorderColor===chipBorderColor);other.chipBorderColor=nextColor(r.players);}else p.chipBorderColor=nextColor(r.players);}if(!used||r.mode==='solo')p.chipBorderColor=chipBorderColor;}this.recordEvent(r,'PROFILE_UPDATED',p);return this.snapshot(r,p.id);}
  leave(token){const {r,p}=this.get(token);this.sessions.delete(token);this.recordEvent(r,'PLAYER_LEFT',p);r.players=r.players.filter(x=>x.id!==p.id);if(r.host===p.id){r.host=r.players.find(x=>!x.bot)?.id||null;}if(!r.players.some(x=>!x.bot))this.rooms.delete(r.code);return {room:r.code};}
  admin(){
    const rooms=[...this.rooms.values()],players=rooms.flatMap(r=>r.players.map(p=>({...p,roomCode:r.code,roomId:r.roomId,mode:r.mode,host:r.host===p.id})));
    return {players:players.filter(p=>!p.bot).length,online:players.filter(p=>!p.bot&&p.online).length,
      soloPlayers:players.filter(p=>!p.bot&&p.mode==='solo').length,groupPlayers:players.filter(p=>!p.bot&&p.mode==='group').length,
      roomDetails:rooms.map(r=>({roomId:r.roomId,roomCode:r.code,mode:r.mode,phase:r.phase,roundId:r.roundId,host:r.host,hostName:r.players.find(p=>p.id===r.host)?.name||'',players:r.players.filter(p=>!p.bot).length,total:r.players.length})),
      playerDetails:players.map(p=>({playerId:p.id,name:p.name,type:p.bot?'BOT':'HUMAN',balance:p.balance,mode:p.mode,roomId:p.roomId,roomCode:p.roomCode,host:p.host,online:p.online})),
      turnover:this.logs.reduce((a,x)=>a+x.chosen.reduce((b,c)=>b+c.amount,0),0),rooms:rooms.length,
      rounds:new Set(this.logs.map(x=>`${x.room}:${x.round}`)).size,
      won:this.logs.reduce((a,x)=>a+Math.max(0,x.net),0),lost:this.logs.reduce((a,x)=>a+Math.max(0,-x.net),0),
      wheels:this.events.filter(e=>e.type==='wheel').length,rewards:this.events.filter(e=>e.type==='wheel'||e.type==='mission'||e.type==='quiz').length,
      presses:this.events.filter(e=>e.type==='mission').length*20+players.reduce((a,p)=>a+p.presses,0),
      missions:this.events.filter(e=>e.type==='mission'||e.type==='quiz').map(e=>({at:e.at,player:e.name,room:e.room,amount:e.amount,type:e.type})),
      logs:this.logs.slice(0,1000),events:this.events.slice(0,1000)};
  }
}
module.exports={HiloEngine,BETS,PAYOUTS,PAYOUT_TABLE,CATEGORY_BY_BET,payoutAmount,payoutForBet,WHEEL,EMOJI,CHIP_BORDERS,betWon,payout};
