'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {HiloEngine}=require('../engine');
const rollFor=n=>[n%6+1,(n*2)%6+1,(n*3)%6+1];
test('เก็บสถิติห้องเดิมต่อเนื่อง 75 รอบโดยไม่ตัดเก่าและเรียงตามรอบ',()=>{
  let now=100000;const e=new HiloEngine({clock:()=>now});
  const a=e.addRoom({mode:'solo',name:'A'}),room=e.get(a.token).r;
  for(let i=1;i<=75;i++){
    const dice=rollFor(i);assert.equal(room.round,i);assert.equal(e.settle(room,dice),true);
    // repeated attempt to settle must not duplicate a round
    assert.equal(e.settle(room,dice),false);
    const entry=room.diceHistory[i-1];
    assert.equal(entry.round,i);assert.deepEqual(entry.dice,dice);
    assert.equal(entry.total,dice.reduce((a,b)=>a+b,0));
    assert.equal(entry.roundId,room.roundId);
    assert.ok(entry.timestamp>0);
    if(i<75){now+=9000;e.next(room);assert.equal(room.diceHistory.length,i);}
  }
  const history=e.snapshot(room,a.room.me).diceHistory;
  assert.equal(history.length,75);assert.deepEqual(history.map(x=>x.round),Array.from({length:75},(_,i)=>i+1));
  assert.deepEqual(history[0].dice,rollFor(1));assert.deepEqual(history[74].dice,rollFor(75));
});
test('ห้อง Group A/B แยกกัน และคนเข้าห้องทีหลังได้รับสถิติเดิมทั้งหมด',()=>{
  const e=new HiloEngine();
  const a=e.addRoom({mode:'group',name:'A'});e.joinRoom({code:a.room.code,name:'B'});e.start(a.token);
  const b=e.addRoom({mode:'group',name:'C'});e.joinRoom({code:b.room.code,name:'D'});e.start(b.token);
  const roomA=e.get(a.token).r,roomB=e.get(b.token).r;
  for(let i=1;i<=41;i++){e.settle(roomA,[1,2,3]);if(i<41)e.next(roomA);}
  for(let i=1;i<=3;i++){e.settle(roomB,[4,5,6]);if(i<3)e.next(roomB);}
  assert.equal(roomA.diceHistory.length,41);assert.equal(roomB.diceHistory.length,3);
  const newcomer=e.joinRoom({code:roomA.code.toLowerCase(),name:'Late join'});
  assert.equal(newcomer.room.diceHistory.length,41);
  assert.deepEqual(newcomer.room.diceHistory[0].dice,[1,2,3]);
  assert.equal(e.snapshot(roomB).diceHistory.length,3);
  // Both existing and newly joined players read the authoritative same history.
  assert.deepEqual(e.snapshot(roomA,a.room.me).diceHistory,e.snapshot(roomA,newcomer.room.me).diceHistory);
});
test('ข้อมูลเก่า newest-first ถูกเปลี่ยนเป็นลำดับเวลาเมื่อเติมรอบใหม่ โดยไม่สูญหาย',()=>{
  const e=new HiloEngine(),a=e.addRoom({mode:'solo',name:'A'}),room=e.get(a.token).r;
  room.diceHistory=[{round:3,dice:[3,3,3]},{round:2,dice:[2,2,2]},{round:1,dice:[1,1,1]}];
  room.round=4;room.roundId=`${room.code}:4`;e.settle(room,[4,4,4]);
  assert.deepEqual(room.diceHistory.map(v=>v.round),[1,2,3,4]);
  assert.equal(e.snapshot(room).diceHistory.length,4);
});
test('UI แสดงรายการทั้งหมดโดยเลื่อนเฉพาะกล่องสถิติ ไม่เปลี่ยนกระดาน',()=>{
 const client=fs.readFileSync(path.join(__dirname,'../public/client.js'),'utf8');
 const css=fs.readFileSync(path.join(__dirname,'../public/style.css'),'utf8');
 const preview=fs.readFileSync(path.join(__dirname,'../../HILO_VIP_Payout_Guide_Preview.html'),'utf8');
 assert.ok(client.includes('newestFirst.slice(1).forEach'));
 assert.ok(css.includes('#game #roundStats{height:auto;max-height:none;min-height:0;flex:1 1 auto;overflow:auto'));
 assert.ok(preview.includes('history.map((h,i)=>'));
 assert.equal(preview.includes('history=history.slice(0,9)'),false);
 assert.equal(preview.includes('history.slice(0,5)'),false);
});
test('ออกจากห้องกลุ่มแล้วกลับเข้ารหัสเดิม เห็นประวัติห้องที่ยังเปิดอยู่',()=>{
 const e=new HiloEngine();const host=e.addRoom({mode:'group',name:'Host'}),friend=e.joinRoom({code:host.room.code,name:'B'});
 e.start(host.token);const r=e.get(host.token).r;
 for(let i=0;i<6;i++){e.settle(r,[2,4,6]);if(i<5)e.next(r);}
 const oldRoomId=r.roomId,oldHistory=e.snapshot(r).diceHistory;
 e.leave(friend.token);
 const reconnect=e.joinRoom({code:r.code,name:'B returns'});
 assert.equal(reconnect.room.roomId,oldRoomId);
 assert.deepEqual(reconnect.room.diceHistory,oldHistory);
 assert.equal(reconnect.room.diceHistory.length,6);
});
