'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
const ROOT=path.resolve(__dirname,'..');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function port(){const netServer=net.createServer();await new Promise(ok=>netServer.listen(0,'127.0.0.1',ok));const p=netServer.address().port;await new Promise(ok=>netServer.close(ok));return p;}
async function boot(t){const p=await port(),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'hilo-accounts-')),db=path.join(tmp,'store.json');let child;
 const launch=async()=>{child=spawn(process.execPath,['server.js'],{cwd:ROOT,env:{...process.env,PORT:String(p),HILO_DATA_FILE:db},stdio:['ignore','ignore','pipe']});for(let i=0;i<100;i++){try{if((await fetch(`http://127.0.0.1:${p}/`)).ok)return;}catch{}await pause(30);}throw Error('server did not boot');};await launch();t.after(()=>{child.kill();fs.rmSync(tmp,{recursive:true,force:true});});return {url:`http://127.0.0.1:${p}`,db,restart:async()=>{child.kill();await new Promise(r=>child.once('exit',r));await launch();}};}
async function post(url,path,body,cookie='',roomToken=''){const response=await fetch(url+path,{method:'POST',headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...(roomToken?{Authorization:'Bearer '+roomToken}:{})},body:JSON.stringify(body)});return {status:response.status,data:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0]||cookie};}
test('บัญชีคงเงินหลัง Logout/Login และ Restart; client ส่ง balance ปลอมไม่สำเร็จ',async t=>{
 const s=await boot(t);let r=await post(s.url,'/api/auth/register',{username:'player_one',password:'correct-horse-123',name:'ผู้เล่นหนึ่ง'});assert.equal(r.status,200);assert.equal(r.data.user.balance,1500);const cookie=r.cookie;
 let room=await post(s.url,'/api/create',{mode:'solo',name:'ignored',balance:999999},cookie);assert.equal(room.status,200);assert.equal(room.data.room.players.find(p=>p.id===room.data.room.me).balance,1500);
 assert.equal((await post(s.url,'/api/command',{action:'place',id:'low',amount:100,balance:999999},cookie,room.data.token)).status,200);
 let me=await fetch(s.url+'/api/auth/me',{headers:{Cookie:cookie}}).then(x=>x.json());assert.equal(me.user.balance,1400);
 let wrong=await post(s.url,'/api/auth/login',{username:'player_one',password:'wrong-pass'});assert.equal(wrong.status,401);
 await post(s.url,'/api/auth/logout',{},cookie);const denied=await post(s.url,'/api/create',{mode:'solo'},cookie);assert.equal(denied.status,401);
 await s.restart();r=await post(s.url,'/api/auth/login',{username:'PLAYER_ONE',password:'correct-horse-123'});assert.equal(r.status,200);assert.equal(r.data.user.balance,1400);
 room=await post(s.url,'/api/create',{mode:'solo'},r.cookie);assert.equal(room.data.room.players.find(p=>p.id===room.data.room.me).balance,1400);
 const raw=fs.readFileSync(s.db,'utf8');assert.ok(!raw.includes('correct-horse-123'));
});
test('Admin ครบทั้งข้อมูลบัญชี เดิมพัน และ CSV ตามตัวกรอง',async t=>{
 const s=await boot(t),a=await post(s.url,'/api/auth/register',{username:'report-user',password:'SecurePassword1',name:'รายงาน'});let room=await post(s.url,'/api/create',{mode:'solo'},a.cookie);assert.equal(room.status,200);
 const placed=await post(s.url,'/api/command',{action:'place',id:'low',amount:50},a.cookie,room.data.token);assert.equal(placed.status,200);
 const adm=await post(s.url,'/api/admin/login',{code:'KiNaIs03'});assert.equal(adm.status,200);
 const h={Authorization:'Bearer '+adm.data.token},dash=await fetch(s.url+'/api/admin',{headers:h}).then(r=>r.json());
 assert.equal(dash.registered,1);assert.equal(dash.accountDetails[0].balance,1450);assert.ok(dash.betDetails.some(b=>b.status==='OPEN'&&b.betAmount===50));assert.ok(dash.ledger.some(x=>x.change===-50));
 const csv=await fetch(s.url+'/api/admin/csv?mode=solo&event=BET_PLACED',{headers:h});assert.equal(csv.status,200);let txt=await csv.text();assert.ok(txt.startsWith('timestamp'));
  const csvBytes=Buffer.from(await (await fetch(s.url+'/api/admin/csv',{headers:h})).arrayBuffer());assert.deepEqual([...csvBytes.subarray(0,3)],[239,187,191]);assert.match(txt,/bet_id,bet_type,bet_area/);assert.match(txt,/BET_PLACED/);
 const blank=await fetch(s.url+'/api/admin/csv?mode=group&event=BET_PLACED',{headers:h}).then(x=>x.text());assert.ok(!blank.includes('report-user'));
 const after=await fetch(s.url+'/api/admin',{headers:h}).then(r=>r.json());assert.equal(after.betDetails.length,dash.betDetails.length);
});
test('ข้อมูลโปรไฟล์รวมรูปภาพยังอยู่หลังออกจากห้อง',async t=>{
 const s=await boot(t),a=await post(s.url,'/api/auth/register',{username:'photo-user',password:'SecurePassword2',name:'คนก่อน'});const room=await post(s.url,'/api/create',{mode:'solo'},a.cookie);const avatar='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB';const update=await post(s.url,'/api/command',{action:'profile',name:'คนใหม่',emoji:'🐼',avatar},a.cookie,room.data.token);assert.equal(update.status,200);
 const left=await post(s.url,'/api/leave',{},a.cookie,room.data.token);assert.equal(left.status,200);const current=await fetch(s.url+'/api/auth/me',{headers:{Cookie:a.cookie}}).then(r=>r.json());assert.equal(current.user.name,'คนใหม่');assert.equal(current.user.avatar,avatar);
 const again=await post(s.url,'/api/create',{mode:'solo'},a.cookie);assert.equal(again.data.room.players[0].avatar,avatar);
});
test('ภาพกระดานและพิกัดเดิมพันยังคงเดิม 100%',()=>{
 const crypto=require('node:crypto');const img=fs.readFileSync(path.join(ROOT,'public/board-reference.jpg'));assert.equal(crypto.createHash('sha256').update(img).digest('hex'),'e439b0ae2e165a9942cf98be7b2a0fd6d9b0e2082d5cc846b7c1732d41cd5a28');
 const client=fs.readFileSync(path.join(ROOT,'public/client.js'),'utf8');assert.match(client,/const dimensions=\{width:701,height:392\}/);assert.match(client,/\['5low',14,23,214,51\]/);
});
test('รางวัลแบบฝึกหัดหลังเงินเป็นศูนย์ถูกบันทึกเข้าบัญชี และไม่ถูกรีเซ็ต',()=>{
 const {Accounts}=require('../accounts'),{HiloEngine}=require('../engine');
 const a=new Accounts(),reg=a.register({username:'quiz_persist',password:'testpassword777',name:'ฝึกเลข'});const account=a.get(reg.token),game=new HiloEngine();const data=game.addRoom({mode:'solo',name:'ฝึกเลข'});const {r,p}=game.get(data.token);a.attach(account,p);a.sync(game);
 for(let i=0;i<3;i++){
   game.place(data.token,{id:'low',amount:500});game.settle(r,[6,6,6]);a.sync(game);
   if(i<2)game.next(r);
 }
 assert.equal(account.balance,0);assert.equal(p.quizEligible,true);
 for(let i=0;i<5;i++){
   const q=game.quizQuestion(data.token);const cleaned=q.text.replaceAll(',','');const [lhs,rhs]=cleaned.split(/\s*[+−]\s*/).map(Number);const answer=cleaned.includes('−')?lhs-rhs:lhs+rhs;const idx=q.options.findIndex(x=>x===answer);const correctChoice=i===0?idx:(idx+1)%3;
   const result=game.quizAnswer(data.token,correctChoice);if(i===4)assert.equal(result.earned,100);
 }
 a.sync(game);assert.equal(account.balance,100);assert.equal(account.exerciseRewards,100);assert.equal(account.exerciseCount,1);
 const restored=new Accounts(a.serialize());assert.equal(restored.get(reg.token).balance,100);
});
