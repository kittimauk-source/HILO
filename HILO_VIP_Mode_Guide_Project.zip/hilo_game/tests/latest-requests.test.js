'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os'),net=require('node:net');
const {spawn}=require('node:child_process');
const {HiloEngine}=require('../engine');
const root=path.join(__dirname,'..');
test('ภาพกระดานต้นฉบับไม่เปลี่ยนแม้แต่น้อย',()=>{
 const image=fs.readFileSync(path.join(root,'public/board-reference.jpg'));
 assert.equal(crypto.createHash('sha256').update(image).digest('hex'),'e439b0ae2e165a9942cf98be7b2a0fd6d9b0e2082d5cc846b7c1732d41cd5a28');
});
test('รหัสห้อง Host รอในห้องก่อนเพื่อนเข้ามา และสีขอบชิปทุกคนไม่ซ้ำ',()=>{
 let time=Date.now();const g=new HiloEngine({clock:()=>time});
 const host=g.addRoom({mode:'group',name:'กิตติมา'});
 assert.match(host.room.code,/^[A-Z][0-9]{5}$/);
 assert.equal(host.room.phase,'lobby');assert.equal(host.room.players.length,1);
 assert.throws(()=>g.start(host.token),/รอผู้เล่น/);
 const friends=Array.from({length:4},(_,i)=>g.joinRoom({code:host.room.code.toLowerCase(),name:'เพื่อน'+i}));
 const players=g.get(host.token).r.players;
 assert.equal(new Set(players.map(p=>p.chipBorderColor)).size,5);
 assert.equal(g.start(host.token).phase,'betting');
 assert.throws(()=>g.start(friends[0].token),/เกมเริ่มไปแล้ว/);
 g.place(friends[0].token,{id:'low',amount:50});
 const result=g.snapshot(g.get(host.token).r,host.room.me);
 const placed=result.players.find(p=>p.id===friends[0].room.me);
 assert.equal(placed.betChips.low[0],50);assert.equal(placed.balance,1450);
});
test('เดิมพันแต่ละมูลค่าเก็บแยกเป็นเหรียญรายตัวและแสดงใน snapshot',()=>{
 const g=new HiloEngine(),p=g.addRoom({mode:'solo',name:'ผู้เล่น'});
 g.place(p.token,{id:'low',amount:10});g.place(p.token,{id:'low',amount:50});
 let me=g.get(p.token).p;
 assert.deepEqual(me.betChips.low,[10,50]);
 assert.equal(me.bets.low,60);
 g.clear(p.token);assert.equal(me.betChips.low,undefined);
});
test('ภาพหน้าเกมมีทางเข้า Admin และไม่มีปุ่มทดลองเสียง',()=>{
 const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
 const css=fs.readFileSync(path.join(root,'public/style.css'),'utf8');
 assert.doesNotMatch(html,/id="coverAdmin"/);assert.match(html,/id="adminButton"/);
 assert.doesNotMatch(html,/id="voiceTest"/);
 assert.match(css,/\.stake-cluster/);assert.match(css,/left:50%;top:50%;transform:translate\(-50%,-50%\)/);
 assert.match(css,/\.stake-coin-10/);assert.match(css,/\.stake-coin-500/);
});
async function freePort(){return new Promise((r,j)=>{const s=net.createServer();s.on('error',j);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>r(p));});});}
test('Admin SSE ส่งเหตุการณ์และยอดเดิมพันจริง พร้อม CSV ที่ไม่ล้างข้อมูล',async t=>{
 const port=await freePort(),dir=fs.mkdtempSync(path.join(os.tmpdir(),'hilo-last-'));
 const child=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),HILO_DATA_FILE:path.join(dir,'db.json')},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(dir,{recursive:true,force:true});});
 const base=`http://127.0.0.1:${port}`;for(let i=0;i<100;i++){try{if((await fetch(base+'/')).ok)break;}catch{}await new Promise(r=>setTimeout(r,25));}
 let userNum=0;const ownerTokens=new Map();let cookie='';
 const post=async(endpoint,body,token)=>{
   if(endpoint==='/api/create'||endpoint==='/api/join'){
      const auth=await fetch(base+'/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'test'+(++userNum)+'worker',password:'testSecret888',name:body.name})});assert.ok(auth.ok);cookie=auth.headers.get('set-cookie').split(';')[0];
   }
   const headers={'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...(endpoint==='/api/create'||endpoint==='/api/join'?{Cookie:cookie}:token&&ownerTokens.has(token)?{Cookie:ownerTokens.get(token)}:{})};
   const r=await fetch(base+endpoint,{method:'POST',headers,body:JSON.stringify(body)});assert.ok(r.ok,`${endpoint}: ${r.status}`);const data=await r.json();if(data.token&&(endpoint==='/api/create'||endpoint==='/api/join'))ownerTokens.set(data.token,cookie);return data;
 };
 const login=await post('/api/admin/login',{code:'KiNaIs03'});
 const abort=new AbortController();t.after(()=>abort.abort());
 const stream=await fetch(base+'/api/admin/events?token='+login.token,{signal:abort.signal});
 assert.equal(stream.status,200);
 assert.match(stream.headers.get('content-type'),/text\/event-stream/);
 const reader=stream.body.getReader();let raw='';
 async function until(pattern){while(!raw.includes(pattern)){const result=await reader.read();if(result.done)throw new Error('SSE ended');raw+=Buffer.from(result.value).toString('utf8');}raw='';}
 await until('dashboard');
 const room=await post('/api/create',{mode:'solo',name:'ทดสอบ'});
 await until('ROOM_CREATED');
 await post('/api/command',{action:'place',id:'low',amount:50},room.token);
 await until('BET_PLACED');
 const csv=await fetch(base+'/api/admin/csv',{headers:{Authorization:'Bearer '+login.token}});
 assert.equal(csv.status,200);assert.match(await csv.text(),/BET_PLACED/);
 const again=await fetch(base+'/api/admin',{headers:{Authorization:'Bearer '+login.token}});
 const data=await again.json();assert.ok(data.events.some(e=>e.type==='BET_PLACED'));
 await reader.cancel();
});
