'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const {HiloEngine,CHIP_BORDERS}=require('../engine');
function prepare(balance, resultDice=[6,6,6]){
 let now=100000;const engine=new HiloEngine({clock:()=>now,roll:()=>resultDice});
 const {token}=engine.addRoom({name:'ผู้เล่น',mode:'solo',emoji:'🦊'});
 const {r,p}=engine.get(token);p.balance=balance;
 return {engine,token,r,p,advance:ms=>now+=ms};
}
test('ยอดเงินหลัง settlement 0,3,9 ต้องเปิดชุดฝึก; 10 บาทไม่เปิด',()=>{
 for(const v of [0,3,9,10]){
  const {engine,token,r,p}=prepare(v);engine.settle(r,[6,6,6]);
  assert.equal(p.quizEligible,v<10,`balance ${v}`);
  if(v<10){const q=engine.quizQuestion(token);assert.equal(q.total,5);assert.equal(q.options.length,3);}
  else assert.throws(()=>engine.quizQuestion(token),/น้อยกว่า 10/);
 }
});
test('เงินชั่วคราว 0 แต่ชนะเดิมพัน ได้เงินกลับมา ไม่เปิดแบบฝึกหัด',()=>{
 const {engine,token,r,p}=prepare(10,[3,4,5]);
 engine.place(token,{id:'high',amount:10});assert.equal(p.balance,0);
 engine.settle(r,[3,4,5]);assert.ok(p.balance>=10);
 assert.equal(p.quizEligible,false);assert.throws(()=>engine.quizQuestion(token),/น้อยกว่า 10/);
});
test('สถิติ 3 ลูกแยกห้องและคงอยู่เมื่อเริ่มรอบใหม่',()=>{
 const e=new HiloEngine({clock:()=>200000});const a=e.addRoom({mode:'solo',name:'A'}),b=e.addRoom({mode:'solo',name:'B'});
 const r1=e.get(a.token).r,r2=e.get(b.token).r;
 e.settle(r1,[2,5,6]);e.settle(r2,[1,3,4]);
 assert.deepEqual(e.snapshot(r1).diceHistory[0].dice,[2,5,6]);
 assert.deepEqual(e.snapshot(r2).diceHistory[0].dice,[1,3,4]);
 e.next(r1);assert.deepEqual(e.snapshot(r1).diceHistory[0].dice,[2,5,6]);
});
test('ผู้เล่นเลือกสีและ Character ได้และใช้สีที่ไม่ซ้ำสมาชิกกลุ่ม',()=>{
 const e=new HiloEngine();const a=e.addRoom({mode:'group',name:'A'}),b=e.joinRoom({code:a.room.code,name:'B'});
 const ra=e.get(a.token).r,pa=e.get(a.token).p,pb=e.get(b.token).p;
 const desired=CHIP_BORDERS[2];e.profile(a.token,{name:'A',emoji:'😎',chipBorderColor:desired});
 assert.equal(pa.emoji,'😎');assert.equal(pa.chipBorderColor,desired);
 e.profile(b.token,{name:'B',emoji:'🐼',chipBorderColor:desired});
 assert.notEqual(pb.chipBorderColor,pa.chipBorderColor);assert.equal(new Set(ra.players.map(p=>p.chipBorderColor)).size,2);
});
test('ภาพกระดานและพิกัดจุดกดยังตรงต้นฉบับ',()=>{
 const css=fs.readFileSync(path.join(__dirname,'../public/style.css'),'utf8');
 const client=fs.readFileSync(path.join(__dirname,'../public/client.js'),'utf8');
 assert.ok(css.includes('.board{width:100%;aspect-ratio:701 / 392;'));
 assert.ok(client.includes('boardHotspots'));
 assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname,'../public/board-reference.jpg'))).digest('hex'),
 'e439b0ae2e165a9942cf98be7b2a0fd6d9b0e2082d5cc846b7c1732d41cd5a28');
});
