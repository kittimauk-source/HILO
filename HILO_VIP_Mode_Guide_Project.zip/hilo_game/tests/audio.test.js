'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const code=fs.readFileSync(path.join(__dirname,'../public/audio-core.js'),'utf8');
function setup(initialVoices=[{name:'Kanya',lang:'th-TH',localService:true}],enabled=true){
  const actions=[],callbacks={},notifications=[];
  let currentVoices=initialVoices;
  const synth={
    getVoices:()=>currentVoices,paused:false,
    addEventListener:(e,cb)=>callbacks[e]=cb,
    cancel:()=>actions.push({event:'cancel'}),
    resume:()=>actions.push({event:'resume'}),
    speak:u=>actions.push({event:'speak',text:u.text,voice:u.voice?.name||'system default',utterance:u})
  };
  class Utterance{constructor(text){this.text=text;}}
  const w={speechSynthesis:synth,SpeechSynthesisUtterance:Utterance,
    setTimeout:()=>0,addEventListener:()=>{},document:{addEventListener:()=>{}}};
  vm.runInNewContext(code,{window:w,globalThis:w});
  let room=null;const endEvents=[];
  const engine=w.HiloAudio.createHiloAudio({enabled,getRoom:()=>room,onSpeechEnd:key=>endEvents.push(key),notify:message=>notifications.push(message)});
  const setRoom=r=>{room=r;engine.handleRoom(r);};
  return {actions,notifications,synth,engine,setRoom,getRoom:()=>room,callbacks,setVoices:v=>{currentVoices=v;callbacks.voiceschanged?.();},endEvents};
}
const betting=(r='AB123',round=1)=>({roomId:r,roundId:`${r}:${round}`,round,phase:'betting',bettingEndAt:Date.now()+15000});
const announcement=(r='AB123',round=1)=>({roomId:r,roundId:`${r}:${round}`,round,phase:'announcing',deadline:Date.now()+4200,dice:[2,4,6]});
test('กดเริ่มปลดล็อก และเสียงหญิงไทยถูกเลือก ไม่ใช้ default เสียงผู้ชาย',()=>{
  const x=setup([{name:'Niwat',lang:'th-TH'},{name:'Kanya',lang:'th-TH'}]);
  x.setRoom(betting());assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,0);
  x.engine.unlock();x.setRoom(betting());
  const played=x.actions.filter(a=>a.event==='speak'&&a.text.trim());assert.equal(played.length,1);
  assert.equal(played[0].voice,'Kanya');assert.equal(played[0].text,'เริ่มเดิมพัน');
  x.setRoom(betting());assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,1);
});
test('รายชื่อเสียงโหลดช้า: ห้ามใช้ default ที่ไม่ทราบเพศ และคิวรอเสียงผู้หญิงไทย',()=>{
  const x=setup([]);x.engine.unlock();x.setRoom(betting());
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,0);
  x.setVoices([{name:'Microsoft Premwadee Online (Natural)',lang:'th-TH'}]);
  const played=x.actions.filter(a=>a.event==='speak'&&a.text.trim());
  assert.equal(played.length,1);assert.equal(played[0].voice,'Microsoft Premwadee Online (Natural)');
});
test('ประกาศลูกเต๋าแล้ว callback หลังเสียงจบ แต่ไม่ควบคุม server phase',()=>{
  const x=setup();x.engine.unlock();x.setRoom(betting());
  x.setRoom(announcement());const spoken=x.actions.filter(a=>a.event==='speak'&&a.text.trim());
  assert.equal(spoken.length,2);assert.match(spoken[1].text,/สอง สี่ หก รวม สิบสอง สูง/);
  spoken[1].utterance.onend();assert.equal(x.endEvents[0],'AB123|AB123:1|announcing');
  assert.equal(x.getRoom().phase,'announcing');
});
test('ปิดเสียงทันที แล้วเปิดกลับไม่พูดเหตุการณ์เก่าใหม่',()=>{
  const x=setup();x.engine.unlock();x.setRoom(betting());
  x.engine.setEnabled(false);x.setRoom(announcement());
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,1);
  x.engine.setEnabled(true);x.setRoom(announcement());
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,1);
  x.setRoom(betting('AB123',2));
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,2);
});
test('ผลของห้องอื่นไม่ถูกขานซ้ำ และต้องไม่เล่นจาก phase ที่หมดเวลาแล้ว',()=>{
  const x=setup();x.engine.unlock();x.setRoom(announcement('ROOM-A'));x.setRoom(announcement('ROOM-B'));
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,2);
  x.setRoom({...announcement('ROOM-B',2),deadline:Date.now()-1000});
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,2);
});
test('ไม่มีเสียงผู้หญิงไทย: ไม่สุ่มใช้เสียงผู้ชาย และแจ้งสาเหตุ',()=>{
  const x=setup([{name:'Niwat',lang:'th-TH'},{name:'Zira',lang:'en-US'}]);
  x.engine.unlock();x.setRoom(betting());
  assert.equal(x.actions.filter(a=>a.event==='speak'&&a.text.trim()).length,0);
  assert.ok(x.notifications.some(n=>n.includes('ไม่พบเสียงผู้หญิง')));
});
test('เสียงผู้หญิงหนึ่งตัวถูกตรึงตลอด session แม้ voiceschanged',()=>{
  const x=setup([{name:'Kanya',lang:'th-TH'}]);x.engine.unlock();x.setRoom(betting());
  x.setVoices([{name:'Premwadee',lang:'th-TH'},{name:'Niwat',lang:'th-TH'}]);
  x.setRoom(betting('AB123',2));
  const played=x.actions.filter(a=>a.event==='speak'&&a.text.trim());
  assert.equal(played.length,2);assert.ok(played.every(a=>a.voice==='Kanya'));
});
