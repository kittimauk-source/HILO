'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {HiloEngine,betWon,payout,BETS}=require('../engine');
function stub(){let t=1000000;const e=new HiloEngine({clock:()=>t,roll:()=>[1,2,3],wheel:()=>7});return {e,advance:ms=>t+=ms};}
function player(e,data){return e.get(data.token).p;}
test('กระดานประกอบด้วย 3 ช่องบน 18 ช่องหลัก และ 9 จุดกรอบเขียว',()=>{
 assert.equal(BETS.length,30);assert.equal(BETS.filter(b=>b.a).length,9);
});
test('ตรวจผลลูกเต๋า 3 ลูก เงื่อนไขต่ำ สูง หน้าลูกเต๋า และชุดตรง',()=>{
 assert.equal(betWon('123',[1,2,3]),true);assert.equal(betWon('456',[1,2,3]),false);
 assert.equal(betWon('low',[1,2,3]),true);assert.equal(betWon('high',[1,2,3]),false);
 assert.equal(betWon('face1',[1,1,3]),true);assert.equal(payout('face1',[1,1,3]),20);
 assert.equal(betWon('6x2',[6,6,2]),true);assert.equal(betWon('combo-3',[1,2,3]),true);
 assert.equal(betWon('low',[2,2,2]),true);
});
test('วางเดิมพัน หักยอดครั้งเดียว ล้างคืน และตัดสินได้/เสีย',()=>{
 const {e}=stub(),a=e.addRoom({mode:'solo',name:'ทดสอบ'}),p=player(e,a);
 e.place(a.token,{id:'123',amount:100});assert.equal(p.balance,1400);
 e.clear(a.token);assert.equal(p.balance,1500);
 e.place(a.token,{id:'123',amount:100});e.lock(a.token);e.settle(e.get(a.token).r,[1,2,3]);
 assert.equal(p.balance,2000);assert.equal(p.history[0].net,500);assert.equal(p.history[0].dice.length,3);
 assert.equal(p.streak,1);
});
test('ภารกิจกด 20 ครั้ง จ่ายครั้งเดียว รองรับคำขอซ้ำ และปิดภารกิจที่ 50 บาทขึ้นไป',()=>{
 const {e}=stub(),a=e.addRoom({mode:'solo',name:'ภารกิจ'}),p=player(e,a);
 p.balance=20;for(let i=0;i<19;i++){const r=e.press(a.token,`press-test-${i}-abc`);assert.equal(r.awarded,false);assert.equal(p.balance,20);}
 const r=e.press(a.token,'press-test-19-abc');assert.equal(r.awarded,true);assert.equal(p.balance,70);assert.equal(p.missions,1);
 const replay=e.press(a.token,'press-test-19-abc');assert.equal(replay.duplicate,true);assert.equal(p.balance,70);
 assert.throws(()=>e.press(a.token,'press-test-20-abc'),/ต่ำกว่า 50/);
});
test('ถูกติดต่อกัน 3 รอบ ได้สิทธิ์วงล้อ และรีเซ็ตเมื่อหมุน',()=>{
 const {e,advance}=stub(),a=e.addRoom({mode:'solo',name:'วงล้อ'}),r=e.get(a.token).r,p=player(e,a);
 for(let i=0;i<3;i++){e.place(a.token,{id:'face1',amount:10});e.settle(r,[1,2,3]);if(i<2){advance(1801);e.tick();advance(4201);e.tick();advance(3001);e.tick();}}
 assert.equal(p.streak,3);assert.equal(p.spins,1);
 const result=e.spin(a.token,'spin-test-123456');assert.equal(result.reward,50);assert.equal(p.streak,0);assert.equal(p.spins,0);
 assert.deepEqual(e.spin(a.token,'spin-test-123456'),result);assert.equal(p.pendingSteal,false);
});
test('รางวัลขโมย 100 บาท จำกัดเป้าหมายไม่ใช่บอท และไม่ทำให้ยอดติดลบ',()=>{
 const {e}=stub(),a=e.addRoom({mode:'group',name:'A'}),b=e.joinRoom({code:a.room.code,name:'B'}),p=player(e,a),q=player(e,b);
 q.balance=55;p.spins=1;const result=e.spin(a.token,'spin-steal-12345');assert.equal(result.reward,'steal');
 assert.throws(()=>e.steal(a.token,p.id),/ไม่สามารถ/);
 const transfer=e.steal(a.token,q.id);assert.equal(transfer.amount,55);assert.equal(q.balance,0);assert.equal(p.balance,1555);
 assert.throws(()=>e.steal(a.token,q.id),/ไม่มีรางวัล/);
});
test('Host เริ่มเกมเท่านั้น ห้องกลุ่มสูงสุด 5 คน และรอบถัดไปอัตโนมัติ',()=>{
 const {e,advance}=stub(),a=e.addRoom({mode:'group',name:'Host'}),code=a.room.code;
 const guests=['B','C','D','E'].map(name=>e.joinRoom({code,name}));assert.throws(()=>e.joinRoom({code,name:'F'}),/เต็ม/);
 assert.throws(()=>e.start(guests[0].token),/เฉพาะ Host/);e.start(a.token);
 const r=e.get(a.token).r;assert.equal(r.phase,'betting');assert.equal(r.round,1);
 advance(15001);e.tick();assert.equal(r.phase,'shake');
 advance(1801);e.tick();assert.equal(r.phase,'announcing');assert.equal(r.dice.length,3);
 advance(4201);e.tick();assert.equal(r.phase,'result');advance(3001);e.tick();assert.equal(r.phase,'betting');assert.equal(r.round,2);
});

test('เข้าร่วมห้องกลุ่มระหว่างรอบแล้วใช้ไทม์ไลน์เดิม ไม่สร้างรอบใหม่',()=>{
 const {e,advance}=stub(),host=e.addRoom({mode:'group',name:'Host'}),friend=e.joinRoom({code:host.room.code,name:'Friend'});e.start(host.token);
 const r=e.get(host.token).r;advance(7000);const newcomer=e.joinRoom({code:r.code,name:'Joined Mid Round'});
 assert.equal(newcomer.room.roundId,r.roundId);assert.equal(newcomer.room.bettingEndAt,r.bettingEndAt);assert.equal(newcomer.room.players.length,3);
});
test('แบบฝึกบวก–ลบ 5 ข้อ: ตรวจบนเซิร์ฟเวอร์และเพิ่มเงินถูกข้อละ 100 เพียงครั้งเดียว',()=>{
 const {e}=stub(),host=e.addRoom({mode:'solo',name:'Math'}),p=e.get(host.token).p;p.balance=0;p.quizEligible=true;
 let count=0;for(let i=0;i<5;i++){const q=e.quizQuestion(host.token);assert.equal(q.index,i+1);assert.equal(q.options.length,3);
 const solution=Function('return ('+q.text.replaceAll(',','').replace('−','-')+')')();const choice=q.options.indexOf(solution);
 assert.ok(choice>=0);const ans=e.quizAnswer(host.token,choice);assert.equal(ans.correct,true);count++;if(i===4){assert.equal(ans.finished,true);assert.equal(ans.earned,500);}}
 assert.equal(count,5);assert.equal(p.balance,500);assert.throws(()=>e.quizAnswer(host.token,0),/ยังไม่ได้/);
});

test('ห้องกลุ่ม: A12345, เข้ารหัสไม่สนใจตัวพิมพ์, รอ 2 คน และ Host เริ่มเท่านั้น',()=>{
 const {e}=stub(),a=e.addRoom({mode:'group',name:'เจ้าของห้อง'});assert.match(a.room.code,/^[A-Z][0-9]{5}$/);
 assert.throws(()=>e.start(a.token),/อย่างน้อย 2 คน/);
 const b=e.joinRoom({code:a.room.code.toLowerCase(),name:'เพื่อน'});
 assert.equal(b.room.players.length,2);assert.equal(e.get(b.token).r.code,a.room.code);
 assert.throws(()=>e.start(b.token),/เฉพาะ Host/);
 e.start(a.token);assert.equal(e.get(b.token).r.phase,'betting');
 const c=e.addRoom({mode:'group',name:'เจ้าของ B'});assert.notEqual(c.room.code,a.room.code);
 assert.equal(e.get(c.token).r.phase,'lobby');
});
test('บอท Solo ทั้ง 4 ทยอยเดิมพันภายใน 15 วินาที มีเงินจริงในเกมจำกัด และบันทึกผล BOT',()=>{
 const {e,advance}=stub(),a=e.addRoom({mode:'solo',name:'เจ้าของ'}),r=e.get(a.token).r;
 assert.equal(r.players.length,5);assert.equal(r.players.filter(p=>p.bot).length,4);
 assert.equal(r.players.filter(p=>p.bot).some(p=>Object.keys(p.bets).length),false);
 advance(1850);e.tick();assert.equal(r.players.filter(p=>p.bot&&Object.keys(p.bets).length).length,1);
 advance(10300);e.tick();assert.equal(r.players.filter(p=>p.bot&&Object.keys(p.bets).length).length,4);
 const before=r.players.slice(1).map(p=>p.balance);
 assert.ok(before.every(n=>n<1500&&n>=0));
 advance(3501);e.tick();assert.equal(r.phase,'shake');
 advance(1801);e.tick();assert.equal(r.phase,'announcing');
 assert.equal(e.logs.filter(x=>x.bot).length,4);
 assert.equal(e.admin().playerDetails.filter(x=>x.type==='BOT').length,4);
 assert.ok(r.players.slice(1).every(p=>p.balance>=0));
});
test('แบบฝึกหัดเปิดได้เฉพาะหลังตัดสินผลเมื่อเงิน 0 ชุดใหม่อัตโนมัติเมื่อผิดทั้งหมด และ A/B/C ไม่ซ้ำตำแหน่ง',()=>{
 const {e}=stub(),a=e.addRoom({mode:'solo',name:'Quiz'}),{r,p}=e.get(a.token);
 p.balance=0;assert.throws(()=>e.quizQuestion(a.token),/หลังตัดสินผล/);
 e.settle(r,[2,3,4]);assert.equal(r.phase,'announcing');assert.equal(p.quizEligible,true);
 const correctLocations=[];for(let i=0;i<5;i++){
   const q=e.quizQuestion(a.token);assert.equal(q.index,i+1);const nums=q.text.match(/[\d,]+/g).map(v=>Number(v.replaceAll(',','')));assert.ok(nums.every(n=>n>=100));
   const answer=q.text.includes('+')?nums[0]+nums[1]:nums[0]-nums[1];const k=q.options.indexOf(answer);
   correctLocations.push(k);assert.ok(k>=0);const wrong=[0,1,2].find(j=>j!==k);
   const out=e.quizAnswer(a.token,wrong);assert.equal(out.correct,false);
   if(i===4){assert.equal(out.finished,true);assert.equal(out.retry,true);assert.equal(out.earned,0);assert.equal(out.next.index,1);}
 }
 assert.equal(new Set(correctLocations).size,3);assert.equal(p.balance,0);
 let result;for(let i=0;i<5;i++){
  const q=e.quizQuestion(a.token);const nums=q.text.match(/[\d,]+/g).map(v=>Number(v.replaceAll(',',''))),ans=q.text.includes('+')?nums[0]+nums[1]:nums[0]-nums[1];
  result=e.quizAnswer(a.token,q.options.indexOf(ans));
 }
 assert.equal(result.earned,500);assert.equal(p.balance,500);assert.equal(p.quizEligible,false);
});
test('แก้ชื่อ รูป และเงินทุกคนซิงก์ผ่าน snapshot พร้อมแยกห้อง',()=>{
 const {e}=stub(),a=e.addRoom({mode:'group',name:'A'}),b=e.joinRoom({code:a.room.code,name:'B'});
 e.profile(b.token,{name:'กิตติมา',emoji:'🐻',avatar:'data:image/png;base64,YWJj'});
 const found=e.snapshot(e.get(a.token).r,a.room.me).players.find(p=>p.id===b.room.me);
 assert.equal(found.name,'กิตติมา');assert.match(found.avatar,/data:image/);
 e.start(a.token);e.place(b.token,{id:'high',amount:50});const snap=e.snapshot(e.get(a.token).r,a.room.me);
 assert.equal(snap.players.find(p=>p.id===b.room.me).balance,1450);
});
