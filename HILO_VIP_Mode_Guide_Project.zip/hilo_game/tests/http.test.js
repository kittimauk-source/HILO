'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
const root=path.join(__dirname,'..');
async function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const port=s.address().port;s.close(()=>resolve(port));});});}
async function boot(t){const port=await freePort(),dir=fs.mkdtempSync(path.join(os.tmpdir(),'hilo-test-')),db=path.join(dir,'game.json');
 const child=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),HILO_DATA_FILE:db},stdio:['ignore','pipe','pipe']});
 t.after(()=>{child.kill('SIGTERM');fs.rmSync(dir,{recursive:true,force:true});});
 const url=`http://127.0.0.1:${port}`;
 for(let i=0;i<50;i++){if(child.exitCode!==null)throw new Error('เซิร์ฟเวอร์หยุดก่อนเริ่ม');try{const r=await fetch(url+'/');if(r.ok)return {url,db};}catch{}await new Promise(r=>setTimeout(r,60));}
 throw new Error('เซิร์ฟเวอร์เริ่มไม่สำเร็จ');
}
const owners=new Map();let seq=0;
async function post(url,endpoint,body,token){let cookie='';if(endpoint==='/api/create'||endpoint==='/api/join'){const auth=await fetch(url+'/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'test-user-'+(++seq),password:'secret-pass-123',name:body.name||'ทดสอบ'})});assert.equal(auth.status,200);cookie=auth.headers.get('set-cookie').split(';')[0];}
  const r=await fetch(url+endpoint,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}) ,...(cookie||owners.get(token)?{Cookie:cookie||owners.get(token)}:{})},body:JSON.stringify(body)});const data=await r.json();if(data?.token&&(endpoint==='/api/create'||endpoint==='/api/join'))owners.set(data.token,cookie);return {status:r.status,data};}

test('หน้าเกมเสิร์ฟรูปกระดานต้นฉบับที่ตรงกับไฟล์ในโปรเจกต์',async t=>{
 const {url}=await boot(t);const image=await fetch(url+'/board-reference.jpg');assert.equal(image.status,200);assert.equal(image.headers.get('content-type'),'image/jpeg');
 const bytes=Buffer.from(await image.arrayBuffer());assert.deepEqual(bytes,fs.readFileSync(path.join(root,'public/board-reference.jpg')));
 const page=await fetch(url+'/');assert.match(await page.text(),/board-reference.jpg/);
});
test('สร้างห้อง เข้าห้องคนละเซสชัน Host เริ่มเกม และยอดเดิมพันซิงก์ผ่าน API',async t=>{
 const {url,db}=await boot(t),a=await post(url,'/api/create',{mode:'group',name:'Host',emoji:'🦊'});assert.equal(a.status,200);assert.match(a.data.room.code,/^[A-Z][0-9]{5}$/);
 const b=await post(url,'/api/join',{code:a.data.room.code,name:'Friend',emoji:'🐼'});assert.equal(b.status,200);
 const denied=await post(url,'/api/command',{action:'start'},b.data.token);assert.equal(denied.status,403);
 const started=await post(url,'/api/command',{action:'start'},a.data.token);assert.equal(started.status,200);
 const bet=await post(url,'/api/command',{action:'place',id:'low',amount:50},b.data.token);assert.equal(bet.status,200);
 const res=await fetch(url+'/api/session',{headers:{Authorization:'Bearer '+a.data.token,Cookie:owners.get(a.data.token)}}),data=await res.json();
 assert.equal(data.room.players.find(p=>p.id===b.data.room.me).bets.low,50);
 assert.equal(data.room.players.find(p=>p.id===b.data.room.me).balance,1450);
 assert.ok(fs.existsSync(db),'เขียนไฟล์ข้อมูลสำหรับกู้คืนหลัง refresh');
});
test('ป้องกันรหัส Admin ผิด และไม่ส่ง token ใน snapshot',async t=>{
 const {url}=await boot(t),a=await post(url,'/api/create',{mode:'solo',name:'A'});
 assert.equal(a.data.room.players[0].token,undefined);assert.equal((await post(url,'/api/admin/login',{code:'incorrect'})).status,401);
 const login=await post(url,'/api/admin/login',{code:'KiNaIs03'});assert.equal(login.status,200);
 const dashboard=await fetch(url+'/api/admin',{headers:{Authorization:'Bearer '+login.data.token}});assert.equal(dashboard.status,200);
});

test('ดาวน์โหลด CSV ภาษาไทยจากผู้ดูแล และโหลดภาพหน้าปกได้',async t=>{
 const {url}=await boot(t),a=await post(url,'/api/create',{mode:'solo',name:'คุณ'});
 const image=await fetch(url+'/cover.png');assert.equal(image.status,200);assert.equal(image.headers.get('content-type'),'image/png');
 const place=await post(url,'/api/command',{action:'place',id:'low',amount:10},a.data.token);assert.equal(place.status,200);
 const login=await post(url,'/api/admin/login',{code:'KiNaIs03'});const csv=await fetch(url+'/api/admin/csv',{headers:{Authorization:'Bearer '+login.data.token}});
 assert.equal(csv.status,200);assert.match(await csv.text(),/player_name|bet_type/);
});

test('SSE ส่งสถานะเข้าห้องและยอดเงินแบบเรียลไทม์ถึง Host คนละเซสชัน',async t=>{
 const {url}=await boot(t);
 const a=await post(url,'/api/create',{mode:'group',name:'เจ้าของ'});
 const abort=new AbortController();const timeout=setTimeout(()=>abort.abort(),5500);
 t.after(()=>{clearTimeout(timeout);abort.abort();});
 const conn=await fetch(url+'/api/events?token='+a.data.token,{signal:abort.signal});
 assert.equal(conn.status,200);assert.match(conn.headers.get('content-type'),/text\/event-stream/);
 const reader=conn.body.getReader();
 let raw='';
 async function until(check){while(!check(raw)){const chunk=await reader.read();if(chunk.done)throw new Error('SSE ถูกปิด');raw+=Buffer.from(chunk.value).toString('utf8');}return raw;}
 await until(v=>v.includes('"phase":"lobby"'));
 const b=await post(url,'/api/join',{code:a.data.room.code.toLowerCase(),name:'ผู้เล่นใหม่'});
 assert.equal(b.status,200);
 raw='';await until(v=>v.includes('ผู้เล่นใหม่')&&v.includes('"players"'));
 const start=await post(url,'/api/command',{action:'start'},a.data.token);assert.equal(start.status,200);
 raw='';await until(v=>v.includes('"phase":"betting"'));
 await post(url,'/api/command',{action:'place',id:'low',amount:50},b.data.token);
 raw='';await until(v=>v.includes('"balance":1450')&&v.includes('"low":50'));
 await reader.cancel();
});
