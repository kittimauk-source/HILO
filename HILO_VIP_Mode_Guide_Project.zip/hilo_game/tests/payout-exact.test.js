'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {HiloEngine, BETS, PAYOUT_TABLE, CATEGORY_BY_BET, betWon,payout,payoutAmount}=require('../engine');
const EXPECTED={
 10:[20,20,60,30,40,60,60,40,30,60,60],
 50:[100,100,300,150,200,300,300,200,150,300,300],
 100:[200,200,600,300,400,600,600,400,300,600,600],
 500:[1000,1000,3000,1500,2000,3000,3000,3000,2500,3000,3000]
};
const KEYS=['SINGLE','LOW_HIGH','TWO_NUMBER','ONE_LOW','THREE_LOW','FIVE_LOW','SIX_LOW','FOUR_HIGH','SIX_HIGH','GROUP_123_456','HILO_11'];
const representative={SINGLE:['face2',[2,4,6]],LOW_HIGH:['low',[1,2,3]],TWO_NUMBER:['5x2',[2,5,6]],ONE_LOW:['combo-1',[1,2,3]],THREE_LOW:['combo-4',[1,2,3]],FIVE_LOW:['5low',[1,1,3]],SIX_LOW:['6low',[1,2,3]],FOUR_HIGH:['combo-5',[4,4,4]],SIX_HIGH:['combo-2',[2,4,6]],GROUP_123_456:['123',[1,2,3]],HILO_11:['11',[1,4,6]]};
test('PAYOUT_TABLE 44 รายการตรงตัวเลขทุกตัวจากคำสั่ง รวมกรณี 500 บาทที่ไม่เป็นสัดส่วน',()=>{
 for(const [chip,amounts] of Object.entries(EXPECTED)){
  assert.deepEqual(Object.keys(PAYOUT_TABLE[chip]),KEYS);
  for(let i=0;i<KEYS.length;i++){
   const cat=KEYS[i], [betId,dice]=representative[cat];
   assert.equal(PAYOUT_TABLE[chip][cat],amounts[i],chip+' '+cat);
   assert.equal(betWon(betId,dice),true,betId);
   assert.equal(payout(betId,dice,Number(chip)),amounts[i],chip+' '+cat);
   assert.equal(payoutAmount(betId,Number(chip)),amounts[i],chip+' '+cat);
  }
 }
});
test('30 เดิมพันบนกระดานทุกช่องมีประเภทจ่าย และตรงกับตารางเดียวกัน',()=>{
 assert.equal(BETS.length,30);
 assert.deepEqual(new Set(BETS.map(b=>b.id)).size,30);
 for(const bet of BETS)assert.ok(KEYS.includes(CATEGORY_BY_BET[bet.id]),bet.id);
 const js=fs.readFileSync(path.join(__dirname,'../public/guide-data.js'),'utf8');
 const generated=JSON.parse(js.match(/window\.HILO_PAYOUT_TABLE=(.*?);/)[1]);
 assert.deepEqual(generated,PAYOUT_TABLE);
});
test('เงื่อนไขผลรวม ต่ำ 3–10 สูง 12–18 และ 11 ไฮโลแยกกัน',()=>{
 assert.equal(betWon('low',[1,1,1]),true);
 assert.equal(betWon('low',[3,3,4]),true);
 assert.equal(betWon('low',[2,3,6]),false);
 assert.equal(betWon('high',[2,4,6]),true);
 assert.equal(betWon('high',[6,6,6]),true);
 assert.equal(betWon('high',[1,4,6]),false);
 assert.equal(betWon('11',[1,4,6]),true);
 assert.equal(betWon('5x2',[5,5,5]),false);
 assert.equal(betWon('5x2',[5,2,6]),true);
});
test('เหรียญต่างมูลค่าในช่องเดียวคิดแยกเหรียญ ตามจำนวนจริง ไม่คูณยอดรวม',()=>{
 const e=new HiloEngine({clock:()=>1_000_000}),host=e.addRoom({mode:'solo',name:'คนเล่น'}),{r,p}=e.get(host.token);
 for(const c of [10,50,100,500])e.place(host.token,{id:'combo-5',amount:c});
 const before=1500-660;
 assert.equal(p.balance,before);
 assert.equal(e.settle(r,[4,4,4]),true);
 const payoutExpected=40+200+400+3000;
 assert.equal(p.balance,before+payoutExpected);
 assert.equal(p.history[0].chosen[0].payout,payoutExpected);
 assert.equal(p.history[0].net,payoutExpected-660);
 const betRecords=e.betRecords.filter(b=>b.playerId===p.id&&b.betType==='combo-5');
 assert.deepEqual(betRecords.map(b=>[b.chipValue,b.payout]).sort((a,b)=>a[0]-b[0]),[[10,40],[50,200],[100,400],[500,3000]]);
 assert.equal(e.logs.find(x=>x.playerId===p.id).net,payoutExpected-660);
 assert.equal(e.events.find(e=>e.type==='ROUND_RESULT'&&e.playerId===p.id).payout,payoutExpected);
});
test('เดิมพันถูก 100 บาท แทงเลขสองตัว รับเงิน 600 กำไรสุทธิ 500',()=>{
 const e=new HiloEngine({clock:()=>1_000_000}),host=e.addRoom({mode:'solo',name:'A'}),{r,p}=e.get(host.token);
 e.place(host.token,{id:'5x2',amount:100});e.settle(r,[2,5,6]);
 assert.equal(p.balance,2000);
 assert.equal(p.history[0].chosen[0].payout,600);
 assert.equal(p.history[0].net,500);
 assert.equal(e.betRecords.find(b=>b.playerId===p.id).payout,600);
 assert.equal(e.betRecords.find(b=>b.playerId===p.id).netResult,500);
});
test('คู่มือและพรีวิวอ้างอิงจำนวนเงินเดียวกัน ไม่เปลี่ยนพิกัดกระดาน',()=>{
 const preview=fs.readFileSync(path.join(__dirname,'../../HILO_VIP_Payout_Guide_Preview.html'),'utf8');
 const client=fs.readFileSync(path.join(__dirname,'../public/client.js'),'utf8');
 assert.ok(client.includes('window.HILO_PAYOUT_TABLE'));
 assert.ok(client.includes('data-guide-chip'));
 assert.ok(preview.includes('PREVIEW_PAYOUT_TABLE'));
 assert.ok(preview.includes('demo-rate-tab'));
 assert.ok(preview.includes('history.map((h,i)=>'));
});
test('ตรวจทุก 30 ช่อง x 4 มูลค่า (120 กรณี) พร้อมผลลูกเต๋าที่ชนะจริง',()=>{
 const all=[];for(let a=1;a<=6;a++)for(let b=1;b<=6;b++)for(let c=1;c<=6;c++)all.push([a,b,c]);
 for(const bet of BETS){
  const dice=all.find(d=>betWon(bet.id,d));
  assert.ok(dice,'หาชุดลูกเต๋าที่ชนะไม่พบ: '+bet.id);
  for(const chip of [10,50,100,500]){
   assert.equal(payout(bet.id,dice,chip),PAYOUT_TABLE[String(chip)][CATEGORY_BY_BET[bet.id]],`${bet.id} ${chip}`);
  }
 }
});
