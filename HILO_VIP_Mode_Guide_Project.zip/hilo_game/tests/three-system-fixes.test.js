'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const {HiloEngine}=require('../engine');
const root=path.join(__dirname,'..');
const get=rel=>fs.readFileSync(path.join(root,rel),'utf8');

test('ระบบเสียงไม่เลือก default หรือเสียงชาย และตรึง Voice ตัวเดียวตลอดเซสชัน',()=>{
  const js=get('public/audio-core.js');
  assert.match(js,/if\(!voice\)voice=voices\.find/);
  assert.match(js,/THAI\.test\(v\.lang\)&&FEMALE\.test\(v\.name\)&&!MALE\.test/);
  assert.match(js,/u\.lang='th-TH';u\.voice=voice/);
  assert.doesNotMatch(js,/voice=voices\.find\([^;]+\|\|voices\[0\]/);
});

test('หน้ากระดานรับคลิกและแสดงข้อมูลยืนยันจากเซิร์ฟเวอร์โดยไม่พึ่ง SSE เพียงอย่างเดียว',()=>{
  const js=get('public/client.js'),css=get('public/style.css');
  assert.match(js,/const next=response\?\.data/);
  assert.match(js,/state=next;offset=state\.serverTimestamp-Date\.now\(\);render\(\)/);
  assert.match(js,/Date\.now\(\)\+offset/);
  assert.match(css,/#boardHotspots>\.hotspot\{pointer-events:auto/);
  assert.match(css,/\.stake-cluster.*pointer-events:none!important/);
});

test('ทางเข้า Admin อยู่บนหน้าเลือกห้อง และมีฟอร์มแจ้งข้อผิดพลาด',()=>{
  const html=get('public/index.html'),js=get('public/client.js');
  const home=html.slice(html.indexOf('<main id="home"'),html.indexOf('<main id="game"'));
  assert.match(home,/id="adminButton"[^>]*>⚙ ADMIN/);
  assert.match(js,/\.className='admin-login-error'/);
  assert.match(js,/const info=await api\('\/api\/admin','GET',null,true\)/);
});

test('รอบใหม่เปิดเดิมพันได้อีกครั้ง และพรีวิวมีจุดกดเหมือนโครงการจริง',()=>{
  let clock=Date.now();const engine=new HiloEngine({clock:()=>clock});
  const created=engine.addRoom({mode:'solo',name:'ทดลอง'});let {r,p}=engine.get(created.token);
  p.locked=true;engine.next(r);assert.equal(r.phase,'betting');assert.equal(p.locked,false);
  assert.doesNotThrow(()=>engine.place(created.token,{id:'low',amount:10}));
  const js=get('public/client.js');
  const spots=js.match(/const spots=\[\n[\s\S]*?\n\];/)[0];
  const hash=require('node:crypto').createHash('sha256').update(spots).digest('hex');
  assert.equal(hash,'c75c2b87fc652ead9cb938b2bbc17b22a417296f6fec75065e49d061a808c4b0');
});
