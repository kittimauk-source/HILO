'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {HiloEngine,CHIP_BORDERS,EMOJI}=require('./engine');
const {Accounts}=require('./accounts');
const ROOT=path.join(__dirname,'public'),DB=process.env.HILO_DATA_FILE||path.join(__dirname,'hilo-data.json');
const PORT=Number(process.env.PORT||3000),ADMIN_CODE='KiNaIs03';
let game=new HiloEngine(),accounts=new Accounts();
const sockets=new Map(),admins=new Set(),adminSockets=new Set();
function restore(){try {const obj=JSON.parse(fs.readFileSync(DB,'utf8'));game.rooms=new Map(obj.rooms.map(r=>[r.code,r]));game.sessions=new Map(obj.sessions);game.logs=obj.logs||[];game.events=obj.events||[];game.pendingDedupe=new Map(obj.dedupe||[]);game.betRecords=obj.betRecords||[];accounts=new Accounts(obj.accounts||{});
  for(const room of game.rooms.values()){const borders=CHIP_BORDERS;room.diceHistory=Array.isArray(room.diceHistory)?room.diceHistory.sort((a,b)=>Number(a.round)-Number(b.round)):[];room.players.forEach((p,i)=>{p.online=false;if(!p.betChips)p.betChips={};if(!p.lastBetChips)p.lastBetChips={};if(!p.chipBorderColor||room.players.findIndex(x=>x.chipBorderColor===p.chipBorderColor)!==i)p.chipBorderColor=borders[i%borders.length];});}console.log('โหลดข้อมูลเกมแล้ว');
}catch(e){if(e.code!=='ENOENT')console.error('ไม่สามารถอ่านไฟล์ข้อมูล:',e.message);}}
restore();
function save(){accounts.sync(game);const data=JSON.stringify({accounts:accounts.serialize(),betRecords:game.betRecords,rooms:[...game.rooms.values()],sessions:[...game.sessions],logs:game.logs,events:game.events,dedupe:[...game.pendingDedupe]});const file=DB+'.tmp';fs.writeFileSync(file,data,{mode:0o600});fs.renameSync(file,DB);}
function json(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));}
async function readBody(req){let s='';for await(const chunk of req){s+=chunk;if(s.length>240000)throw Object.assign(new Error('ข้อมูลใหญ่เกินไป'),{status:413});}if(!s)return {};try{return JSON.parse(s)}catch{throw Object.assign(new Error('JSON ไม่ถูกต้อง'),{status:400});}}
const bearer=req=>String(req.headers.authorization||'').replace(/^Bearer\s+/i,'').trim();
const accountBearer=req=>{const c=String(req.headers.cookie||'').match(/(?:^|;\s*)hilo_session=([a-f0-9]{64})(?:;|$)/);return c?.[1]||String(req.headers['x-account-token']||'').trim();};
const cookie=(token,req)=>`hilo_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${req.socket.encrypted?'; Secure':''}`;
function accountAuth(req){return accounts.get(accountBearer(req));}
function validateOwnership(req){const u=accountAuth(req);const {p}=game.get(bearer(req));if(!p.accountId||p.accountId!==u.id)throw Object.assign(new Error('บัญชีไม่ตรงกับผู้เล่นในห้อง'),{status:403});return u;}
function resolveMemberColor(room,p){const others=room.players.filter(x=>x.id!==p.id),used=new Set(others.map(x=>x.chipBorderColor));if(!used.has(p.chipBorderColor))return;const spare=CHIP_BORDERS.find(c=>!used.has(c)&&c!==p.chipBorderColor);if(room.mode==='solo'){const bot=others.find(x=>x.bot&&x.chipBorderColor===p.chipBorderColor);if(bot&&spare){bot.chipBorderColor=spare;return;}}p.chipBorderColor=spare||p.chipBorderColor;}
function moveOut(u){for(const [key,session] of [...game.sessions]){const room=game.rooms.get(session.room),p=room?.players.find(x=>x.id===session.id);if(!p||p.accountId!==u.id)continue;accounts.sync(game);game.leave(key);notify(session.room);}}
function send(res,type,payload){if(res.destroyed||res.writableEnded)return;try{res.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`);}catch{}}
function pushRoom(code){for(const c of sockets.get(code)||[]){try{const {r,p}=game.get(c.token);send(c.res,'state',game.snapshot(r,p.id));}catch{send(c.res,'reset',{message:'เซสชันสิ้นสุด'});}}}
function pushAdmin(){if(adminSockets.size){const snapshot=adminData();for(const res of adminSockets)send(res,'dashboard',snapshot);}}
function notify(code){if(code){const room=game.rooms.get(code);if(room)room.version=(room.version||0)+1;if(sockets.has(code))pushRoom(code);}save();pushAdmin();}
function authAdmin(req){if(!admins.has(bearer(req)))throw Object.assign(new Error('กรุณาเข้าสู่ระบบผู้ดูแล'),{status:401});}
function adminData(){
 const base=game.admin(),users=[...accounts.users.values()].map(u=>accounts.public(u));
 const rooms=[...game.rooms.values()];const bets=game.betRecords.map(e=>({...e,name:e.playerName,at:e.timestamp,room:e.roomCode,username:accounts.users.get(e.accountId)?.username||''}));
 const diceRounds=game.events.filter(e=>e.type==='DICE_RESULT').map(e=>({...e,total:(e.dice||[]).reduce((a,b)=>a+b,0)}));
 const exercises=game.events.filter(e=>e.type.startsWith('EXERCISE_'));
 const turnover=bets.reduce((n,e)=>n+(e.status==='CANCELLED'?0:e.betAmount||0),0),payouts=game.events.filter(e=>e.type==='ROUND_RESULT').reduce((n,e)=>n+(e.payout||0),0);
 return {...base,rounds:accounts.globalStats.rounds,registered:users.length,online:users.filter(u=>u.online).length,soloOnline:base.playerDetails.filter(p=>p.online&&p.mode==='solo'&&p.type==='HUMAN').length,groupOnline:base.playerDetails.filter(p=>p.online&&p.mode==='group'&&p.type==='HUMAN').length,botCount:base.playerDetails.filter(p=>p.type==='BOT').length,playingRooms:rooms.filter(r=>r.phase!=='lobby').length,betCount:accounts.globalStats.bets,betTotal:accounts.globalStats.turnover,payoutTotal:accounts.globalStats.payout,houseNet:accounts.globalStats.turnover-accounts.globalStats.payout,moneyInSystem:users.reduce((n,u)=>n+u.balance,0)+rooms.reduce((n,r)=>n+r.players.filter(p=>p.bot).reduce((m,p)=>m+p.balance,0),0),zeroPlayers:users.filter(u=>u.balance<10).length,exerciseCount:exercises.filter(e=>e.type==='EXERCISE_START').length,exerciseCorrect:exercises.filter(e=>e.type==='EXERCISE_ANSWER'&&e.correct).length,exerciseWrong:exercises.filter(e=>e.type==='EXERCISE_ANSWER'&&!e.correct).length,
  accountDetails:users,betDetails:bets,diceDetails:diceRounds,ledger:accounts.ledger,exerciseDetails:exercises,events:[...base.events,...accounts.authEvents].sort((a,b)=>b.at-a.at).slice(0,1500),
  roomDetails:base.roomDetails.map(row=>{const r=rooms.find(x=>x.roomId===row.roomId);return {...row,created:r?.created||0,deadline:r?.deadline||0,bettingEndAt:r?.bettingEndAt||0,round:r?.round||0,memberNames:r?.players.filter(x=>!x.bot).map(x=>x.name)||[],roundStartAt:r?.roundStartAt||0,roundEndAt:r?.roundEndAt||0};})};
}
const routes={
 '/api/create':(req,b)=>{const u=accountAuth(req);moveOut(u);const data=game.addRoom({mode:b.mode,name:u.name,emoji:u.emoji});accounts.attach(u,game.get(data.token).p);resolveMemberColor(game.get(data.token).r,game.get(data.token).p);for(const e of game.events)if(e.playerId===game.get(data.token).p.id)e.accountId=u.id;data.room=game.snapshot(game.get(data.token).r,game.get(data.token).p.id);notify(data.room.code);return data;},
 '/api/join':(req,b)=>{const u=accountAuth(req);if(!game.rooms.has(String(b.code||'').trim().toUpperCase()))throw Object.assign(new Error('ไม่พบห้องนี้'),{status:404});moveOut(u);const data=game.joinRoom({code:b.code,name:u.name,emoji:u.emoji});accounts.attach(u,game.get(data.token).p);resolveMemberColor(game.get(data.token).r,game.get(data.token).p);for(const e of game.events)if(e.playerId===game.get(data.token).p.id)e.accountId=u.id;data.room=game.snapshot(game.get(data.token).r,game.get(data.token).p.id);notify(data.room.code);return data;},
 '/api/command':(req,b)=>{validateOwnership(req);const token=bearer(req),{r}=game.get(token);let data;switch(b.action){
  case 'place':data=game.place(token,b);break;case 'clear':data=game.clear(token);break;case 'double':data=game.double(token);break;case 'repeat':data=game.repeat(token);break;
  case 'lock':data=game.lock(token);break;case 'start':data=game.start(token);break;case 'press':data=game.press(token,b.requestId);break;
  case 'spin':data=game.spin(token,b.requestId);break;case 'steal':data=game.steal(token,b.targetId);break;case 'chat':data=game.chat(token,b.message);break;
  case 'quizQuestion':data=game.quizQuestion(token);break;case 'quizAnswer':data=game.quizAnswer(token,b.choice);break;case 'mic':data=game.mic(token,b.enabled);break;case 'profile':data=game.profile(token,b);break;default:throw Object.assign(new Error('คำสั่งไม่ถูกต้อง'),{status:400});}
  notify(r.code);return {ok:true,data};},
 '/api/leave':req=>{validateOwnership(req);const token=bearer(req),{r}=game.get(token);const code=r.code;game.leave(token);notify(code);return {ok:true};},
 '/api/auth/register':(req,b,res)=>{const data=accounts.register(b);res.setHeader('Set-Cookie',cookie(data.token,req));save();pushAdmin();return {user:data.user};},
 '/api/auth/login':(req,b,res)=>{const data=accounts.login(b);res.setHeader('Set-Cookie',cookie(data.token,req));save();pushAdmin();return {user:data.user};},
 '/api/auth/profile':(req,b)=>{const u=accountAuth(req);const name=String(b.name||'').trim();if(!name||name.length>24)throw Object.assign(new Error('ชื่อผู้เล่นต้องมี 1–24 ตัว'),{status:400});if(!EMOJI.includes(b.emoji))throw Object.assign(new Error('อิโมจิไม่ถูกต้อง'),{status:400});if(!CHIP_BORDERS.includes(b.chipBorderColor))throw Object.assign(new Error('สีขอบเหรียญไม่ถูกต้อง'),{status:400});if(b.avatar!==undefined&&(typeof b.avatar!=='string'||b.avatar.length>110000||(b.avatar&&!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(b.avatar))))throw Object.assign(new Error('รูปโปรไฟล์ไม่ถูกต้อง'),{status:400});u.name=name;u.emoji=b.emoji;u.chipBorderColor=b.chipBorderColor;if(b.avatar!==undefined)u.avatar=b.avatar;for(const room of game.rooms.values())for(const p of room.players)if(p.accountId===u.id){p.name=u.name;p.emoji=u.emoji;p.avatar=u.avatar;p.chipBorderColor=u.chipBorderColor;resolveMemberColor(room,p);u.chipBorderColor=p.chipBorderColor;game.recordEvent(room,'PROFILE_UPDATED',p);notify(room.code);}save();pushAdmin();return {user:accounts.public(u)};},
 '/api/auth/logout':(req,b,res)=>{accounts.logout(accountBearer(req));res.setHeader('Set-Cookie','hilo_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');save();return {ok:true};},
 '/api/admin/login':(req,b)=>{const a=Buffer.from(String(b.code||'')),c=Buffer.from(ADMIN_CODE);if(a.length!==c.length||!crypto.timingSafeEqual(a,c))throw Object.assign(new Error('รหัสผู้ดูแลไม่ถูกต้อง'),{status:401});const token=crypto.randomBytes(30).toString('hex');admins.add(token);return {token};},
 '/api/admin/reset':req=>{authAdmin(req);for(const list of sockets.values())for(const s of list)send(s.res,'reset',{message:'ผู้ดูแลรีเซ็ตข้อมูลเกม'});game=new HiloEngine();save();pushAdmin();return {ok:true};}
};
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try {
    if(req.method==='GET'&&url.pathname==='/api/admin/events'){
      if(!admins.has(url.searchParams.get('token')||''))return json(res,401,{error:'ไม่ได้รับอนุญาต'});
      res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-store, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
      adminSockets.add(res);send(res,'dashboard',adminData());
      const heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': live\n\n');},18000);
      req.on('close',()=>{clearInterval(heartbeat);adminSockets.delete(res);});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/events'){
      const token=url.searchParams.get('token')||'';const {r,p}=game.get(token);res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
      const client={res,token,id:p.id};if(!sockets.has(r.code))sockets.set(r.code,new Set());sockets.get(r.code).add(client);p.online=true;send(res,'state',game.snapshot(r,p.id));pushRoom(r.code);
      const heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': keepalive\n\n')},20000);
      req.on('close',()=>{clearInterval(heartbeat);sockets.get(r.code)?.delete(client);if(![...(sockets.get(r.code)||[])].some(c=>c.id===p.id)){p.online=false;pushRoom(r.code);save();pushAdmin();}});
      return;
    }
    if(req.method==='GET'&&url.pathname==='/api/auth/me'){const u=accountAuth(req);return json(res,200,{user:accounts.public(u)});}
    if(req.method==='GET'&&url.pathname==='/api/session'){validateOwnership(req);const {r,p}=game.get(bearer(req));return json(res,200,{room:game.snapshot(r,p.id)});}
    if(req.method==='GET'&&url.pathname==='/api/admin'){authAdmin(req);return json(res,200,adminData());}
    if(req.method==='GET'&&url.pathname==='/api/admin/csv'){
      authAdmin(req);
      const columns=['timestamp','event','mode','room_code','room_id','round_id','player_id','username','player_name','player_type','bet_id','bet_type','bet_area','bet_status','chip_value','bet_amount','dice_1','dice_2','dice_3','dice_total','payout','net_result','balance_before','balance_after','exercise_correct','exercise_wrong','online_status'];
      const info=adminData(),records=[];
      for(const e of game.events){const d=e.dice||[],account=accounts.users.get(e.accountId);
        records.push({timestamp:new Date(e.at).toISOString(),event:e.type,mode:e.mode||'',room_code:e.room||'',room_id:e.roomId||'',round_id:e.roundId||'',player_id:e.playerId||'',username:account?.username||'',player_name:e.name||'',player_type:e.bot?'BOT':e.playerId?'HUMAN':'SYSTEM',bet_id:e.betId||'',bet_type:e.betType||'',bet_area:e.betArea||'',chip_value:e.chipValue??'',bet_amount:e.betAmount??e.amount??'',dice_1:d[0]??'',dice_2:d[1]??'',dice_3:d[2]??'',dice_total:d.length?d.reduce((a,b)=>a+b,0):'',payout:e.payout??'',net_result:e.netResult??'',balance_before:e.balanceBefore??'',balance_after:e.balanceAfter??e.balance??'',exercise_correct:e.type==='EXERCISE_ANSWER'?Number(Boolean(e.correct)):'',exercise_wrong:e.type==='EXERCISE_ANSWER'?Number(!e.correct):'',online_status:account?.online?'ONLINE':'OFFLINE'});
      }
      for(const b of game.betRecords){records.push({timestamp:new Date(b.timestamp).toISOString(),event:'BET_SETTLED',mode:b.mode,room_code:b.roomCode,room_id:b.roomId,round_id:b.roundId,player_id:b.playerId,username:accounts.users.get(b.accountId)?.username||'',player_name:b.playerName,player_type:b.playerType,bet_id:b.betId,bet_type:b.betType,bet_area:b.betArea,bet_status:b.status,chip_value:b.chipValue,bet_amount:b.betAmount,dice_1:b.dice?.[0]??'',dice_2:b.dice?.[1]??'',dice_3:b.dice?.[2]??'',dice_total:b.dice?.reduce((a,v)=>a+v,0)??'',payout:b.payout,net_result:b.netResult,balance_before:b.balanceBefore,balance_after:b.balanceAfter});}
      for(const u of accounts.users.values()){records.push({timestamp:new Date(u.lastLoginAt||u.registeredAt).toISOString(),event:'ACCOUNT_SNAPSHOT',player_id:u.id,username:u.username,player_name:u.name,player_type:'HUMAN',balance_after:u.balance,online_status:u.online?'ONLINE':'OFFLINE'});}
      for(const room of game.rooms.values()){records.push({timestamp:new Date(room.created).toISOString(),event:'ROOM_SNAPSHOT',mode:room.mode,room_code:room.code,room_id:room.roomId,round_id:room.roundId||'',player_id:room.host});}
      for(const e of accounts.authEvents){records.push({timestamp:new Date(e.at).toISOString(),event:e.type,player_id:e.playerId,username:e.username,player_name:e.name,player_type:'HUMAN'});}
      for(const e of accounts.ledger){records.push({timestamp:new Date(e.timestamp).toISOString(),event:e.reason,room_id:e.roomId,round_id:e.roundId,mode:e.mode,player_id:e.playerId,username:e.username,player_name:e.name,net_result:e.change,balance_before:e.before,balance_after:e.after});}
      const filter={q:(url.searchParams.get('q')||'').toLowerCase(),mode:url.searchParams.get('mode')||'',room:(url.searchParams.get('room')||'').toUpperCase(),round:url.searchParams.get('round')||'',event:(url.searchParams.get('event')||'').toUpperCase(),date:url.searchParams.get('date')||'',player:url.searchParams.get('player')||'',start:url.searchParams.get('start')||'',end:url.searchParams.get('end')||''};
      const selected=records.filter(r=>(!filter.mode||r.mode===filter.mode)&&(!filter.room||String(r.room_code||'').toUpperCase().includes(filter.room))&&(!filter.round||String(r.round_id||'').includes(filter.round))&&(!filter.event||String(r.event||'').toUpperCase().includes(filter.event))&&(!filter.date||String(r.timestamp||'').startsWith(filter.date))&&(!filter.player||r.player_id===filter.player)&&(!filter.start||new Date(r.timestamp).getTime()>=Date.parse(filter.start))&&(!filter.end||new Date(r.timestamp).getTime()<=Date.parse(filter.end))&&(!filter.q||[r.player_name,r.username,r.player_id,r.room_code,r.room_id].join(' ').toLowerCase().includes(filter.q)));
      const normalize=x=>{const s=String(x??'');return typeof x==='string'&&/^[\s]*[=+@-]/.test(s)&&!/^-?[0-9]+(?:\.[0-9]+)?$/.test(s)?"'"+s:s;};
      const quote=x=>'"'+normalize(x).replace(/"/g,'""')+'"';
      const csv='\ufeff'+[columns.join(','),...selected.map(o=>columns.map(k=>quote(o[k])).join(','))].join('\r\n');
      res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="hilo-vip-history.csv"','Cache-Control':'no-store'});res.end(csv);return;
    }
    if(req.method==='POST'&&url.pathname==='/api/signal'){
      validateOwnership(req);const {r,p}=game.get(bearer(req));const b=await readBody(req);const target=r.players.find(x=>x.id===b.to&&!x.bot&&x.id!==p.id);if(!target)throw Object.assign(new Error('ผู้รับไม่ถูกต้อง'),{status:400});
      if(!['offer','answer','ice','hangup'].includes(b.signal?.type))throw Object.assign(new Error('สัญญาณเสียงไม่ถูกต้อง'),{status:400});
      const peers=[...(sockets.get(r.code)||[])].filter(x=>x.id===target.id);for(const peer of peers)send(peer.res,'signal',{from:p.id,signal:b.signal});return json(res,200,{ok:true});
    }
    if(req.method==='POST'&&routes[url.pathname]){const body=await readBody(req);return json(res,200,routes[url.pathname](req,body,res));}
    if(req.method==='GET'){
      let pathname;try{pathname=decodeURIComponent(url.pathname)}catch{return json(res,400,{error:'เส้นทางไม่ถูกต้อง'})}
      const filename=path.resolve(ROOT,'.'+(pathname==='/'?'/index.html':pathname));if(filename!==ROOT&&!filename.startsWith(ROOT+path.sep))return json(res,403,{error:'ไม่อนุญาต'});
      const ext=path.extname(filename);if(!mime[ext])return json(res,404,{error:'ไม่พบไฟล์'});
      return fs.createReadStream(filename).on('error',()=>{if(!res.headersSent)json(res,404,{error:'ไม่พบไฟล์'});else res.end()}).once('open',()=>res.writeHead(200,{'Content-Type':mime[ext],'X-Content-Type-Options':'nosniff'})).pipe(res);
    }
    return json(res,404,{error:'ไม่พบคำสั่ง'});
  }catch(e){json(res,e.status||500,{error:e.status?e.message:'เซิร์ฟเวอร์ขัดข้อง'});if(!e.status)console.error(e);}
});
setInterval(()=>{const changed=game.tick();for(const code of changed)notify(code);},250);
server.listen(PORT,'0.0.0.0',()=>console.log(`เกมไฮโลพร้อมใช้งาน: http://localhost:${PORT}`));
