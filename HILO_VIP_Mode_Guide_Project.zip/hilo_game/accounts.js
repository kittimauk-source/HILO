'use strict';
const crypto=require('node:crypto');
const fail=(message,status=400)=>{const e=new Error(message);e.status=status;throw e};
const now=()=>Date.now();
class Accounts{
 constructor(data={}){this.users=new Map((data.users||[]).map(u=>[u.id,u]));this.tokens=new Map((data.tokens||[]).filter(([h,s])=>s.expires>now()));this.ledger=data.ledger||[];this.lastEventId=data.lastEventId||'';this.authEvents=data.authEvents||[];this.globalStats=data.globalStats||{rounds:0,bets:0,turnover:0,payout:0};}
 serialize(){return {users:[...this.users.values()],tokens:[...this.tokens],ledger:this.ledger,lastEventId:this.lastEventId,authEvents:this.authEvents,globalStats:this.globalStats};}
 public(u){const {passwordHash,passwordSalt,...safe}=u;return safe;}
 find(username){return [...this.users.values()].find(u=>u.username.toLowerCase()===String(username).toLowerCase());}
 hash(password,salt){return crypto.scryptSync(password,salt,64).toString('hex');}
 audit(u,type){this.authEvents.unshift({id:crypto.randomUUID(),type,at:now(),accountId:u.id,username:u.username,name:u.name,playerId:u.id,mode:'',room:'',roomId:'',roundId:''});this.authEvents=this.authEvents.slice(0,5000);}
 issue(u){const token=crypto.randomBytes(32).toString('hex');this.tokens.set(crypto.createHash('sha256').update(token).digest('hex'),{id:u.id,expires:now()+30*86400000});u.lastLoginAt=now();u.loginCount=(u.loginCount||0)+1;this.audit(u,'LOGIN');return {token,user:this.public(u)};}
 register({username,password,name}){const un=String(username||'').trim();if(!/^[a-zA-Z0-9_.-]{3,24}$/.test(un))fail('Username ต้องเป็นภาษาอังกฤษหรือตัวเลข 3–24 ตัว');if(this.find(un))fail('Username นี้ถูกใช้แล้ว',409);if(typeof password!=='string'||password.length<8||password.length>128)fail('รหัสผ่านต้องยาว 8–128 ตัว');const displayName=String(name||'').trim().slice(0,24)||un;
  const salt=crypto.randomBytes(16).toString('hex');const u={id:crypto.randomUUID(),username:un,name:displayName,avatar:'',emoji:'🦊',chipBorderColor:'#ffc247',passwordSalt:salt,passwordHash:this.hash(password,salt),balance:1500,initialBalance:1500,registeredAt:now(),lastLoginAt:0,lastLogoutAt:0,loginCount:0,totalBet:0,totalWon:0,totalLost:0,rounds:0,zeroCount:0,exerciseCount:0,exerciseCorrect:0,exerciseWrong:0,exerciseRewards:0,online:false};this.users.set(u.id,u);this.log(u,0,'ACCOUNT_CREATED',{after:1500});return this.issue(u);}
 login({username,password}){const u=this.find(username);if(!u||typeof password!=='string')fail('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง',401);const candidate=Buffer.from(this.hash(password,u.passwordSalt),'hex'),expected=Buffer.from(u.passwordHash,'hex');if(candidate.length!==expected.length||!crypto.timingSafeEqual(candidate,expected))fail('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง',401);return this.issue(u);}
 get(token){const digest=crypto.createHash('sha256').update(String(token||'')).digest('hex');const session=this.tokens.get(digest);if(!session||session.expires<now())fail('กรุณาเข้าสู่ระบบก่อน',401);const u=this.users.get(session.id);if(!u)fail('ไม่พบบัญชีผู้เล่น',401);return u;}
 logout(token){const digest=crypto.createHash('sha256').update(String(token||'')).digest('hex');const s=this.tokens.get(digest);if(s){const u=this.users.get(s.id);if(u){u.lastLogoutAt=now();this.audit(u,'LOGOUT');}this.tokens.delete(digest);}}
 log(u,change,reason,more={}){const before=more.before??(u.balance-change);this.ledger.unshift({timestamp:now(),playerId:u.id,username:u.username,name:u.name,before,change,after:more.after??u.balance,reason,roomId:more.roomId||'',roundId:more.roundId||'',mode:more.mode||''});this.ledger=this.ledger.slice(0,30000);}
 attach(u,p){p.accountId=u.id;p.name=u.name;p.avatar=u.avatar;p.emoji=u.emoji;p.chipBorderColor=u.chipBorderColor||'#ffc247';p.balance=u.balance;}
 consume(game){const events=game.events||[];for(const e of events)if(!e.id)e.id=crypto.randomUUID();const fresh=[];for(const e of events){if(e.id===this.lastEventId)break;fresh.push(e);}if(events.length)this.lastEventId=events[0].id;
  for(const e of fresh.reverse()){
    if(e.type==='ROUND_START')this.globalStats.rounds++;
    if(e.type==='BET_PLACED'){this.globalStats.bets++;this.globalStats.turnover+=(e.amount||0);}
    if(e.type==='ROUND_RESULT')this.globalStats.payout+=(e.payout||0);
    const u=this.users.get(e.accountId);if(!u)continue;
    if(e.type==='BET_PLACED')u.totalBet+=(e.amount||0);
    if(e.type==='ROUND_RESULT'){u.rounds++;const net=e.netResult||0;if(net>0)u.totalWon+=net;else u.totalLost+=-net;}
    if(e.type==='EXERCISE_START')u.exerciseCount++;
    if(e.type==='EXERCISE_ANSWER'){if(e.correct)u.exerciseCorrect++;else u.exerciseWrong++;}
    if(e.type==='EXERCISE_REWARD')u.exerciseRewards+=(e.amount||0);
  }
 }
 sync(game){this.consume(game);const active=new Set();for(const r of game.rooms.values()){for(const p of r.players){if(!p.accountId||p.bot)continue;const u=this.users.get(p.accountId);if(!u)continue;active.add(u.id);const previous=u.balance;
      if(previous!==p.balance){u.balance=p.balance;const delta=u.balance-previous;const event=game.events.find(e=>e.playerId===p.id&&e.room===r.code);this.log(u,delta,event?.type||'BALANCE_UPDATE',{before:previous,roomId:r.roomId,roundId:r.roundId,mode:r.mode});if(previous>0&&u.balance===0)u.zeroCount++;}
      u.name=p.name;u.avatar=p.avatar||'';u.emoji=p.emoji;u.chipBorderColor=p.chipBorderColor;u.online=!!p.online;
    }}for(const u of this.users.values())if(!active.has(u.id))u.online=false;
 }
 snapshot(u){return {id:u.id,username:u.username,name:u.name,avatar:u.avatar,emoji:u.emoji,chipBorderColor:u.chipBorderColor,balance:u.balance,registeredAt:u.registeredAt};}
}
module.exports={Accounts};
