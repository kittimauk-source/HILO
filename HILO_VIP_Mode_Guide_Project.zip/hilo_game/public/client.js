'use strict';
const $=id=>document.getElementById(id);
const money=n=>Number(n||0).toLocaleString('th-TH')+' ฿';
const faces=['','⚀','⚁','⚂','⚃','⚄','⚅'];
const playerColors=['#ffc247','#47b6ff','#ff7da5','#48e0a8','#c396ff'];
const emojis=['🦊','🐼','🐯','🐱','🐻','🐰','🦄','🐸','🐨','🐵','🦁','🐧','😀','😎','🤓','🥳','😺','🐶','🐮','🦋','🐺','🦖'];
let token=localStorage.getItem('hilo-player-token')||'',adminToken=sessionStorage.getItem('hilo-admin-token')||'';
let state=null,stream=null,chip=10,emoji='🦊',selected='',offset=0,toastTimer=null,wheelDegrees=0,spinning=false;
let lastRenderedRoomHistoryKey=''; // Avoid rebuilding long scrollable history on unrelated room state changes.
let localStream=null,peers=new Map(),peerAudio=new Map(),micEnabled=false;
const requestId=()=>`${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
function toast(text,isError=false){const box=$('toast');box.textContent=text;box.classList.toggle('error',isError);box.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.classList.remove('show'),3700);}
async function api(url,method='GET',body=null,admin=false){const response=await fetch(url,{method,headers:{'Content-Type':'application/json',...(admin?{'Authorization':'Bearer '+adminToken}:token?{'Authorization':'Bearer '+token}:{})},body:body?JSON.stringify(body):undefined});const data=await response.json();if(!response.ok)throw new Error(data.error||'เกิดข้อผิดพลาด');return data;}
function handleError(e){toast(e.message||'เกิดข้อผิดพลาด กรุณาลองใหม่',true);}
function screen(which){for(const name of ['auth','cover','deviceScreen','home','game','admin'])$(name).classList.toggle('hidden',name!==which);document.body.dataset.screen=which;if(which==='game')requestAnimationFrame(()=>window.fitGame?.());}
function modal(title,content){$('modalTitle').textContent=title;const body=$('modalBody');body.replaceChildren();if(typeof content==='string')body.innerHTML=content;else body.append(content);$('modal').classList.remove('hidden');}
function closeModal(){$('modal').classList.add('hidden');}
$('modalClose').onclick=closeModal;$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal();});
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function emojiPicker(container,initial,onChange){container.replaceChildren();for(const em of emojis){const b=document.createElement('button');b.type='button';b.textContent=em;b.className=em===initial?'selected':'';b.onclick=()=>{for(const c of container.children)c.classList.toggle('selected',c===b);onChange(em);};container.append(b);}}
emojiPicker($('emojiPicks'),emoji,em=>emoji=em);
$('device').addEventListener('change',e=>{document.body.dataset.device=e.target.value;localStorage.setItem('hilo-device',e.target.value);});$('device').value=localStorage.getItem('hilo-device')||'desktop';document.body.dataset.device=$('device').value;
const dimensions={width:701,height:392};
const spots=[
  ['5low',14,23,214,51],['11',239,23,209,51],['6low',457,23,219,51],
  ['4x1',14,84,108,89],['face1',130,84,101,89],['low',239,84,100,89],['high',348,84,100,89],['face6',456,84,105,89],['6x1',569,84,107,89],
  ['6x2',14,182,108,91],['face2',130,182,101,91],['face3',239,182,100,91],['face4',348,182,100,91],['face5',456,182,105,91],['5x2',569,182,107,91],
  ['123',14,282,108,92],['6x3',130,282,101,92],['4x2',239,282,100,92],['5x3',348,282,100,92],['5x1',456,282,105,92],['456',569,282,107,92],
  ['combo-1',217,109,35,43],['combo-2',435,109,35,43],['combo-3',162,156,36,45],['combo-4',270,156,36,45],['combo-5',381,156,37,45],['combo-6',490,156,37,45],['combo-7',217,206,35,43],['combo-8',326,206,36,43],['combo-9',435,206,35,43]
];
const buttons=new Map();for(const [id,x,y,w,h]of spots){const b=document.createElement('button');b.type='button';b.className='hotspot'+(id.startsWith('combo')?' combo':'');b.style.left=x/dimensions.width*100+'%';b.style.top=y/dimensions.height*100+'%';b.style.width=w/dimensions.width*100+'%';b.style.height=h/dimensions.height*100+'%';b.dataset.id=id;b.title=id;b.setAttribute('aria-label',id);b.onclick=()=>selectBet(id);$('boardHotspots').append(b);buttons.set(id,b);}
function betMeta(id){return state?.bets?.find(b=>b.id===id);}
async function selectBet(id){
  window.hiloSound?.unlock();selected=id;const b=betMeta(id);
  $('selectedBet').textContent=`ช่องที่เลือก: ${b?.label||id} · ชิป ${money(chip)}`;
  if(!state)return;
  const mine=me(),canPlace=state.phase==='betting'&&!mine?.locked&&state.bettingEndAt>Date.now()+offset;
  if(!canPlace){toast('ขณะนี้ไม่เปิดรับเดิมพัน',true);return;}
  if(mine.balance<chip){toast('ยอดเงินเกมไม่เพียงพอสำหรับชิปนี้',true);return;}
  try{
    const previousRoomId=state.roomId;
    const response=await api('/api/command','POST',{action:'place',id,amount:chip});
    // Do not rely solely on SSE: show a server-confirmed chip immediately, even if
    // a browser/WebView's EventSource connection is delayed. Never simulate success.
    const next=response?.data;
    if(next&&state?.roomId===previousRoomId&&next.roomId===previousRoomId&&
       (next.version||0)>=(state.version||0)){
      state=next;offset=state.serverTimestamp-Date.now();render();window.updateVIP?.(state);
    }
    window.hiloSound?.playEffect('chip');
  }catch(e){handleError(e);}
}
function me(){return state?.players?.find(p=>p.id===state.me);}
function showRoom(data){token=data.token;localStorage.setItem('hilo-player-token',token);state=data.room;openStream();render();screen('game');window.updateVIP?.(state);}
async function create(mode){try{const name=$('playerName').value.trim();const data=await api('/api/create','POST',{mode,name,emoji});showRoom(data);toast(mode==='solo'?'เข้าห้องเล่นคนเดียวแล้ว':'สร้างห้องแล้ว แชร์รหัสให้เพื่อนเข้าร่วม');}catch(e){handleError(e);}}
$('soloButton').onclick=()=>create('solo');$('createButton').onclick=()=>create('group');
$('joinButton').onclick=async()=>{try{const code=$('roomCode').value.trim();if(!/^[A-Z][0-9]{5}$/.test(code.toUpperCase()))throw new Error('กรุณาระบุรหัส เช่น K58231');const data=await api('/api/join','POST',{code:code.toUpperCase(),name:$('playerName').value,emoji});showRoom(data);toast('เข้าห้องสำเร็จ');}catch(e){handleError(e);}};
$('roomCode').addEventListener('input',e=>{e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);});
const params=new URLSearchParams(location.search);if(/^[A-Z][0-9]{5}$/i.test(params.get('room')||''))$('roomCode').value=params.get('room').toUpperCase();
function openStream(){stream?.close();if(!token)return;stream=new EventSource('/api/events?token='+encodeURIComponent(token));stream.addEventListener('state',e=>{lastRoomEventAt=Date.now();state=JSON.parse(e.data);offset=state.serverTimestamp-Date.now();render();refreshChatModal();syncVoice();window.updateVIP?.(state);});stream.addEventListener('signal',e=>receiveSignal(JSON.parse(e.data)).catch(console.error));stream.addEventListener('reset',e=>{toast(JSON.parse(e.data).message,true);logoutLocal();});stream.onerror=()=>{$('status').textContent='กำลังเชื่อมต่อเซิร์ฟเวอร์อีกครั้ง…';};}
// If an iPad suspends EventSource during tab changes, recover authoritative phases
// so next-round betting buttons never remain disabled waiting for a lost event.
let lastRoomEventAt=Date.now(),resyncPending=false;
setInterval(async()=>{
  if(!token||!state||document.body.dataset.screen!=='game'||resyncPending)return;
  if(stream?.readyState===EventSource.OPEN&&Date.now()-lastRoomEventAt<3200)return;
  resyncPending=true;
  try{
    const data=await api('/api/session');const next=data.room;
    if(next&&state?.roomId===next.roomId&&(next.version||0)>=(state.version||0)){
      state=next;offset=state.serverTimestamp-Date.now();render();window.updateVIP?.(state);
    }
  }catch(_){/* EventSource will reconnect; never invent a local round. */}
  finally{resyncPending=false;}
},2000);
function logoutLocal(){token='';state=null;stream?.close();stream=null;stopMic(false);closeModal();localStorage.removeItem('hilo-player-token');screen('cover');}
$('leaveBtn').onclick=async()=>{if(!confirm('ออกจากห้องนี้ใช่หรือไม่?'))return;try{await api('/api/leave','POST');}catch(e){console.warn(e)}logoutLocal();};
function render(){if(!state)return;const mine=me();if(!mine)return;
  const group=state.mode==='group',host=state.host===mine.id;
  $('roomTitle').textContent=group?'ห้องเล่นกับเพื่อน (Group Mode)':'ห้องส่วนตัว (โหมดเล่นคนเดียว)';
  const roomText=$('roomCodeText');roomText.replaceChildren();if(group){const copy=document.createElement('button');copy.className='inline-btn';copy.textContent='รหัสห้อง '+state.code+' · แตะเพื่อคัดลอกลิงก์';copy.onclick=async()=>{const link=location.origin+'/?room='+state.code;try{await navigator.clipboard.writeText(link);toast('คัดลอกลิงก์เข้าห้องแล้ว');}catch{modal('ลิงก์เข้าห้อง',`<p>${esc(link)}</p>`);}};roomText.append(copy);}else roomText.textContent='คุณ + บอท 4 คน';
  $('roundTag').textContent='รอบ '+state.round;
  $('status').textContent=state.phase==='lobby'?(state.players.filter(p=>!p.bot).length<2?'กำลังรอผู้เล่น อย่างน้อย 2 คนจึงสามารถเริ่มเกมได้':host?'สมาชิกพร้อมแล้ว Host กด “เริ่มเกม”':'รอ Host กดเริ่มเกม'):
    state.phase==='betting'?'เปิดรับเดิมพัน (15 วินาที)':state.phase==='shake'?'กำลังเขย่าลูกเต๋า...':state.phase==='announcing'?'กำลังขานแต้ม...':'สรุปผลรอบนี้ แล้วเริ่มรอบใหม่อัตโนมัติ';
  if(mine.avatar){$('myEmoji').replaceChildren(Object.assign(document.createElement('img'),{src:mine.avatar,alt:'รูปโปรไฟล์'}));}else $('myEmoji').textContent=mine.emoji;$('myName').textContent=mine.name;$('balance').textContent=money(mine.balance);
  $('betTotal').textContent=money(Object.values(mine.bets).reduce((a,v)=>a+v,0));
  const available=state.phase==='betting'&&!mine.locked&&state.bettingEndAt>Date.now()+offset;
  for(const id of buttons.keys()){const btn=buttons.get(id),n=mine.bets[id]||0,meta=betMeta(id);btn.disabled=!available;btn.setAttribute('aria-label',`${meta?.label||id} ${n?'วางไว้ '+money(n):''}`);btn.title=(meta?.label||id)+(n?' · '+money(n):'');btn.classList.toggle('chosen',n>0);renderStakeCluster(btn,id);}
  for(const id of ['doubleBtn','repeatBtn','clearBtn'])$(id).disabled=!available;
  $('lockBtn').disabled=!available||!Object.keys(mine.bets).length;
  $('lockBtn').textContent=mine.locked?'ยืนยันแล้ว ✓':'เริ่มเดิมพัน';
  $('startBtn').classList.toggle('hidden',!(group&&host&&state.phase==='lobby'));
  $('startBtn').disabled=state.players.filter(p=>!p.bot).length<2;
  $('betHelp').textContent=state.phase==='lobby'?'กำลังรอผู้เล่น อย่างน้อย 2 คนจึงสามารถเริ่มเกมได้ (สูงสุด 5 คน)':mine.locked?'ล็อกเดิมพันแล้ว รอระบบทอยลูกเต๋า':state.phase==='betting'?'แตะช่องสีขาวหรือกรอบเขียวเพื่อวางชิป แล้วกดยืนยัน':'ระบบเปิดรอบใหม่หลังแสดงผล 3 วินาที';
  $('seatCount').textContent=(group?state.players.filter(p=>!p.bot).length:state.players.length)+'/5 คน';renderPlayers();renderDice();
  $('pressText').textContent=mine.presses+' / 20 ครั้ง';$('pressBar').style.width=mine.presses/20*100+'%';$('missionState').textContent=mine.balance<50?'เปิดใช้งาน':'ต้องมีเงินต่ำกว่า 50 ฿';$('pressBtn').disabled=mine.balance>=50;
  $('streakLabel').textContent=mine.streak+' / 3';$('streakBar').style.width=mine.streak/3*100+'%';$('spinBtn').disabled=!mine.spins||mine.pendingSteal||spinning;
  $('spinBtn').textContent=mine.pendingSteal?'เลือกรายชื่อผู้เล่นเพื่อรับรางวัล':mine.spins?'หมุนวงล้อ · '+mine.spins+' สิทธิ์':'หมุนวงล้อ';
  if(mine.pendingSteal&&!$('modal').classList.contains('hidden')&&$('modalTitle').textContent==='เลือกผู้เล่นที่ต้องการขโมยเงิน')return;
  if(mine.pendingSteal&&!spinning&&$('modal').classList.contains('hidden'))showSteal();
  const rec=mine.history?.find(x=>x.round===state.round&&x.room===state.code);
  const total=rec?.chosen.reduce((t,b)=>t+b.amount,0)||0;
  $('roundReport').textContent=rec?`เดิมพัน ${money(total)} • ${rec.net>=0?'กำไร':'ขาดทุน'} ${money(Math.abs(rec.net))} • คงเหลือ ${money(mine.balance)}`:`เดิมพัน ${money(Object.values(mine.bets).reduce((a,n)=>a+n,0))} • คงเหลือ ${money(mine.balance)}`;
  // Each room receives its entire immutable, append-only history from the server.
  // Reverse only for display (latest first); do not trim the authoritative list.
  const diceHistory=state.diceHistory||[];
  const stat=$('roundStats');
  const newest=diceHistory[diceHistory.length-1];
  const statsKey=`${state.roomId}:${diceHistory.length}:${newest?.roundId||newest?.round||''}`;
  if(statsKey===lastRenderedRoomHistoryKey)return;
  const wasAtTop=stat.scrollTop<=6,oldScroll=stat.scrollTop;
  lastRenderedRoomHistoryKey=statsKey;
  stat.replaceChildren();
  const dots={1:[5],2:[1,9],3:[1,5,9],4:[1,3,7,9],5:[1,3,5,7,9],6:[1,3,4,6,7,9]};
  const faceSet=dice=>{const group=document.createElement('div');group.className='dice-face-set';
    dice.forEach(value=>{const die=document.createElement('div');die.className='mini-die';die.setAttribute('role','img');die.setAttribute('aria-label',`หน้าลูกเต๋า ${value}`);
      for(let i=1;i<=9;i++){const dot=document.createElement('i');if(dots[value]?.includes(i))dot.className='visible';die.append(dot);}group.append(die);});return group;};
  const describe=x=>{const total=x.dice.reduce((a,b)=>a+b,0);return `รวม ${total} · ${x.dice.every(n=>n===x.dice[0])?'ตอง':total>=11&&total<=17?'สูง':total>=4&&total<=10?'ต่ำ':'พิเศษ'}`;};
  if(diceHistory.length){const newestFirst=diceHistory.slice().reverse();const latest=newestFirst[0],hero=document.createElement('div');hero.className='stats-latest-card';
    const top=document.createElement('div');top.className='stat-top';top.innerHTML=`<span>ล่าสุด · รอบ ${Number(latest.round)||0}</span><span>ผล 3 ลูก</span>`;
    const result=document.createElement('div');result.className='stat-outcome';result.textContent=describe(latest);
    hero.append(top,faceSet(latest.dice),result);stat.append(hero);
    const list=document.createElement('div');list.className='stats-list';newestFirst.slice(1).forEach(x=>{const row=document.createElement('div');row.className='stats-row';
      const id=document.createElement('span');id.className='stat-round';id.textContent='รอบ '+x.round;
      const result=document.createElement('span');result.className='stat-outcome';result.textContent=describe(x);
      row.append(id,faceSet(x.dice),result);list.append(row);});stat.append(list);
    $('miniLatest').textContent=`ล่าสุด ${latest.dice.join('-')} · ${describe(latest)}`;
  }else{$('miniLatest').textContent='ยังไม่มีผลลูกเต๋า';stat.textContent='รอผลรอบแรก — เมื่อจบรอบจะแสดงหน้าลูกเต๋าทั้งสามลูก';}
  stat.scrollTop=wasAtTop?0:oldScroll;
  $('quizBtn').disabled=mine.balance>=10||!mine.quizEligible||['shake','announcing'].includes(state.phase)||(state.phase==='betting'&&Object.keys(mine.bets).length>0); 
}
// Chips live inside the SAME immutable hotspot rectangles. Only chip positioning
// changes: all chips are clustered around the centre, never at the cell edges.
function renderStakeCluster(button,id){
  button.replaceChildren();if(!state)return;
  const all=[];
  for(const p of state.players){
    const stack=p.betChips?.[id];
    if(Array.isArray(stack)&&stack.length){for(const amount of stack)all.push({amount,p});}
    else if(p.bets[id]>0){ // Backward compatibility for a persisted room before chip stacks existed.
      let remainder=p.bets[id];for(const denom of [500,100,50,10])while(remainder>=denom){all.push({amount:denom,p});remainder-=denom;}
    }
  }
  if(!all.length)return;
  const container=document.createElement('span');container.className='stake-cluster';
  const compact=id.startsWith('combo');
  const limit=compact?2:all.length>6?5:6;
  const visible=all.slice(0,limit);
  for(const item of visible){
    const mark=document.createElement('span');mark.className=`stake-coin stake-coin-${item.amount}${compact?' stake-coin-compact':''}`;
    mark.textContent=item.amount;
    mark.style.setProperty('--stake-border',item.p.chipBorderColor||playerColors[state.players.indexOf(item.p)%5]);
    mark.setAttribute('aria-label',`${item.p.name} เดิมพัน ${item.amount}`);
    container.append(mark);
  }
  if(all.length>visible.length){const extra=document.createElement('span');extra.className='stake-extra';extra.textContent='+'+(all.length-visible.length);container.append(extra);}
  button.append(container);
}
function renderPlayers(){const holder=$('players');holder.replaceChildren();state.players.forEach((p,i)=>{const c=document.createElement('div');c.className='player'+(p.id===state.me?' you':'')+(p.id===state.host?' host':'');const a=document.createElement('div');a.className='avatar';if(p.avatar){const img=document.createElement('img');img.src=p.avatar;img.alt='รูปโปรไฟล์ '+p.name;a.append(img);}else a.textContent=p.emoji;const n=document.createElement('div');n.className='player-name';n.textContent=p.name;const sub=document.createElement('div');sub.className='sub';sub.textContent='P'+(i+1)+(p.bot?' · บอท':p.online?' · ออนไลน์':' · ออฟไลน์');const cash=document.createElement('div');cash.className='cash';cash.textContent=money(p.balance);c.style.setProperty('--player-chip-color',p.chipBorderColor||playerColors[i%5]);c.append(a,n,sub,cash);holder.append(c);});}
function renderDice(){const banner=$('diceBanner');banner.classList.remove('result-win','result-lose');if(!state.dice){$('dice').textContent=state.phase==='shake'?'🎲 🎲 🎲':'⚀ ⚀ ⚀';$('dice').classList.toggle('dice-shake',state.phase==='shake');if(state.phase==='shake')$('dice').style.animationDelay=(-(Date.now()+offset-state.shakeStartAt)%150)+'ms';$('outcome').textContent=state.phase==='lobby'?'รอ Host เริ่มเกม':'รอผลรอบนี้';return;}
  $('dice').classList.remove('dice-shake');$('dice').textContent=state.dice.map(x=>faces[x]).join(' ');const result=state.results.find(x=>x.playerId===state.me);const total=state.dice.reduce((a,b)=>a+b,0);if(result){$('outcome').textContent=`รวม ${total} แต้ม · ${result.net>=0?'ได้':'เสีย'} ${money(Math.abs(result.net))}`;banner.classList.add(result.net>=0?'result-win':'result-lose');}else $('outcome').textContent=`รวม ${total} แต้ม`;
}
function updateClock(){if(!state)return;const seconds=state.deadline?Math.max(0,Math.ceil((state.deadline-Date.now()-offset)/1000)):0;
  $('timer').textContent=state.phase==='lobby'?'รอเพื่อน':state.phase==='betting'?String(seconds):state.phase==='shake'?'🎲':state.phase==='announcing'?'ขานผล':String(seconds);
  if(state.phase==='betting'&&seconds===0){for(const button of buttons.values())button.disabled=true;}
}
setInterval(updateClock,180);
$('chips').addEventListener('click',e=>{const b=e.target.closest('[data-amount]');if(!b)return;chip=Number(b.dataset.amount);for(const c of $('chips').children)c.classList.toggle('selected',c===b);if(selected)$('selectedBet').textContent=`ช่องที่เลือก: ${betMeta(selected)?.label||selected} · ชิป ${money(chip)}`;});
async function command(action,extra={}){try{const data=await api('/api/command','POST',{action,...extra});return data.data;}catch(e){handleError(e);return null;}}
$('doubleBtn').onclick=()=>command('double');$('repeatBtn').onclick=()=>command('repeat');$('clearBtn').onclick=()=>command('clear');$('lockBtn').onclick=()=>command('lock');$('startBtn').onclick=()=>command('start');
$('pressBtn').onclick=async()=>{const btn=$('pressBtn');btn.disabled=true;const result=await command('press',{requestId:requestId()});if(result?.awarded)toast('ภารกิจสำเร็จ! คุณได้รับเงินจำลอง 50 บาท 🎉');else if(result)toast('กดแล้ว '+result.progress+' / 20 ครั้ง');if(state)btn.disabled=me().balance>=50;};
$('spinBtn').onclick=async()=>{if(spinning)return;spinning=true;$('spinBtn').disabled=true;const result=await command('spin',{requestId:requestId()});if(!result){spinning=false;render();return;}
  const reward=result.reward;wheelDegrees=Math.ceil(wheelDegrees/360)*360+1440+(8-result.index)*45-22.5;$('wheel').style.transform=`rotate(${wheelDegrees}deg)`;
  setTimeout(()=>{spinning=false;render();if(reward==='steal'){if($('modal').classList.contains('hidden'))showSteal();}else modal('ผลวงล้อรางวัล',`<p style="text-align:center;font-size:1.8rem;font-weight:900;color:#168e65">+${reward} ฿</p><p style="text-align:center">ได้รับเงินจำลองจากวงล้อแล้ว</p>`);},2600);
};
function showSteal(){if(!state)return;const eligible=state.players.filter(p=>!p.bot&&p.id!==state.me&&p.balance>0);if(!eligible.length){modal('วงล้อรางวัล','<p>ไม่มีผู้เล่นอื่นที่สามารถเลือกได้ ระบบจะเปลี่ยนรางวัลเป็น +50 บาทให้โดยอัตโนมัติเมื่อหมุน</p>');return;}
  const container=document.createElement('div');container.className='target-list';for(const p of eligible){const b=document.createElement('button');const left=document.createElement('span');left.textContent=p.emoji+' '+p.name;const right=document.createElement('strong');right.textContent=money(p.balance);b.append(left,right);b.onclick=async()=>{const result=await command('steal',{targetId:p.id});if(result){closeModal();toast('โอนเงินจำลองจาก '+p.name+' '+money(result.amount));}};container.append(b);}modal('เลือกผู้เล่นที่ต้องการขโมยเงิน',container);
}
let guideLang='th';
let guideChip=10;
const GUIDE_CATEGORIES=[
 ['SINGLE','เลขเดี่ยว 1–6','Single face 1–6'],['LOW_HIGH','ต่ำ / สูง','Low / High'],
 ['TWO_NUMBER','แทงเลข 2 ตัว','Two-number pair'],['ONE_LOW','1+ต่ำ','1 + Low'],
 ['THREE_LOW','3+ต่ำ','3 + Low'],['FIVE_LOW','5+ต่ำ','5 + Low'],
 ['SIX_LOW','6+ต่ำ','6 + Low'],['FOUR_HIGH','4+สูง','4 + High'],
 ['SIX_HIGH','6+สูง','6 + High'],['GROUP_123_456','123 / 456','123 / 456'],
 ['HILO_11','11 ไฮโล','11 exact']
];
function showGuide(){
 const th=guideLang==='th';
 const rules=th?[
  ['1. เลือกโหมดการเล่น','<b>เล่นคนเดียว (Solo)</b> เล่นกับบอท 4 ตัว รวม 5 คน เริ่มเกมได้ทันที<br><b>เล่นกับเพื่อน (Group)</b> ห้องออนไลน์แบบเรียลไทม์ รองรับผู้เล่นจริงสูงสุด 5 คน'],
  ['2. การเล่นกับเพื่อน','<b>สร้างห้อง:</b> Host กด “สร้างห้องใหม่” ได้รหัสรูปแบบอักษรอังกฤษพิมพ์ใหญ่ 1 ตัว + ตัวเลข 5 ตัว เช่น K58231 แล้วเข้าไปรอได้ทันที<br><b>เข้าร่วมห้อง:</b> เพื่อนกด “เข้าร่วมห้องด้วยรหัส” กรอกรหัสเดียวกันและเข้าห้องได้เลย ระบบยอมรับรหัสพิมพ์เล็ก'],
  ['3. การเริ่มเกม','Host เข้าห้องรอได้ตั้งแต่ 1 คน แต่รอบแรกเริ่มได้เมื่อมีผู้เล่นจริงอย่างน้อย <b>2 คน</b> และ <b>Host เท่านั้น</b> เป็นผู้กดเริ่ม รอบถัดไปเริ่มอัตโนมัติ'],
  ['4. เลือกเหรียญเดิมพัน','เลือกเหรียญ <b>10 / 50 / 100 / 500 บาท</b> ก่อน แล้วกดช่องเดิมพันที่ต้องการบนกระดาน'],
  ['5. วิธีวางเดิมพัน','<b>กดช่องไหน = ลงเฉพาะช่องนั้น</b> เช่น กด “โต๊ด 5-2” จะลงที่ช่องนี้ช่องเดียว ไม่กระจายไปเลขเดี่ยว 5 หรือ 2'],
  ['6. เวลาเดิมพันและดูผล','มีเวลา <b>15 → 14 → … → 1 → 0</b> เมื่อถึง 0 ระบบปิดรับเดิมพันทันที จากนั้นเขย่าและเปิดลูกเต๋า 3 ลูก ขานผล แสดงเงินที่ได้รับและ <b>กำไร/ขาดทุนสุทธิ</b> แล้วนับ 3 → 2 → 1 ล้างชิปรอบเก่าและเริ่มรอบใหม่'],
  ['7. ตารางอัตราค่าตอบแทน','ตารางด้านล่างเป็น <b>เงินที่ได้รับเมื่อชนะ รวมทุนคืนแล้ว</b> ไม่ใช่กำไรสุทธิ กดเปลี่ยนมูลค่าเหรียญเพื่อดูจำนวนเงินที่ตรงกับการเดิมพันนั้น'],
  ['8. เงื่อนไขเดิมพัน','<b>เลขเดี่ยว:</b> ลูกเต๋ามีเลขนั้นอย่างน้อย 1 ลูก (อัตราจ่ายคงที่ตามเหรียญ)<br><b>ต่ำ:</b> ผลรวม 3–10 • <b>สูง:</b> ผลรวม 12–18 • <b>11 ไฮโล:</b> ผลรวมเท่ากับ 11<br><b>แทงเลข 2 ตัว:</b> ต้องมีทั้งสองเลข เช่น 4-1, 5-2, 6-3<br><b>1+ต่ำ / 3+ต่ำ / 5+ต่ำ / 6+ต่ำ / 4+สูง / 6+สูง:</b> ใช้เงื่อนไขของช่องเดิมพันเดิม<br><b>123 / 456:</b> ต้องออกเลขสามตัวตามชุดที่เลือก ไม่สนลำดับ']
 ]:[
  ['1. Choose mode','Solo: you and 4 bots, start immediately. Group: real-time room for up to 5 people.'],
  ['2. Play with friends','Host creates a room and shares a code: one capital letter + five digits, e.g. K58231. Friends join with the same code.'],
  ['3. Starting rounds','Host may wait alone but first round requires 2 real players and Host presses Start. All later rounds start automatically.'],
  ['4. Select a chip','Choose 10 / 50 / 100 / 500 before selecting a betting area.'],
  ['5. Place bets','Tapping an area bets only on that exact area. A 5–2 pair does not create single-face bets.'],
  ['6. Countdown and outcome','Betting lasts 15 seconds. At zero bets close; dice reveal, payouts settle, then 3, 2, 1 and the next round starts automatically.'],
  ['7. Payout table','Displayed amounts are gross receipts including your stake. Net result = gross payout − total stake.'],
  ['8. Winning conditions','Single face: appears at least once; Low: 3–10; High: 12–18; 11 exact: sum 11; pair: both faces appear; 123/456: exact three-face set; combined areas follow original board rules.']
 ];
 const rates=window.HILO_PAYOUT_TABLE;
 const fmt=v=>Number(v).toLocaleString('th-TH')+' '+(th?'บาท':'THB');
 const rows=GUIDE_CATEGORIES.map(([id,thai,en])=>`<tr><td>${esc(th?thai:en)}</td><td class="vip-guide-money">${fmt(rates[String(guideChip)][id])}</td></tr>`).join('');
 const content=`<div class="vip-guide" role="document"><div class="vip-guide-top"><span class="vip-guide-eyebrow">HILO VIP • PLAYER MANUAL</span><button id="langSwitch" class="vip-guide-lang" type="button">${th?'ENGLISH':'ภาษาไทย'}</button></div><p class="vip-guide-intro">${th?'คู่มือเข้าใจง่าย ตั้งแต่เริ่มเล่นจนถึงวิธีคิดกำไรสุทธิ':'Beginner-friendly game guide and exact payout amounts.'}</p><div class="vip-guide-sections">${rules.map(([h,t])=>`<section class="vip-guide-section"><h3>${h}</h3><p>${t}</p></section>`).join('')}</div><section class="vip-guide-table-card"><h3>${th?'ตารางเงินที่ได้รับเมื่อชนะ':'Gross amount received on a win'}</h3><div class="vip-guide-tabs">${[10,50,100,500].map(n=>`<button class="vip-guide-tab ${guideChip===n?'active':''}" data-guide-chip="${n}" type="button" aria-pressed="${guideChip===n}">${n.toLocaleString('th-TH')} ${th?'บาท':'THB'}</button>`).join('')}</div><div class="vip-guide-scroll"><table class="vip-guide-rates"><thead><tr><th>${th?'ประเภทเดิมพัน':'Bet type'}</th><th>${th?'เงินที่ได้รับเมื่อชนะ':'Gross payout'}</th></tr></thead><tbody>${rows}</tbody></table></div><p class="vip-guide-calculation">${th?`<b>ตัวอย่าง:</b> แทงเลข 2 ตัว 100 บาท ถูกเดิมพัน → ได้รับ <b>600 บาท</b> รวมทุนคืน กำไรสุทธิ = 600 − 100 = <b>+500 บาท</b>`:`<b>Example:</b> 100 THB winning pair → 600 THB received; net profit = 600 − 100 = +500 THB.`}</p></section><p class="vip-guide-note">${th?'ใช้เงินเกมจำลองเท่านั้น ไม่มีการฝากถอน • หากยอดเงินหลังตัดสินผลต่ำกว่า 10 บาท จะมีแบบฝึกหัด 5 ข้อ ถูกข้อละ 100 บาท':'Play-money simulation only. Below 10 THB after settlement unlocks five maths questions at 100 THB per correct answer.'}</p></div>`;
 modal(th?'คู่มือการเล่น':'How to Play',content);
 $('langSwitch').onclick=()=>{guideLang=th?'en':'th';showGuide();};
 $('modalBody').querySelectorAll('[data-guide-chip]').forEach(b=>b.onclick=()=>{guideChip=Number(b.dataset.guideChip);showGuide();});
}
$('guideHead').onclick=showGuide;$('inGameGuide').onclick=showGuide;$('lobbyGuide').onclick=showGuide;
$('dealerBtn').onclick=()=>modal('บอกเจ้ามือ','<p>เจ้ามือจะเปิดรับเดิมพัน 15 วินาที จากนั้นทอยลูกเต๋า 3 ลูกและประกาศผลโดยอัตโนมัติ</p>');
$('noticeBtn').onclick=()=>{const title=state?.phase==='result'?'ประกาศผลรอบล่าสุด':'แจ้งเตือน';modal(title,`<p>${esc($('status').textContent)}</p><p>เมื่อจบรอบ ระบบจะเริ่มรอบใหม่อัตโนมัติภายใน 3 วินาที</p>`);};
$('historyBtn').onclick=()=>{const history=me()?.history||[];const root=document.createElement('div');if(!history.length)root.textContent='ยังไม่มีประวัติการเล่น';for(const rec of history){const card=document.createElement('div');card.className='log-card';const h=document.createElement('strong');h.textContent=`รอบ ${rec.round} · ${rec.dice.join('-')} · ${rec.net>=0?'+':''}${money(rec.net)}`;const p=document.createElement('p');p.textContent=rec.chosen.map(c=>`${c.label} ${money(c.amount)} ${c.won?'✓':'✗'}`).join(' · ')||'ไม่มีเดิมพัน';card.append(h,p);root.append(card);}modal('ประวัติการเล่น',root);};
$('statsBtn').onclick=()=>{const p=me();modal('สถิติผู้เล่น',`<p><b>${esc(p.name)}</b> · เงินจำลอง ${money(p.balance)}</p><p>เล่นแล้ว ${p.history.length} รอบ · ได้สุทธิ ${money(p.totalWon)} · เสียสุทธิ ${money(p.totalLost)}</p><p>ถูกติดต่อกัน ${p.streak}/3 รอบ · หมุนวงล้อ ${p.wheels} ครั้ง · ทำภารกิจรับเงิน ${p.missions} ครั้ง</p>`);};
function openProfileEditor(){const person=state?me():window.hiloAccount;if(!person)return toast('กรุณาเข้าสู่ระบบ',true);
  const root=document.createElement('div'),name=document.createElement('input');name.maxLength=24;name.value=person.name;
  const label=document.createElement('p');label.textContent='ชื่อที่แสดง';const picks=document.createElement('div');picks.className='emoji-picks';let chosen=person.emoji||'🦊';emojiPicker(picks,chosen,v=>chosen=v);
  const photo=document.createElement('input');photo.type='file';photo.accept='image/png,image/jpeg,image/webp';photo.style.margin='12px 0';
  const hint=document.createElement('p');hint.textContent='เลือกภาพ หรือใช้ Character เพียงอย่างเดียว (รูปภาพที่บันทึกอยู่จะแสดงก่อนอิโมจิ)';
  const colors=document.createElement('div');colors.className='border-color-picks';const palette=['#ffc247','#47b6ff','#ff7da5','#48e0a8','#c396ff','#ff8653','#bbef5a','#e858b5','#47d5d8','#f4f1f1','#8da4ff','#b6a16c'];let color=person.chipBorderColor||palette[0];
  for(const value of palette){const button=document.createElement('button');button.type='button';button.className='color-choice';button.style.background=value;button.title='สีขอบเหรียญ '+value;button.setAttribute('aria-label',button.title);button.classList.toggle('selected',color===value);button.onclick=()=>{color=value;for(const c of colors.children)c.classList.toggle('selected',c===button);};colors.append(button);}
  const title=document.createElement('p');title.textContent='สีขอบเหรียญของคุณ';
  const removeAvatar=document.createElement('label');removeAvatar.className='remove-avatar';const removeCheckbox=document.createElement('input');removeCheckbox.type='checkbox';removeAvatar.append(removeCheckbox,' ลบรูปแล้วใช้อิโมจิที่เลือก');
  const save=document.createElement('button');save.className='primary full';save.textContent='บันทึกโปรไฟล์';save.onclick=async()=>{try{const body={name:name.value,emoji:chosen,chipBorderColor:color};if(removeCheckbox.checked)body.avatar='';else if(photo.files[0])body.avatar=await resizeAvatar(photo.files[0]);
    if(state){const result=await command('profile',body);if(!result)return;const updated=result.players?.find(p=>p.id===result.me);if(updated)window.hiloAccount={...(window.hiloAccount||{}),...updated};if(updated&&updated.chipBorderColor!==color)toast('สีที่เลือกถูกใช้แล้ว ระบบกำหนดสีสำรองให้');}
    else{const response=await fetch('/api/auth/profile',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(body)});const payload=await response.json();if(!response.ok)throw Error(payload.error||'บันทึกโปรไฟล์ไม่สำเร็จ');window.hiloAccount=payload.user;$('playerName').value=payload.user.name;}
    closeModal();toast('บันทึกโปรไฟล์แล้ว');}catch(e){handleError(e);}};
  root.append(label,name,hint,photo,removeAvatar,document.createTextNode('เลือก Character / Emoji'),picks,title,colors,save);modal('แก้ไขโปรไฟล์',root);
}
$('editProfile').onclick=openProfileEditor;
$('lobbyProfile').onclick=openProfileEditor;
async function resizeAvatar(file){if(file.size>8_000_000)throw new Error('รูปใหญ่เกินไป');const img=await createImageBitmap(file);const canvas=document.createElement('canvas');canvas.width=128;canvas.height=128;const ctx=canvas.getContext('2d');const side=Math.min(img.width,img.height);ctx.drawImage(img,(img.width-side)/2,(img.height-side)/2,side,side,0,0,128,128);img.close();return canvas.toDataURL('image/jpeg',0.64);}
function renderChatList(list){list.replaceChildren();for(const line of state?.messages||[]){const item=document.createElement('div');item.className='chat-line';const name=document.createElement('strong');name.textContent=line.name;const txt=document.createElement('p');txt.textContent=line.text;item.append(name,txt);list.append(item);}if(!state?.messages?.length)list.textContent='ยังไม่มีข้อความในห้อง';list.scrollTop=list.scrollHeight;}
function refreshChatModal(){if($('modal').classList.contains('hidden')||$('modalTitle').textContent!=='แชตในห้อง')return;const list=$('modalBody').querySelector('.chat-list');if(list)renderChatList(list);}
$('chatBtn').onclick=()=>{if(!state)return;const root=document.createElement('div'),list=document.createElement('div');list.className='chat-list';renderChatList(list);
  const form=document.createElement('form');form.className='chat-form';const field=document.createElement('input');field.className='chat-input';field.placeholder='พิมพ์ข้อความถึงเพื่อน…';field.maxLength=250;const send=document.createElement('button');send.textContent='ส่ง';send.className='primary';form.append(field,send);form.onsubmit=async e=>{e.preventDefault();const text=field.value.trim();if(!text)return;const success=await command('chat',{message:text});if(success){field.value='';$('chatBtn').click();}};root.append(list,form);modal('แชตในห้อง',root);};
// ระบบเสียงผ่าน WebRTC ทำงานเมื่อผู้ใช้อนุญาตไมโครโฟน และเว็บไซต์อยู่บน localhost/HTTPS
async function signal(to,signal){try{await api('/api/signal','POST',{to,signal});}catch(e){console.warn('ส่งสัญญาณเสียง:',e.message);}}
function closePeer(id){const pc=peers.get(id);if(pc){pc.close();peers.delete(id);}peerAudio.get(id)?.remove();peerAudio.delete(id);}
function createPeer(id){if(peers.has(id))return peers.get(id);const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});peers.set(id,pc);pc._initiated=false;pc._ice=[];
  for(const track of localStream?.getTracks()||[])pc.addTrack(track,localStream);
  pc.onicecandidate=e=>{if(e.candidate)signal(id,{type:'ice',candidate:e.candidate});};
  pc.ontrack=e=>{let audio=peerAudio.get(id);if(!audio){audio=document.createElement('audio');audio.autoplay=true;audio.playsInline=true;audio.style.display='none';document.body.append(audio);peerAudio.set(id,audio);}audio.srcObject=e.streams[0];audio.play().catch(()=>{});};
  pc.onconnectionstatechange=()=>{if(pc.connectionState==='failed')closePeer(id);};return pc;
}
function syncVoice(){if(!micEnabled||!state||!localStream)return;const mine=me();for(const p of state.players.filter(p=>!p.bot&&p.id!==mine.id)){if(!p.mic){closePeer(p.id);continue;}const pc=createPeer(p.id);if(mine.id<p.id&&!pc._initiated&&pc.signalingState==='stable'){pc._initiated=true;(async()=>{try{const offer=await pc.createOffer();await pc.setLocalDescription(offer);await signal(p.id,{type:'offer',sdp:pc.localDescription});}catch(e){pc._initiated=false;console.warn(e);}})();}}}
async function receiveSignal({from,signal:s}){if(!micEnabled||!localStream)return;if(s.type==='hangup'){closePeer(from);return;}const pc=createPeer(from);
  if(s.type==='offer'){if(pc.signalingState!=='stable'){await pc.setLocalDescription({type:'rollback'});}await pc.setRemoteDescription(new RTCSessionDescription(s.sdp));const answer=await pc.createAnswer();await pc.setLocalDescription(answer);await signal(from,{type:'answer',sdp:pc.localDescription});}
  else if(s.type==='answer')await pc.setRemoteDescription(new RTCSessionDescription(s.sdp));
  else if(s.type==='ice'){if(!pc.remoteDescription){pc._ice.push(s.candidate);return;}try{await pc.addIceCandidate(new RTCIceCandidate(s.candidate))}catch(e){console.warn('ICE candidate:',e.message);}}
  if(pc.remoteDescription&&pc._ice.length){for(const candidate of pc._ice.splice(0))try{await pc.addIceCandidate(new RTCIceCandidate(candidate))}catch(e){console.warn('ICE candidate:',e.message);}}
}
function stopMic(report=true){micEnabled=false;localStream?.getTracks().forEach(t=>t.stop());localStream=null;for(const id of [...peers.keys()]){if(report)signal(id,{type:'hangup'});closePeer(id);}$('micBtn').classList.remove('active');$('micBtn').textContent='🎙️';if(report&&token)command('mic',{enabled:false});}
$('micBtn').onclick=async()=>{if(micEnabled){stopMic();toast('ปิดไมโครโฟนแล้ว');return;}try{if(!navigator.mediaDevices?.getUserMedia)throw new Error('ไมโครโฟนต้องเปิดผ่าน localhost หรือ HTTPS');localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});micEnabled=true;$('micBtn').classList.add('active');$('micBtn').textContent='🔴';await command('mic',{enabled:true});syncVoice();toast('เปิดไมโครโฟนแล้ว');}catch(e){stopMic(false);handleError(e);}};
$('adminButton').onclick=()=>{
  const root=document.createElement('form'),field=document.createElement('input'),submit=document.createElement('button'),error=document.createElement('p');
  field.type='password';field.placeholder='รหัสผ่านระบบหลังบ้าน';field.autocomplete='off';field.required=true;
  submit.type='submit';submit.textContent='เข้าสู่ระบบ';submit.className='primary full';
  error.className='admin-login-error';error.setAttribute('role','alert');
  root.className='admin-login-form';root.append(field,submit,error);
  root.addEventListener('submit',async event=>{
    event.preventDefault();submit.disabled=true;error.textContent='';
    try{
      // Authentication MUST be verified on the server, never by a client-side password constant.
      const r=await api('/api/admin/login','POST',{code:field.value});
      adminToken=r.token;sessionStorage.setItem('hilo-admin-token',adminToken);
      const info=await api('/api/admin','GET',null,true);
      closeModal();screen('admin');renderAdmin(info);openAdminStream();
    }catch(e){error.textContent=e.message||'ไม่สามารถเข้าสู่ระบบได้ กรุณาลองใหม่';field.focus();}
    finally{submit.disabled=false;}
  });
  modal('ระบบหลังบ้าน • เข้าสู่ระบบ',root);field.focus();
};
async function loadAdmin(){try{const info=await api('/api/admin','GET',null,true);renderAdmin(info);}catch(e){handleError(e);}}
function renderAdmin(info){const metrics=[['ผู้เล่นจริง',info.players],['ผู้เล่นที่ออนไลน์',info.online],['จำนวนห้อง',info.rooms],['Solo',info.soloPlayers||0],['Group',info.groupPlayers||0],['เงินสะพัด',money(info.turnover)],['จำนวนรอบ',info.rounds],['ยอดได้สุทธิ',money(info.won)],['ยอดเสียสุทธิ',money(info.lost)],['หมุนวงล้อ',info.wheels],['รางวัลที่ได้รับ',info.rewards],['จำนวนครั้งกดภารกิจ',info.presses]];const div=$('metrics');div.replaceChildren();for(const [label,v]of metrics){const card=document.createElement('div');card.className='metric';const caption=document.createElement('span');caption.textContent=label;const number=document.createElement('strong');number.textContent=v;card.append(caption,number);div.append(card);}const rows=$('adminRows');rows.replaceChildren();for(const rec of info.logs){const tr=document.createElement('tr');const values=[rec.round,rec.player,rec.chosen.map(b=>b.label+' '+money(b.amount)).join(', ')||'ไม่มีเดิมพัน',rec.dice.join('-'),money(rec.before),(rec.net>0?'+':'')+money(rec.net),money(rec.after),new Date(rec.at).toLocaleString('th-TH')];values.forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;if(i===5)td.className=rec.net>=0?'positive':'negative';tr.append(td);});rows.append(tr);}const rooms=$('adminRooms');rooms.replaceChildren();for(const r of info.roomDetails||[]){const tr=document.createElement('tr');[r.roomCode,r.roomId,r.hostName,r.mode,r.roundId,r.players+'/5',r.phase,new Date(r.created||0).toLocaleString('th-TH'),r.bettingEndAt?Math.max(0,Math.ceil((r.bettingEndAt-Date.now())/1000))+' วินาที':'—'].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td);});rooms.append(tr);}
    const people=$('adminPlayers');people.replaceChildren();for(const p of info.playerDetails||[]){const tr=document.createElement('tr');[p.roomCode,p.playerId,p.name,p.type,money(p.balance)].forEach((v,i)=>{const td=document.createElement('td');td.textContent=v;if(i===4)td.className='money-cell';tr.append(td);});people.append(tr);}
    const missions=$('missionRows');missions.replaceChildren();if(!info.missions.length)missions.textContent='ยังไม่มีผู้เล่นทำภารกิจสำเร็จ';for(const m of info.missions){const div=document.createElement('div');div.className='log-card';div.textContent=`${m.player} · ห้อง ${m.room} · ${new Date(m.at).toLocaleString('th-TH')} · +50 ฿`;missions.append(div);}
    const events=$('adminEvents');if(events){events.replaceChildren();for(const event of (info.events||[]).slice(0,120)){const tr=document.createElement('tr');[new Date(event.at).toLocaleString('th-TH'),event.type,event.room||'',event.name||'',event.bot?'BOT':event.playerId?'HUMAN':'SYSTEM',event.betType||'',event.amount??event.betAmount??'',event.balance??'',event.dice?.join('-')||''].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.append(td);});events.append(tr);}}
}
$('adminRefresh').onclick=loadAdmin;let adminStream=null;function openAdminStream(){adminStream?.close();if(!adminToken)return;adminStream=new EventSource('/api/admin/events?token='+encodeURIComponent(adminToken));adminStream.addEventListener('dashboard',e=>{if(document.body.dataset.screen==='admin')renderAdmin(JSON.parse(e.data));});adminStream.onerror=()=>console.warn('Admin live connection reconnecting');}
$('adminBack').onclick=()=>{adminStream?.close();adminStream=null;screen('home');};$('adminReset').onclick=async()=>{if(!confirm('ต้องการล้างข้อมูลห้อง ผู้เล่น และประวัติทั้งหมดหรือไม่? การกระทำนี้ย้อนกลับไม่ได้'))return;const code=prompt('พิมพ์ RESET เพื่อยืนยันการล้างข้อมูลทั้งหมด');if(code!=='RESET')return;try{await api('/api/admin/reset','POST',{},true);toast('ล้างข้อมูลเกมทั้งหมดแล้ว');await loadAdmin();}catch(e){handleError(e);}};
async function resume(){if(!token)return;try{const data=await api('/api/session');state=data.room;openStream();render();screen('game');}catch{localStorage.removeItem('hilo-player-token');token='';}}
resume();
