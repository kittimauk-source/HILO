'use strict';
/* Welcome flow, screen scaling, announcements, arithmetic mission and CSV;
   board image + hotspot positions stay in client.js and are not redefined here. */
const screenReady=()=>document.body.dataset.screen;
const resizeGame=()=>{
  const stage=document.getElementById('game');if(!stage||stage.classList.contains('hidden'))return;
  const vw=window.visualViewport?.width||document.documentElement.clientWidth;
  const vh=window.visualViewport?.height||document.documentElement.clientHeight;
  const virtualW=1440,virtualH=Math.max(1145,stage.scrollHeight),scale=Math.min(vw/virtualW,vh/virtualH);
  stage.style.transform=`scale(${scale})`;
  stage.style.left=`${Math.max(0,(vw-virtualW*scale)/2)}px`;
  stage.style.top=`${Math.max(0,(vh-virtualH*scale)/2)}px`;
};
window.fitGame=resizeGame;
window.addEventListener('resize',resizeGame);
window.visualViewport?.addEventListener('resize',resizeGame);
if(window.ResizeObserver)new ResizeObserver(resizeGame).observe(document.documentElement);

document.getElementById('coverStart').addEventListener('click',()=>{voiceEngine.unlock();screen('deviceScreen');});
document.getElementById('backToCover').addEventListener('click',()=>screen('cover'));

document.getElementById('coverGuide').addEventListener('click',()=>showGuide());
document.querySelectorAll('[data-device-choice]').forEach(button=>button.addEventListener('click',()=>{
  voiceEngine.unlock();const type=button.dataset.deviceChoice;
  document.getElementById('device').value=type;
  document.getElementById('device').dispatchEvent(new Event('change'));
  screen('home');
}));
let soundEnabled=localStorage.getItem('hilo-vip-sound')!=='off';
const soundButton=document.getElementById('coverSound');
const gameSoundButton=document.getElementById('gameSound');
const voiceEngine=window.HiloAudio.createHiloAudio({
  enabled:soundEnabled,
  getRoom:()=>document.body.dataset.screen==='game'?state:null,
  notify:message=>toast(message,true)
});
const syncSoundButton=()=>{
  soundButton.setAttribute('aria-pressed',String(soundEnabled));
  soundButton.title=soundEnabled?'ปิดเสียง':'เปิดเสียง';
  soundButton.style.outline=soundEnabled?'none':'3px solid #aaa8';
  if(gameSoundButton){gameSoundButton.textContent=soundEnabled?'🔊':'🔇';gameSoundButton.setAttribute('aria-pressed',String(soundEnabled));gameSoundButton.title=soundEnabled?'ปิดเสียงเกม':'เปิดเสียงเกม';}
};
syncSoundButton();
const toggleGameSound=()=>{
  soundEnabled=!soundEnabled;localStorage.setItem('hilo-vip-sound',soundEnabled?'on':'off');
  // setEnabled unlocks sound directly from this click.
  voiceEngine.setEnabled(soundEnabled);syncSoundButton();
  toast(soundEnabled?'เปิดเสียงแล้ว เสียงจะทำงานกับเหตุการณ์ถัดไป':'ปิดเสียงแล้ว');
};
soundButton.addEventListener('click',toggleGameSound);
gameSoundButton?.addEventListener('click',toggleGameSound);
window.hiloSound=voiceEngine;
// A direct user tap before the asynchronous Server command enables Safari/Chrome audio.
for(const id of ['soloButton','createButton','joinButton','startBtn']){
  document.getElementById(id)?.addEventListener('click',()=>voiceEngine.unlock(),{capture:true});
}
document.getElementById('leaveBtn')?.addEventListener('click',()=>voiceEngine.stop());
let autoQuizRound='';let quizBusy=false;
const diceGrid={1:[5],2:[1,9],3:[1,5,9],4:[1,3,7,9],5:[1,3,5,7,9],6:[1,3,4,6,7,9]};
function paintRealisticDice(dice){const target=document.getElementById('dicePopupFaces');target.replaceChildren();for(const n of dice){const cube=document.createElement('div');cube.className='realistic-die';cube.setAttribute('aria-label',`ลูกเต๋า ${n} แต้ม`);for(let i=1;i<=9;i++){const pip=document.createElement('i');pip.className='pip'+(diceGrid[n].includes(i)?' visible':'');cube.append(pip);}target.append(cube);}}
window.updateVIP=room=>{
  if(!room||document.body.dataset.screen!=='game')return;
  const phase=room.phase;
  voiceEngine.handleRoom(room,offset);
  const pop=document.getElementById('dicePopup');
  if(phase==='announcing'&&room.dice){
    const total=room.dice.reduce((a,b)=>a+b,0),triple=room.dice.every(n=>n===room.dice[0]);
    paintRealisticDice(room.dice);
    document.getElementById('dicePopupTotal').textContent=`รวม ${total} แต้ม`;
    document.getElementById('dicePopupKind').textContent=triple?'ตอง':total>=11&&total<=17?'สูง':total>=4&&total<=10?'ต่ำ':'ผลพิเศษ';
    pop.classList.remove('hidden');
  }else pop.classList.add('hidden');
  if(phase==='result'){
    const player=room.players.find(x=>x.id===room.me);
    if(player&&player.balance<10&&player.quizEligible&&!quizBusy&&autoQuizRound!==room.roundId){autoQuizRound=room.roundId;setTimeout(()=>{if(state?.players.find(p=>p.id===state.me)?.balance<10&&state?.players.find(p=>p.id===state.me)?.quizEligible)openQuiz();},350);}
  }
};
document.getElementById('quizBtn').addEventListener('click',()=>openQuiz());
async function openQuiz(){
  if(quizBusy)return;quizBusy=true;
  try{const response=await command('quizQuestion');if(response)quizQuestionView(response);else quizBusy=false;}
  catch(e){quizBusy=false;handleError(e);}
}
function quizQuestionView(q){
  const root=document.createElement('div');
  const intro=document.createElement('p');intro.textContent=`ข้อ ${q.index} / ${q.total} • ตอบถูกข้อละ 100 บาท • สะสมแล้ว ${money(q.earned)}`;
  const prompt=document.createElement('h2');prompt.textContent=q.text+' = ?';
  const options=document.createElement('div');options.className='quiz-options';
  q.options.forEach((value,i)=>{
    const button=document.createElement('button');button.className='secondary';button.textContent='ABC'[i]+'. '+Number(value).toLocaleString('th-TH');
    button.addEventListener('click',async()=>{
      [...options.children].forEach(x=>x.disabled=true);
      const result=await command('quizAnswer',{choice:i});
      if(!result){[...options.children].forEach(x=>x.disabled=false);return;}
      if(result.finished&&result.retry){
        toast('ตอบถูก 0/5 ระบบเริ่มโจทย์ชุดใหม่ให้อัตโนมัติ');quizQuestionView(result.next);
      }else if(result.finished){
        quizBusy=false;
        modal('สรุปคะแนนแบบฝึกหัด',`<p>ตอบครบ 5 ข้อแล้ว ได้รับเงินเกมรวม <b>${money(result.earned)}</b></p><p>ระบบเพิ่มยอดเงินนี้เข้าสู่ยอดคงเหลือของคุณแล้ว</p>`);
      }else{
        quizQuestionView(result.next);
        toast(result.correct?'ตอบถูก +100 คะแนนสะสม':'ยังไม่ถูก ไปข้อถัดไป');
      }
    });options.append(button);
  });
  const note=document.createElement('p');note.className='footnote';note.textContent='เงินรางวัลจะเพิ่มครั้งเดียวหลังตอบครบทั้ง 5 ข้อ';
  root.append(intro,prompt,options,note);modal('แบบฝึกหัดบวก–ลบ',root);
}
// Users may close the modal while their quiz remains active: the next click resumes it.
document.getElementById('modalClose').addEventListener('click',()=>{quizBusy=false;});
document.getElementById('exportCSV')?.addEventListener('click',async()=>{
  try{
    const response=await fetch('/api/admin/csv',{headers:{Authorization:'Bearer '+adminToken}});
    if(!response.ok)throw new Error('ไม่สามารถส่งออก CSV ได้');
    const blob=await response.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download='hilo-vip-history.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }catch(e){handleError(e);}
});
let adminPoll=null;
setInterval(()=>{if(document.body.dataset.screen==='admin'&&adminToken)loadAdmin();},6500);
