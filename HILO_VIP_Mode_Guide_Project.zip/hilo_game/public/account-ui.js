'use strict';
/* Account screens are separate from the unchanged betting board. Cookies are HttpOnly. */
(function(){
  let mode='login';
  const $=id=>document.getElementById(id);
  const login=$('authLoginTab'),register=$('authRegisterTab'),form=$('authForm');
  function setMode(next){mode=next;login.classList.toggle('active',mode==='login');register.classList.toggle('active',mode==='register');$('authDisplayWrap').classList.toggle('hidden',mode!=='register');$('authSubmit').textContent=mode==='register'?'สมัครสมาชิก รับเงินเกม 1,500 บาท':'เข้าสู่ระบบ';$('authPassword').autocomplete=mode==='register'?'new-password':'current-password';$('authError').textContent='';}
  login.addEventListener('click',()=>setMode('login'));register.addEventListener('click',()=>setMode('register'));
  function showUser(u){window.hiloAccount=u;$('playerName').value=u.name||u.username;if(!['game','admin'].includes(document.body.dataset.screen))screen('cover');}
  form.addEventListener('submit',async e=>{e.preventDefault();const submit=$('authSubmit');submit.disabled=true;$('authError').textContent='';try{
    const path=mode==='login'?'/api/auth/login':'/api/auth/register';const body={username:$('authUsername').value.trim(),password:$('authPassword').value};if(mode==='register')body.name=$('authDisplay').value.trim()||body.username;
    const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify(body)});const result=await response.json();if(!response.ok)throw Error(result.error||'เข้าสู่ระบบไม่สำเร็จ');$('authPassword').value='';showUser(result.user);
  }catch(error){$('authError').textContent=error.message;}finally{submit.disabled=false;}});
  $('accountLogout').addEventListener('click',async()=>{try{await fetch('/api/auth/logout',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'});}catch(_){/* expired session also returns to login */}
    window.hiloAccount=null;token='';state=null;stream?.close();stream=null;localStorage.removeItem('hilo-player-token');$('authPassword').value='';screen('auth');});
  (async()=>{try{const r=await fetch('/api/auth/me',{cache:'no-store',credentials:'same-origin'});if(!r.ok)throw Error('not signed in');showUser((await r.json()).user);}catch(_){screen('auth');}})();
})();
