'use strict';
/* Audio presentation only. The server owns room timers and results; no audio callback
   can advance a room. Real sound is unlocked through existing player gestures. */
(function(global){
  const THAI=/^th(?:-|_|$)/i;
  const FEMALE=/female|woman|หญิง|กัญญา|นริศา|เปรมวดี|kanya|narisa|premwadee|achara|arisa|sirima|siri.*female|google.*th.*female|microsoft.*th.*female/i;
  const MALE=/(?:^|[^a-z])male(?:[^a-z]|$)|\bman\b|ชาย|niwat|pattara|prateep/i;
  const DIGITS=['ศูนย์','หนึ่ง','สอง','สาม','สี่','ห้า','หก','เจ็ด','แปด','เก้า','สิบ','สิบเอ็ด','สิบสอง','สิบสาม','สิบสี่','สิบห้า','สิบหก','สิบเจ็ด','สิบแปด'];
  function createHiloAudio({enabled=true,notify=()=>{},getRoom=()=>null,onSpeechEnd=()=>{}}={}){
    const synth=global.speechSynthesis||null;
    const supported=!!(synth&&global.SpeechSynthesisUtterance);
    let audioContext=null,enabledNow=Boolean(enabled),unlocked=false,primed=false;
    let voices=[],voice=null,lastContext='',lastEvent='',pending=null,active=null,serial=0,lastWarn='';
    const keyFor=(room)=>`${room.roomId||room.code||'solo'}|${room.roundId||room.round}`;
    const phaseKey=(room)=>`${keyFor(room)}|${room.phase}`;
    const tell=message=>{if(lastWarn!==message){lastWarn=message;notify(message);}};
    const isCurrent=p=>{const room=getRoom();if(!room||!enabledNow||!unlocked||phaseKey(room)!==p.key)return false;
      const t=Date.now()+(Number(p.offset)||0),end=room.phase==='betting'?room.bettingEndAt:room.phase==='announcing'?room.deadline:0;
      return !end||t<end-300;
    };
    function reloadVoices(){
      try{voices=synth?.getVoices?.()||[];}catch(_){voices=[];}
      // Choose one demonstrably female Thai voice for the whole session, never reselect.
      // Web Speech API does NOT expose gender as a reliable separate property.
      if(!voice)voice=voices.find(v=>THAI.test(v.lang)&&FEMALE.test(v.name)&&!MALE.test(v.name))||null;
      if(pending&&isCurrent(pending)){const p=pending;pending=null;play(p);}
      return voice;
    }
    function unlock(){
      // MUST execute synchronously from click/tap, before any awaited network action.
      unlocked=true;
      try{
        const Ctor=global.AudioContext||global.webkitAudioContext;
        if(Ctor){if(!audioContext)audioContext=new Ctor();
          if(audioContext.state==='suspended')audioContext.resume()?.catch?.(()=>{});
          const b=audioContext.createBuffer(1,1,22050),s=audioContext.createBufferSource();
          s.buffer=b;s.connect(audioContext.destination);s.start(0);
        }
      }catch(_){/* Speech synthesis may still work independently. */}
      try{synth?.resume?.();}catch(_){}
      reloadVoices();
      // iOS Safari can require the first speak() call in the user's direct gesture.
      if(supported&&!primed){
        try{const prime=new global.SpeechSynthesisUtterance(' ');prime.lang='th-TH';prime.volume=0;
          if(voice)prime.voice=voice;synth.speak(prime);primed=true;
        }catch(_){}
      }
      return true;
    }
    function effect(kind='chip'){
      if(!enabledNow||!unlocked||!audioContext)return false;
      try{
        if(audioContext.state==='suspended')audioContext.resume()?.catch?.(()=>{});
        const now=audioContext.currentTime;
        const specs=kind==='chip'?[[760,.035,0],[1030,.046,.028]]:kind==='shake'?[[180,.065,0],[290,.075,.09],[210,.06,.18]]:[[670,.07,0],[920,.11,.09]];
        for(const [frequency,length,delay] of specs){
          const osc=audioContext.createOscillator(),gain=audioContext.createGain();
          osc.type=kind==='shake'?'triangle':'sine';osc.frequency.setValueAtTime(frequency,now+delay);
          gain.gain.setValueAtTime(.0001,now+delay);gain.gain.exponentialRampToValueAtTime(kind==='chip'?.065:.09,now+delay+.007);
          gain.gain.exponentialRampToValueAtTime(.0001,now+delay+length);
          osc.connect(gain);gain.connect(audioContext.destination);
          osc.start(now+delay);osc.stop(now+delay+length+.015);
        }
        return true;
      }catch(_){return false;}
    }
    function stop(){serial++;active=null;pending=null;lastContext='';lastEvent='';try{synth?.cancel?.();}catch(_){}}
    function play(p){
      if(!isCurrent(p)||!supported)return false;
      if(lastEvent===p.key)return true;
      // Never fall back to an unknown voice (possibly male). Queue while voices load.
      if(!voice)reloadVoices();
      if(!voice){pending=p;tell(voices.length?'ยังไม่พบเสียงผู้หญิงภาษาไทยในเครื่อง กรุณาติดตั้งเสียงไทยหญิงในระบบและเปิดเสียงอุปกรณ์':'กำลังโหลดเสียงภาษาไทย กรุณาตรวจการตั้งค่าเสียงของอุปกรณ์');return false;}
      if(active){serial++;try{synth.cancel();}catch(_){}}
      else if(primed&&!lastEvent){try{synth.cancel();}catch(_){}}
      const id=++serial,u=new global.SpeechSynthesisUtterance(p.text);
      u.lang='th-TH';u.voice=voice;u.rate=1.03;u.pitch=1;u.volume=1;
      active=p.key;lastEvent=p.key;
      u.onend=()=>{if(id===serial){active=null;onSpeechEnd(p.key);}};
      u.onerror=e=>{if(id!==serial)return;active=null;
        if(e?.error!=='canceled'&&e?.error!=='interrupted'){
          tell('เครื่องนี้ยังเล่นเสียงพูดไม่ได้ ตรวจระดับเสียงหรือเสียง TTS ที่ติดตั้ง');
          effect('announce');
        }
      };
      try{synth.resume?.();synth.speak(u);return true;}
      catch(_){active=null;lastEvent='';effect('announce');tell('ระบบเสียงพูดถูกบล็อก ตรวจสิทธิ์เสียงของเบราว์เซอร์');return false;}
    }
    function handleRoom(room,timeOffset=0){
      if(!room)return;
      const ctx=keyFor(room),key=phaseKey(room);
      if(ctx!==lastContext){stop();lastContext=ctx;}
      if(active&&active!==key){serial++;active=null;try{synth?.cancel?.();}catch(_){}}
      if(pending&&pending.key!==key)pending=null;
      if(!enabledNow||!unlocked||lastEvent===key||pending?.key===key)return;
      if(room.phase==='betting'&&Date.now()+timeOffset<room.bettingEndAt-300){
        effect('announce');
        if(!supported){lastEvent=key;tell('เบราว์เซอร์ไม่รองรับเสียงพูด แต่เสียงเอฟเฟกต์ยังทำงาน');return;}
        play({key,text:'เริ่มเดิมพัน',offset:timeOffset});
      }else if(room.phase==='shake'){
        lastEvent=key;effect('shake');
      }else if(room.phase==='announcing'&&Array.isArray(room.dice)&&room.dice.length===3){
        const d=room.dice,total=d.reduce((a,b)=>a+b,0),triple=d.every(n=>n===d[0]);
        const highLow=triple?'ตอง':total>=11&&total<=17?'สูง':total>=4&&total<=10?'ต่ำ':'ผลพิเศษ';
        effect('announce');
        if(!supported){lastEvent=key;return;}
        play({key,text:`${d.map(n=>DIGITS[n]).join(' ')} รวม ${DIGITS[total]||total} ${highLow}`,offset:timeOffset});
      }
    }
    function setEnabled(flag){
      enabledNow=Boolean(flag);
      if(!enabledNow){stop();return;}
      unlock();
      // After unmuting, do not repeat an old phase already running.
      const room=getRoom();if(room){lastContext=keyFor(room);lastEvent=phaseKey(room);}
    }
    if(synth){
      synth.addEventListener?.('voiceschanged',reloadVoices);
      if(!synth.addEventListener){const prev=synth.onvoiceschanged;synth.onvoiceschanged=e=>{prev?.(e);reloadVoices();};}
      global.addEventListener?.('pageshow',reloadVoices);
      global.document?.addEventListener?.('visibilitychange',()=>{if(!global.document.hidden&&unlocked&&enabledNow){reloadVoices();try{synth.resume?.();}catch(_){}}});
      reloadVoices();[300,1200,2800].forEach(t=>global.setTimeout?.(reloadVoices,t));
    }
    return {unlock,handleRoom,setEnabled,stop,reloadVoices,playEffect:effect,
      getStatus:()=>({enabled:enabledNow,unlocked,supported,voice:voice?.name||'ยังไม่มีเสียงผู้หญิงภาษาไทย',speaking:Boolean(active),voices:voices.map(v=>({name:v.name,lang:v.lang}))})};
  }
  global.HiloAudio={createHiloAudio};
})(typeof window!=='undefined'?window:globalThis);
